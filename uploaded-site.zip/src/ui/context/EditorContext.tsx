import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { CameraMode } from '../../core/camera/CameraController';
import { EditorEngine } from '../../core/editor/EditorEngine';
import { getTranslations, type TranslationStrings } from '../../core/i18n/translations';
import type { DimensiXProject, EditorSettings } from '../../core/project/ProjectTypes';
import type { PathTracerStatus, TransformMode } from '../../core/rendering/IRenderEngine';
import type { RenderSettings } from '../../core/rendering/RenderSettings';
import type { SceneNode, SceneSnapshot } from '../../core/scene/SceneNode';

interface EditorContextValue {
  engine: EditorEngine;
  snapshot: SceneSnapshot;
  selectedNode: SceneNode | null;
  project: DimensiXProject;
  settings: EditorSettings;
  renderSettings: RenderSettings;
  transformMode: TransformMode;
  cameraMode: CameraMode;
  activeEngineId: string;
  pathTracerStatus: PathTracerStatus | null;
  importError: string | null;
  clearImportError: () => void;
  canUndo: boolean;
  canRedo: boolean;
  isDirty: boolean;
  lastSavedAt: number | null;
  t: TranslationStrings;
}

const EditorContext = createContext<EditorContextValue | null>(null);

export function EditorProvider({ children }: { children: React.ReactNode }) {
  const engine = useMemo(() => new EditorEngine(), []);

  const [snapshot, setSnapshot] = useState<SceneSnapshot>(() => engine.getSnapshot());
  const [selectedNode, setSelectedNode] = useState<SceneNode | null>(() => engine.getSelectedNode());
  const [project, setProject] = useState<DimensiXProject>(() => engine.getActiveProject());
  const [settings, setSettings] = useState<EditorSettings>(() => engine.getSettings());
  const [renderSettings, setRenderSettings] = useState<RenderSettings>(() =>
    engine.getRenderSettings(),
  );
  const [transformMode, setTransformMode] = useState<TransformMode>(() => engine.getTransformMode());
  const [cameraMode, setCameraMode] = useState<CameraMode>(() => engine.getCameraMode());
  const [activeEngineId, setActiveEngineId] = useState<string>(() => engine.getActiveEngineId());
  const [pathTracerStatus, setPathTracerStatus] = useState<PathTracerStatus | null>(() =>
    engine.getPathTracerStatus(),
  );
  const [importError, setImportError] = useState<string | null>(null);
  const [canUndo, setCanUndo] = useState<boolean>(() => engine.canUndo());
  const [canRedo, setCanRedo] = useState<boolean>(() => engine.canRedo());
  const [isDirty, setIsDirty] = useState<boolean>(() => engine.getIsDirty());
  const [lastSavedAt, setLastSavedAt] = useState<number | null>(() => engine.getLastSavedAt());

  useEffect(() => {
    const unsubScene = engine.events.on('scene:changed', ({ snapshot: next }) => {
      setSnapshot(next);
      setSelectedNode(engine.getSelectedNode());
    });

    const unsubSelection = engine.events.on('selection:changed', ({ node }) => {
      setSnapshot(engine.getSnapshot());
      setSelectedNode(node);
    });

    const unsubUpdated = engine.events.on('node:updated', ({ node }) => {
      setSnapshot(engine.getSnapshot());
      if (engine.getSelectedNode()?.id === node.id) {
        setSelectedNode(node);
      }
    });

    const unsubHistory = engine.events.on('history:changed', ({ canUndo: u, canRedo: r }) => {
      setCanUndo(u);
      setCanRedo(r);
    });

    const unsubMode = engine.events.on('viewport:transformModeChanged', ({ mode }) => {
      setTransformMode(mode);
    });

    const unsubCameraMode = engine.events.on('camera:modeChanged', ({ mode }) => {
      setCameraMode(mode);
    });

    const unsubLoaded = engine.events.on('project:loaded', ({ project: nextProject }) => {
      setProject(nextProject);
      setLastSavedAt(nextProject.updatedAt);
    });

    const unsubSaved = engine.events.on('project:saved', ({ project: savedProject, savedAt }) => {
      setProject(savedProject);
      setLastSavedAt(savedAt);
    });

    const unsubDirty = engine.events.on('project:dirtyChanged', ({ isDirty: dirty }) => {
      setIsDirty(dirty);
    });

    const unsubSettings = engine.events.on('settings:changed', ({ settings: nextSettings }) => {
      setSettings(nextSettings);
      setActiveEngineId(nextSettings.activeEngineId);
    });

    const unsubRenderSettings = engine.events.on(
      'renderSettings:changed',
      ({ renderSettings: nextRender }) => {
        setRenderSettings(nextRender);
      },
    );

    const unsubEngineChanged = engine.events.on('engine:changed', ({ engineId }) => {
      setActiveEngineId(engineId);
      if (engineId !== 'dimensix-path-tracer') {
        setPathTracerStatus(null);
      }
    });

    const unsubPtStatus = engine.events.on('pathtracer:status', (status) => {
      setPathTracerStatus(status);
    });

    const unsubImportError = engine.events.on('model:importError', ({ message }) => {
      setImportError(message);
    });

    return () => {
      unsubScene();
      unsubSelection();
      unsubUpdated();
      unsubHistory();
      unsubMode();
      unsubCameraMode();
      unsubLoaded();
      unsubSaved();
      unsubDirty();
      unsubSettings();
      unsubRenderSettings();
      unsubEngineChanged();
      unsubPtStatus();
      unsubImportError();
    };
  }, [engine]);

  // Sync document lang & dir with active language setting
  useEffect(() => {
    document.documentElement.lang = settings.language;
    document.documentElement.dir = settings.language === 'ar' ? 'rtl' : 'ltr';
  }, [settings.language]);

  const t = useMemo(() => getTranslations(settings.language), [settings.language]);

  const value: EditorContextValue = {
    engine,
    snapshot,
    selectedNode,
    project,
    settings,
    renderSettings,
    transformMode,
    cameraMode,
    activeEngineId,
    pathTracerStatus,
    importError,
    clearImportError: () => setImportError(null),
    canUndo,
    canRedo,
    isDirty,
    lastSavedAt,
    t,
  };

  return <EditorContext.Provider value={value}>{children}</EditorContext.Provider>;
}

export function useEditor(): EditorContextValue {
  const ctx = useContext(EditorContext);
  if (!ctx) {
    throw new Error('useEditor must be used inside EditorProvider');
  }
  return ctx;
}
