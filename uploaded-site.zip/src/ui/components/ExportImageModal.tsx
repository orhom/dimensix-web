import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Camera,
  Download,
  Grid,
  Pause,
  Play,
  Sparkles,
  Square,
  X,
  Zap,
} from 'lucide-react';
import {
  ASPECT_RATIO_PRESETS,
  clampSampleCount,
  computeExportDimensions,
  deriveHeightFromWidth,
  MAX_SAMPLES_LIMIT,
  RESOLUTION_BASE_PRESETS,
  SAMPLE_PRESETS,
  type AspectRatioPresetId,
  type ResolutionPresetId,
} from '../../core/rendering/AspectAndResolution';
import {
  buildCenterFirstTiles,
  planExportMemoryBudget,
  probeDeviceGraphicsCapabilities,
} from '../../core/rendering/MemoryBudget';
import { PATH_TRACING_DESCRIPTOR } from '../../core/rendering/PathTracingViewportEngine';
import { THREE_FOUNDATION_DESCRIPTOR } from '../../core/rendering/ThreeViewportEngine';
import type {
  ExportPauseController,
  TiledExportProgressEvent,
} from '../../core/rendering/TiledPathTracingExportSession';
import { useEditor } from '../context/EditorContext';

interface ExportImageModalProps {
  open: boolean;
  onClose: () => void;
}

type ExportState = 'idle' | 'rendering' | 'paused' | 'completed' | 'cancelled' | 'error';

function formatElapsed(ms: number): string {
  const sec = Math.max(0, ms / 1000);
  if (sec < 60) {
    return `${sec.toFixed(1)}s`;
  }
  const mins = Math.floor(sec / 60);
  const rem = (sec % 60).toFixed(1).padStart(4, '0');
  return `${mins}m ${rem}s`;
}

export function ExportImageModal({ open, onClose }: ExportImageModalProps) {
  const { engine, activeEngineId, t } = useEditor();

  const [selectedEngineId, setSelectedEngineId] = useState(activeEngineId);
  const [aspectPreset, setAspectPreset] = useState<AspectRatioPresetId>('16:9');
  const [customAspectW, setCustomAspectW] = useState<number>(16);
  const [customAspectH, setCustomAspectH] = useState<number>(10);

  const [resolutionPreset, setResolutionPreset] = useState<ResolutionPresetId>('1024');
  const [customWidth, setCustomWidth] = useState<number>(1920);
  const [customHeight, setCustomHeight] = useState<number>(1080);

  const [samples, setSamples] = useState<number>(64);
  const [showTileOverlay, setShowTileOverlay] = useState<boolean>(true);

  const [exportState, setExportState] = useState<ExportState>('idle');
  const [progress, setProgress] = useState<number>(0);
  const [telemetry, setTelemetry] = useState<TiledExportProgressEvent | null>(null);
  const [renderedSize, setRenderedSize] = useState<{ width: number; height: number } | null>(null);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const renderCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const pausedRef = useRef<boolean>(false);
  const pauseResolversRef = useRef<Array<() => void>>([]);
  const lastUiSyncRef = useRef<number>(0);

  const caps = useMemo(() => probeDeviceGraphicsCapabilities(), []);

  const dims = useMemo(
    () =>
      computeExportDimensions({
        aspectPreset,
        customAspectW,
        customAspectH,
        resolutionPreset,
        customWidth,
        customHeight,
      }),
    [aspectPreset, customAspectW, customAspectH, resolutionPreset, customWidth, customHeight],
  );

  const isPathTracing = selectedEngineId === PATH_TRACING_DESCRIPTOR.id;

  const memoryPlan = useMemo(
    () =>
      planExportMemoryBudget(
        dims.width,
        dims.height,
        isPathTracing ? samples : 1,
        caps,
        isPathTracing ? 'pathtracer' : 'realtime',
      ),
    [dims.width, dims.height, isPathTracing, samples, caps],
  );

  const tileGrid = useMemo(
    () =>
      memoryPlan.valid
        ? buildCenterFirstTiles(memoryPlan.width, memoryPlan.height, memoryPlan.tileSize)
        : [],
    [memoryPlan],
  );

  const wakePausedWaiters = useCallback(() => {
    const list = pauseResolversRef.current.splice(0);
    for (const resolve of list) resolve();
  }, []);

  useEffect(() => {
    if (open) {
      setSelectedEngineId(activeEngineId);
      setErrorMsg(null);
    }
  }, [open, activeEngineId]);

  useEffect(() => {
    return () => {
      abortRef.current?.abort();
      wakePausedWaiters();
    };
  }, [wakePausedWaiters]);

  useEffect(() => {
    return () => {
      if (downloadUrl) {
        URL.revokeObjectURL(downloadUrl);
      }
    };
  }, [downloadUrl]);

  const drawTileOverlay = useCallback(
    (ev: TiledExportProgressEvent | null, clearAll = false) => {
      const ov = overlayCanvasRef.current;
      if (!ov) return;
      const ctx = ov.getContext('2d');
      if (!ctx) return;

      if (ov.width !== dims.width || ov.height !== dims.height) {
        ov.width = dims.width;
        ov.height = dims.height;
      }
      ctx.clearRect(0, 0, ov.width, ov.height);

      if (clearAll || !showTileOverlay || !ev) return;

      const scaleStroke = Math.max(1, Math.round(Math.max(dims.width, dims.height) / 512));

      // Subtle pending tile boundaries
      ctx.lineWidth = scaleStroke;
      for (const tile of tileGrid) {
        if (ev.activeTile && tile.index === ev.activeTile.index) continue;
        if (!ev.completedTileIndices.has(tile.index)) {
          ctx.strokeStyle = 'rgba(148, 163, 184, 0.16)';
          ctx.strokeRect(tile.tx + 0.5, tile.tyTop + 0.5, tile.tw - 1, tile.th - 1);
        }
      }

      // Highlight active tile being traced right now
      if (ev.activeTile) {
        const at = ev.activeTile;
        ctx.strokeStyle = 'rgba(34, 211, 238, 0.92)';
        ctx.lineWidth = scaleStroke * 2;
        ctx.strokeRect(at.tx + scaleStroke, at.tyTop + scaleStroke, Math.max(1, at.tw - scaleStroke * 2), Math.max(1, at.th - scaleStroke * 2));

        const bracket = Math.min(18 * scaleStroke, Math.floor(Math.min(at.tw, at.th) * 0.25));
        ctx.strokeStyle = '#A78BFA';
        ctx.lineWidth = scaleStroke * 2.5;
        ctx.beginPath();
        // Top-left corner bracket
        ctx.moveTo(at.tx, at.tyTop + bracket);
        ctx.lineTo(at.tx, at.tyTop);
        ctx.lineTo(at.tx + bracket, at.tyTop);
        // Bottom-right corner bracket
        ctx.moveTo(at.tx + at.tw - bracket, at.tyTop + at.th);
        ctx.lineTo(at.tx + at.tw, at.tyTop + at.th);
        ctx.lineTo(at.tx + at.tw, at.tyTop + at.th - bracket);
        ctx.stroke();
      }
    },
    [dims.width, dims.height, showTileOverlay, tileGrid],
  );

  useEffect(() => {
    if (exportState === 'rendering' || exportState === 'paused') {
      drawTileOverlay(telemetry, false);
    } else {
      drawTileOverlay(null, true);
    }
  }, [showTileOverlay, exportState, telemetry, drawTileOverlay]);

  if (!open) return null;

  const isBusy = exportState === 'rendering' || exportState === 'paused';

  const handleSelectAspect = (nextPreset: AspectRatioPresetId) => {
    setAspectPreset(nextPreset);
    if (resolutionPreset === 'custom') {
      setCustomHeight(
        deriveHeightFromWidth(customWidth, nextPreset, customAspectW, customAspectH),
      );
    }
  };

  const handleStartRender = async () => {
    if (!memoryPlan.valid) {
      setErrorMsg(memoryPlan.reason || 'Invalid export dimensions.');
      return;
    }

    abortRef.current?.abort();
    pausedRef.current = false;
    wakePausedWaiters();

    const controller = new AbortController();
    abortRef.current = controller;

    if (downloadUrl) {
      setDownloadUrl(null);
    }

    const canvas = renderCanvasRef.current;
    if (canvas) {
      canvas.width = dims.width;
      canvas.height = dims.height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#090D16';
        ctx.fillRect(0, 0, dims.width, dims.height);
      }
    }

    setExportState('rendering');
    setProgress(0);
    setTelemetry(null);
    setRenderedSize({ width: dims.width, height: dims.height });
    setErrorMsg(null);
    lastUiSyncRef.current = 0;

    const pauseController: ExportPauseController = {
      isPaused: () => pausedRef.current,
      waitWhilePaused: (sig?: AbortSignal) =>
        new Promise<void>((resolve) => {
          if (!pausedRef.current || sig?.aborted) {
            resolve();
            return;
          }
          const onAbort = () => {
            sig?.removeEventListener('abort', onAbort);
            resolve();
          };
          sig?.addEventListener('abort', onAbort, { once: true });
          pauseResolversRef.current.push(() => {
            sig?.removeEventListener('abort', onAbort);
            resolve();
          });
        }),
    };

    try {
      const blob = await engine.exportRenderImage({
        engineId: selectedEngineId,
        width: dims.width,
        height: dims.height,
        samples: clampSampleCount(samples),
        targetCanvas: renderCanvasRef.current ?? undefined,
        pauseController,
        signal: controller.signal,
        onProgress: (p, cur, total) => {
          setProgress(p);
          if (!isPathTracing) {
            setTelemetry({
              progress01: p,
              currentSample: cur,
              totalSamples: total,
              completedTilesInPass: cur >= total ? 1 : 0,
              totalTiles: 1,
              samplesPerSec: 0,
              elapsedMs: 0,
              activeTile: null,
              completedTileIndices: new Set(cur >= total ? [0] : []),
              engineModeLabel: 'GPU WebGL2',
              strategy: 'full-progressive',
            });
          }
        },
        onTiledProgress: (ev) => {
          drawTileOverlay(ev, false);
          const now = performance.now();
          if (now - lastUiSyncRef.current >= 45 || ev.progress01 >= 1 || ev.activeTile === null) {
            lastUiSyncRef.current = now;
            setTelemetry({
              ...ev,
              completedTileIndices: new Set(ev.completedTileIndices),
            });
            setProgress(ev.progress01);
          }
        },
      });

      const url = URL.createObjectURL(blob);
      setDownloadUrl(url);
      setProgress(1);
      setExportState('completed');
      drawTileOverlay(null, true);
    } catch (err) {
      drawTileOverlay(null, true);
      if (controller.signal.aborted) {
        setExportState('cancelled');
      } else {
        setExportState('error');
        setErrorMsg(err instanceof Error ? err.message : 'Export render failed.');
      }
    } finally {
      pausedRef.current = false;
      wakePausedWaiters();
    }
  };

  const handleTogglePause = () => {
    if (exportState === 'rendering') {
      pausedRef.current = true;
      setExportState('paused');
    } else if (exportState === 'paused') {
      pausedRef.current = false;
      setExportState('rendering');
      wakePausedWaiters();
    }
  };

  const handleCancel = () => {
    pausedRef.current = false;
    abortRef.current?.abort();
    wakePausedWaiters();
    if (isBusy) {
      setExportState('cancelled');
    }
  };

  const aspectNameMap: Record<AspectRatioPresetId, string> = {
    '1:1': t.exportModal.aspectSquare,
    '16:9': t.exportModal.aspectLandscape,
    '9:16': t.exportModal.aspectPortrait,
    '4:3': t.exportModal.aspectStandard,
    '3:2': t.exportModal.aspectPhoto,
    custom: t.exportModal.aspectCustom,
  };

  const statusText =
    exportState === 'rendering'
      ? t.exportModal.rendering
      : exportState === 'paused'
        ? t.exportModal.pausedLabel
        : exportState === 'completed'
          ? t.exportModal.completedLabel
          : exportState === 'cancelled'
            ? t.exportModal.cancelledLabel
            : t.exportModal.idleLabel;

  const hasPreviewFrame =
    exportState === 'rendering' ||
    exportState === 'paused' ||
    exportState === 'completed' ||
    exportState === 'cancelled';

  const frameDims = renderedSize && hasPreviewFrame ? renderedSize : dims;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-2 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="export-modal-title"
      data-testid="dimensix-export-modal"
      data-export-state={exportState}
    >
      <div className="w-full max-w-5xl rounded-2xl bg-[#111520] border border-white/[0.1] overflow-hidden flex flex-col max-h-[94vh]">
        {/* Header */}
        <div className="px-4 sm:px-5 py-3 border-b border-white/[0.08] flex items-center justify-between gap-4 shrink-0 bg-[#0D1019]">
          <div className="min-w-0">
            <h2 id="export-modal-title" className="text-sm font-semibold text-white truncate">
              {t.exportModal.title}
            </h2>
            <p className="text-[11px] text-slate-400 truncate">{t.exportModal.subtitle}</p>
          </div>
          <button
            type="button"
            onClick={() => {
              handleCancel();
              onClose();
            }}
            aria-label={t.close}
            className="min-h-[38px] min-w-[38px] rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/[0.06] shrink-0"
          >
            <X className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>

        {/* Main Studio Body */}
        <div className="p-4 sm:p-5 overflow-y-auto dx-scroll grid grid-cols-1 lg:grid-cols-[1.08fr_1fr] gap-5">
          {/* Left Column: Live Progressive Canvas Stage & Telemetry */}
          <div className="flex flex-col gap-3 min-w-0">
            <div className="rounded-xl bg-[#070A10] border border-white/[0.08] p-3 flex items-center justify-center min-h-[220px] sm:min-h-[300px] lg:min-h-[360px] relative overflow-hidden">
              <div
                className="relative w-full max-h-[42vh] lg:max-h-[50vh] flex items-center justify-center rounded-lg overflow-hidden border border-white/[0.08] bg-[#090D16] mx-auto"
                style={{
                  aspectRatio: `${frameDims.width} / ${frameDims.height}`,
                  maxWidth:
                    frameDims.width >= frameDims.height
                      ? '100%'
                      : `calc(42vh * ${frameDims.width / frameDims.height})`,
                }}
                data-testid="dimensix-export-frame"
              >
                <canvas
                  ref={renderCanvasRef}
                  data-testid="dimensix-export-canvas"
                  className={`w-full h-full block object-contain ${hasPreviewFrame ? 'opacity-100' : 'opacity-0'}`}
                />
                <canvas
                  ref={overlayCanvasRef}
                  aria-hidden="true"
                  className="absolute inset-0 w-full h-full pointer-events-none object-contain"
                />

                {!hasPreviewFrame && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-5 text-center gap-2">
                    <Camera className="w-7 h-7 text-slate-600" aria-hidden="true" />
                    <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
                      {t.exportModal.previewEmpty}
                    </p>
                    <span className="text-xs font-mono tabular-nums text-cyan-300/90" dir="ltr">
                      {dims.width} × {dims.height} ({dims.aspectLabel})
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Live Progress Bar & Real Telemetry Readout */}
            <div
              className="rounded-xl bg-[#0B0E17] border border-white/[0.08] px-3.5 py-3 space-y-2.5"
              data-testid="dimensix-export-progress"
            >
              <div className="flex items-center justify-between gap-2 text-xs">
                <span
                  className={`font-medium ${
                    exportState === 'completed'
                      ? 'text-emerald-300'
                      : exportState === 'paused'
                        ? 'text-amber-300'
                        : exportState === 'cancelled' || exportState === 'error'
                          ? 'text-rose-300'
                          : isBusy
                            ? 'text-cyan-300'
                            : 'text-slate-300'
                  }`}
                  data-testid="dimensix-export-status-text"
                >
                  {statusText}
                </span>
                <div className="flex items-center gap-2.5">
                  {isPathTracing && (
                    <button
                      type="button"
                      onClick={() => setShowTileOverlay((v) => !v)}
                      aria-pressed={showTileOverlay}
                      className={`h-7 px-2 rounded-md border text-[11px] flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 ${
                        showTileOverlay
                          ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-200'
                          : 'bg-[#121622] border-white/[0.08] text-slate-400 hover:text-white'
                      }`}
                    >
                      <Grid className="w-3 h-3" aria-hidden="true" />
                      <span>{t.exportModal.showTileOverlayLabel}</span>
                    </button>
                  )}
                  <span className="font-mono tabular-nums text-slate-200 font-semibold" dir="ltr">
                    {Math.round(progress * 100)}%
                  </span>
                </div>
              </div>

              <div className="w-full h-2 rounded-full bg-[#151A28] overflow-hidden">
                <div
                  className={`h-full transition-all duration-150 ${
                    exportState === 'paused'
                      ? 'bg-amber-400'
                      : exportState === 'completed'
                        ? 'bg-emerald-400'
                        : 'bg-gradient-to-r from-violet-500 to-cyan-400'
                  }`}
                  style={{ width: `${Math.round(progress * 100)}%` }}
                />
              </div>

              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-400 font-mono tabular-nums">
                <span data-testid="dimensix-export-samples-readout" dir="ltr">
                  {telemetry
                    ? `${telemetry.currentSample}/${telemetry.totalSamples} spp`
                    : isPathTracing
                      ? `0/${samples} spp`
                      : '1/1 frame'}
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  {t.exportModal.tilesLabel}{' '}
                  <bdi dir="ltr">
                    {telemetry
                      ? `${telemetry.completedTilesInPass}/${telemetry.totalTiles}`
                      : `0/${memoryPlan.totalTiles}`}
                  </bdi>
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  {t.exportModal.elapsedLabel}:{' '}
                  <bdi dir="ltr">
                    {telemetry ? formatElapsed(telemetry.elapsedMs) : '0.0s'}
                  </bdi>
                </span>
                {telemetry && telemetry.samplesPerSec > 0 && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span>
                      <bdi dir="ltr">{telemetry.samplesPerSec.toFixed(1)}</bdi>{' '}
                      {t.exportModal.speedLabel === 'Speed' || t.exportModal.speedLabel === 'Throughput'
                        ? 'spp/s'
                        : 'عينة/ث'}
                    </span>
                  </>
                )}
                <span aria-hidden="true">·</span>
                <span className="text-slate-300" dir="ltr">
                  {frameDims.width} × {frameDims.height}
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Independent Aspect Ratio, Resolution, Samples & Budget */}
          <div className="space-y-4 min-w-0">
            {/* Engine Selector */}
            <div className="space-y-1.5">
              <span className="block text-xs font-semibold text-slate-200">
                {t.exportModal.engineLabel}
              </span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => setSelectedEngineId(THREE_FOUNDATION_DESCRIPTOR.id)}
                  className={`min-h-[42px] px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    !isPathTracing
                      ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-200'
                      : 'bg-[#0B0E17] border-white/[0.08] text-slate-400 hover:text-white'
                  }`}
                >
                  <Zap className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>{t.engineRealtime}</span>
                </button>

                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => setSelectedEngineId(PATH_TRACING_DESCRIPTOR.id)}
                  className={`min-h-[42px] px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    isPathTracing
                      ? 'bg-violet-600/25 border-violet-500/55 text-violet-200'
                      : 'bg-[#0B0E17] border-white/[0.08] text-slate-400 hover:text-white'
                  }`}
                >
                  <Sparkles className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>{t.enginePathTracing}</span>
                </button>
              </div>
            </div>

            {/* Section A: Image Aspect Ratio */}
            <div className="space-y-2" data-testid="dimensix-aspect-section">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-slate-200">
                  {t.exportModal.aspectSectionTitle}
                </span>
                <span className="text-[11px] font-mono tabular-nums text-cyan-300" dir="ltr">
                  {dims.aspectLabel}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {ASPECT_RATIO_PRESETS.map((item) => {
                  const active = aspectPreset === item.id;
                  const maxBox = 18;
                  const ratio =
                    item.id === 'custom'
                      ? Math.max(0.25, Math.min(4, customAspectW / Math.max(0.1, customAspectH)))
                      : item.ratioW / item.ratioH;
                  const boxW = ratio >= 1 ? maxBox : Math.max(8, Math.round(maxBox * ratio));
                  const boxH = ratio >= 1 ? Math.max(8, Math.round(maxBox / ratio)) : maxBox;

                  return (
                    <button
                      key={item.id}
                      type="button"
                      disabled={isBusy}
                      data-testid={`aspect-card-${item.id}`}
                      onClick={() => handleSelectAspect(item.id)}
                      className={`min-h-[54px] px-2 py-1.5 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition-colors ${
                        active
                          ? 'bg-cyan-500/18 border-cyan-400/60 text-white'
                          : 'bg-[#0B0E17] border-white/[0.08] text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <span
                        className={`inline-block rounded-[2px] border ${
                          active ? 'border-cyan-300 bg-cyan-400/20' : 'border-slate-500 bg-white/[0.04]'
                        }`}
                        style={{ width: `${boxW}px`, height: `${boxH}px` }}
                        aria-hidden="true"
                      />
                      <span className="text-[11px] font-medium leading-tight whitespace-nowrap">
                        {item.id === 'custom' ? aspectNameMap.custom : `${item.id} · ${aspectNameMap[item.id]}`}
                      </span>
                    </button>
                  );
                })}
              </div>

              {aspectPreset === 'custom' && (
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <label className="block space-y-1">
                    <span className="block text-[11px] text-slate-400">
                      {t.exportModal.ratioWidthLabel}
                    </span>
                    <input
                      type="number"
                      min={1}
                      max={100}
                      step={1}
                      disabled={isBusy}
                      value={customAspectW}
                      onChange={(e) => setCustomAspectW(Math.max(1, Number(e.target.value) || 1))}
                      dir="ltr"
                      className="w-full h-9 px-2.5 rounded-lg bg-[#0B0E17] border border-white/[0.1] text-xs font-mono tabular-nums text-slate-100 focus:outline-none focus:border-cyan-500"
                    />
                  </label>
                  <label className="block space-y-1">
                    <span className="block text-[11px] text-slate-400">
                      {t.exportModal.ratioHeightLabel}
                    </span>
                    <input
                      type="number"
                      min={1}
                      max={100}
                      step={1}
                      disabled={isBusy}
                      value={customAspectH}
                      onChange={(e) => setCustomAspectH(Math.max(1, Number(e.target.value) || 1))}
                      dir="ltr"
                      className="w-full h-9 px-2.5 rounded-lg bg-[#0B0E17] border border-white/[0.1] text-xs font-mono tabular-nums text-slate-100 focus:outline-none focus:border-cyan-500"
                    />
                  </label>
                </div>
              )}
            </div>

            {/* Section B: Output Resolution */}
            <div className="space-y-2" data-testid="dimensix-resolution-section">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-slate-200">
                  {t.exportModal.resolutionSectionTitle}
                </span>
                <span className="text-[11px] font-mono tabular-nums text-violet-300" dir="ltr">
                  {dims.width} × {dims.height} px
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {RESOLUTION_BASE_PRESETS.map((resKey) => {
                  const active = resolutionPreset === resKey;
                  const derivedH = deriveHeightFromWidth(
                    parseInt(resKey, 10),
                    aspectPreset,
                    customAspectW,
                    customAspectH,
                  );
                  return (
                    <button
                      key={resKey}
                      type="button"
                      disabled={isBusy}
                      data-testid={`resolution-card-${resKey}`}
                      onClick={() => setResolutionPreset(resKey)}
                      className={`min-h-[46px] px-2 py-1.5 rounded-xl border flex flex-col items-center justify-center transition-colors ${
                        active
                          ? 'bg-violet-600/25 border-violet-400/60 text-white'
                          : 'bg-[#0B0E17] border-white/[0.08] text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <span className="text-xs font-mono font-semibold tabular-nums" dir="ltr">
                        {resKey} px
                      </span>
                      <span className="text-[10px] font-mono tabular-nums text-slate-400" dir="ltr">
                        {resKey} × {derivedH}
                      </span>
                    </button>
                  );
                })}

                <button
                  type="button"
                  disabled={isBusy}
                  data-testid="resolution-card-custom"
                  onClick={() => setResolutionPreset('custom')}
                  className={`min-h-[46px] px-2 py-1.5 rounded-xl border flex flex-col items-center justify-center transition-colors ${
                    resolutionPreset === 'custom'
                      ? 'bg-violet-600/25 border-violet-400/60 text-white'
                      : 'bg-[#0B0E17] border-white/[0.08] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span className="text-xs font-semibold whitespace-nowrap">
                    {t.exportModal.resolutionCustom}
                  </span>
                  <span className="text-[10px] font-mono tabular-nums text-slate-400" dir="ltr">
                    W × H
                  </span>
                </button>
              </div>

              {resolutionPreset === 'custom' && (
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <label className="block space-y-1">
                    <span className="block text-[11px] text-slate-400">
                      {t.exportModal.customWidthLabel}
                    </span>
                    <input
                      type="number"
                      min={64}
                      max={8192}
                      step={16}
                      disabled={isBusy}
                      value={customWidth}
                      onChange={(e) => setCustomWidth(Math.max(64, Number(e.target.value) || 64))}
                      dir="ltr"
                      className="w-full h-9 px-2.5 rounded-lg bg-[#0B0E17] border border-white/[0.1] text-xs font-mono tabular-nums text-slate-100 focus:outline-none focus:border-violet-500"
                    />
                  </label>
                  <label className="block space-y-1">
                    <span className="block text-[11px] text-slate-400">
                      {t.exportModal.customHeightLabel}
                    </span>
                    <input
                      type="number"
                      min={64}
                      max={8192}
                      step={16}
                      disabled={isBusy}
                      value={customHeight}
                      onChange={(e) => setCustomHeight(Math.max(64, Number(e.target.value) || 64))}
                      dir="ltr"
                      className="w-full h-9 px-2.5 rounded-lg bg-[#0B0E17] border border-white/[0.1] text-xs font-mono tabular-nums text-slate-100 focus:outline-none focus:border-violet-500"
                    />
                  </label>
                </div>
              )}
            </div>

            {/* Samples up to 1024 SPP */}
            {isPathTracing && (
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <label htmlFor="export-samples-range" className="font-semibold text-slate-200">
                    {t.exportModal.samplesLabel}
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={MAX_SAMPLES_LIMIT}
                    disabled={isBusy}
                    value={samples}
                    aria-label={t.exportModal.samplesLabel}
                    onChange={(e) => setSamples(clampSampleCount(Number(e.target.value)))}
                    dir="ltr"
                    data-testid="dimensix-export-samples-input"
                    className="w-20 h-7 px-2 rounded-md bg-[#0B0E17] border border-white/[0.1] text-xs font-mono tabular-nums text-violet-300 text-center focus:outline-none focus:border-violet-500"
                  />
                </div>
                <input
                  id="export-samples-range"
                  disabled={isBusy}
                  type="range"
                  min={1}
                  max={MAX_SAMPLES_LIMIT}
                  step={1}
                  value={samples}
                  onChange={(e) => setSamples(clampSampleCount(parseInt(e.target.value, 10)))}
                  className="w-full dx-range"
                />
                <div className="flex flex-wrap gap-1.5" dir="ltr">
                  {SAMPLE_PRESETS.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      disabled={isBusy}
                      data-testid={`samples-preset-${preset}`}
                      onClick={() => setSamples(preset)}
                      className={`h-7 px-2.5 rounded-md border text-[11px] font-mono tabular-nums transition-colors ${
                        samples === preset
                          ? 'bg-violet-600/30 border-violet-400/60 text-violet-100'
                          : 'bg-[#0B0E17] border-white/[0.08] text-slate-400 hover:text-white'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Pre-Render Output & Memory Summary */}
            <div className="rounded-xl bg-[#0B0E17] border border-white/[0.08] px-3.5 py-2.5 space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">{t.exportModal.outputSummaryLabel}</span>
                <span className="font-mono tabular-nums text-white font-semibold" dir="ltr">
                  {dims.width} × {dims.height} px
                </span>
              </div>
              <div
                className="flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-[11px] text-slate-400 font-mono tabular-nums"
                dir="ltr"
              >
                <span>{dims.megapixels} MP</span>
                <span aria-hidden="true">·</span>
                <span>
                  ~{memoryPlan.estimatedPeakMb} MB RAM
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  {isPathTracing
                    ? `${memoryPlan.tileSize}px tiles (${memoryPlan.strategy === 'tile-streaming' ? 'streaming' : 'progressive'})`
                    : 'Direct WebGL2'}
                </span>
              </div>
            </div>

            {(!memoryPlan.valid || errorMsg) && (
              <p
                className="text-xs text-rose-200 bg-rose-500/10 border border-rose-500/35 rounded-xl px-3 py-2"
                role="alert"
              >
                {errorMsg || memoryPlan.reason}
              </p>
            )}
          </div>
        </div>

        {/* Footer Controls */}
        <div className="px-4 sm:px-5 py-3 border-t border-white/[0.08] flex flex-wrap items-center justify-end gap-2.5 bg-[#0D1019] shrink-0">
          {isBusy ? (
            <>
              {isPathTracing && (
                <button
                  type="button"
                  onClick={handleTogglePause}
                  data-testid="dimensix-export-pause"
                  className="min-h-[40px] px-4 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/45 text-xs font-semibold text-amber-200 flex items-center gap-1.5 whitespace-nowrap shrink-0"
                >
                  {exportState === 'paused' ? (
                    <>
                      <Play className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>{t.exportModal.resumeRender}</span>
                    </>
                  ) : (
                    <>
                      <Pause className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>{t.exportModal.pauseRender}</span>
                    </>
                  )}
                </button>
              )}

              <button
                type="button"
                onClick={handleCancel}
                data-testid="dimensix-export-cancel"
                className="min-h-[40px] px-4 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-xs font-semibold text-rose-200 flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <Square className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{t.exportModal.cancelRender}</span>
              </button>
            </>
          ) : (
            <button
              type="button"
              disabled={!memoryPlan.valid}
              onClick={handleStartRender}
              data-testid="dimensix-export-start"
              className="min-h-[40px] px-4 rounded-xl bg-violet-600 hover:bg-violet-500 disabled:opacity-45 text-xs font-semibold text-white flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Camera className="w-4 h-4" aria-hidden="true" />
              <span>{t.exportModal.startRender}</span>
            </button>
          )}

          {downloadUrl && exportState === 'completed' && (
            <a
              href={downloadUrl}
              download={`dimensix-${frameDims.width}x${frameDims.height}-${isPathTracing ? `${samples}spp` : 'realtime'}.png`}
              data-testid="dimensix-export-download"
              className="min-h-[40px] px-4 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/45 text-xs font-semibold text-cyan-200 flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Download className="w-4 h-4" aria-hidden="true" />
              <span>{t.exportModal.downloadPng}</span>
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
