import { X } from 'lucide-react';
import { useEditor } from '../context/EditorContext';

interface SettingsModalProps {
  open: boolean;
  onClose: () => void;
}

export function SettingsModal({ open, onClose }: SettingsModalProps) {
  const { engine, settings, t } = useEditor();

  if (!open) return null;

  const engines = engine.listRenderEngines();

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="settings-modal-title"
      data-testid="dimensix-settings-modal"
    >
      <div className="w-full max-w-md rounded-2xl bg-[#121622] border border-white/[0.1] overflow-hidden flex flex-col max-h-[88vh]">
        <div className="px-5 py-3.5 border-b border-white/[0.08] flex items-center justify-between">
          <h2 id="settings-modal-title" className="text-sm font-semibold text-white">
            {t.settingsTitle}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="min-h-[36px] min-w-[36px] rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/[0.06]"
          >
            <X className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto dx-scroll space-y-5">
          {/* Active Render Engine Selector */}
          <div className="space-y-2">
            <label
              htmlFor="settings-engine-select"
              className="block text-xs font-semibold text-slate-200"
            >
              {t.renderEngineLabel}
            </label>
            <select
              id="settings-engine-select"
              value={settings.activeEngineId}
              onChange={(e) => engine.setActiveRenderEngine(e.target.value)}
              className="w-full h-10 px-3 rounded-xl bg-[#0B0E17] border border-white/[0.1] text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
            >
              {engines.map((desc) => (
                <option key={desc.id} value={desc.id}>
                  {desc.name} (v{desc.version})
                </option>
              ))}
            </select>
            {engines
              .filter((e) => e.id === settings.activeEngineId)
              .map((active) => (
                <p key={active.id} className="text-[11px] text-slate-400 leading-relaxed">
                  {active.description}
                </p>
              ))}
          </div>

          {/* Viewport Toggles */}
          <div className="pt-4 border-t border-white/[0.08] space-y-2.5">
            <ToggleRow
              label={t.showGrid}
              checked={settings.showGrid}
              onChange={(checked) => engine.updateSettings({ showGrid: checked })}
            />
            <ToggleRow
              label={t.showAxes}
              checked={settings.showAxes}
              onChange={(checked) => engine.updateSettings({ showAxes: checked })}
            />
            <ToggleRow
              label={t.snapToGrid}
              checked={settings.snapToGrid}
              onChange={(checked) => engine.updateSettings({ snapToGrid: checked })}
            />
          </div>

          {/* Camera FOV */}
          <div className="pt-4 border-t border-white/[0.08] space-y-2">
            <div className="flex items-center justify-between text-xs">
              <label htmlFor="settings-fov-range" className="text-slate-300 font-medium">
                {t.cameraFov}
              </label>
              <span className="font-mono tabular-nums text-cyan-300">{settings.fov}°</span>
            </div>
            <input
              id="settings-fov-range"
              type="range"
              min={30}
              max={90}
              step={2}
              value={settings.fov}
              onChange={(e) => engine.updateSettings({ fov: parseInt(e.target.value, 10) })}
              className="w-full dx-range"
            />
          </div>

          {/* Language */}
          <div className="pt-4 border-t border-white/[0.08] space-y-2">
            <span className="block text-xs font-semibold text-slate-200">{t.language}</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => engine.updateSettings({ language: 'ar' })}
                className={`min-h-[40px] rounded-xl text-xs font-medium border transition-colors ${
                  settings.language === 'ar'
                    ? 'bg-violet-600/20 border-violet-500/50 text-white'
                    : 'bg-[#0B0E17] border-white/[0.08] text-slate-400 hover:text-slate-200'
                }`}
              >
                العربية
              </button>
              <button
                type="button"
                onClick={() => engine.updateSettings({ language: 'en' })}
                className={`min-h-[40px] rounded-xl text-xs font-medium border transition-colors ${
                  settings.language === 'en'
                    ? 'bg-violet-600/20 border-violet-500/50 text-white'
                    : 'bg-[#0B0E17] border-white/[0.08] text-slate-400 hover:text-slate-200'
                }`}
              >
                English
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ToggleRow({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}) {
  return (
    <label className="flex items-center justify-between gap-3 min-h-[38px] cursor-pointer">
      <span className="text-xs text-slate-200">{label}</span>
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="w-4 h-4 accent-cyan-400 rounded"
      />
    </label>
  );
}
