import {
  Box,
  Camera,
  Check,
  FolderOpen,
  Redo2,
  Save,
  Settings,
  SlidersHorizontal,
  Undo2,
} from 'lucide-react';
import { useState } from 'react';
import { useEditor } from '../context/EditorContext';

interface TopHeaderBarProps {
  onOpenProjects: () => void;
  onOpenRenderSettings: () => void;
  onOpenExport: () => void;
  onOpenSettings: () => void;
}

export function TopHeaderBar({
  onOpenProjects,
  onOpenRenderSettings,
  onOpenExport,
  onOpenSettings,
}: TopHeaderBarProps) {
  const { engine, project, canUndo, canRedo, isDirty, t } = useEditor();
  const [justSaved, setJustSaved] = useState(false);

  const handleSave = () => {
    engine.saveCurrentProject();
    setJustSaved(true);
    window.setTimeout(() => setJustSaved(false), 1600);
  };

  return (
    <header
      className="h-12 shrink-0 bg-[#0D101A] border-b border-white/[0.08] px-2 sm:px-4 flex items-center justify-between gap-1.5 sm:gap-2 z-30"
      data-testid="dimensix-header"
    >
      {/* Brand + Project Selector */}
      <div className="flex items-center gap-1.5 sm:gap-3 min-w-0">
        <div className="flex items-center gap-1.5 shrink-0">
          <div className="w-7 h-7 rounded-lg bg-violet-600/20 border border-violet-500/40 flex items-center justify-center text-cyan-400">
            <Box className="w-4 h-4" aria-hidden="true" />
          </div>
          <span className="font-semibold text-sm sm:text-base tracking-tight text-white whitespace-nowrap hidden sm:inline">
            {t.appName}
          </span>
        </div>

        <button
          type="button"
          onClick={onOpenProjects}
          aria-label={`${t.projects}: ${project.name}`}
          className="min-h-[36px] px-2 sm:px-2.5 py-1 rounded-lg bg-[#151A28] hover:bg-[#1B2133] border border-white/[0.08] flex items-center gap-1.5 text-xs sm:text-sm text-slate-200 transition-colors min-w-0 max-w-[92px] sm:max-w-[220px]"
        >
          <FolderOpen className="w-3.5 h-3.5 text-violet-400 shrink-0" aria-hidden="true" />
          <span className="truncate font-medium">{project.name}</span>
          {isDirty && (
            <span
              className="text-cyan-400 font-bold shrink-0"
              title={t.unsaved}
              aria-label={t.unsaved}
            >
              *
            </span>
          )}
        </button>
      </div>

      {/* Primary Actions: Undo, Redo, Save, Render Settings, Export Image, Editor Settings */}
      <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
        <button
          type="button"
          onClick={() => engine.undo()}
          disabled={!canUndo}
          aria-label={t.undo}
          title={t.undo}
          className="min-h-[36px] min-w-[34px] sm:min-h-[40px] sm:min-w-[38px] px-1 rounded-lg flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/[0.06] disabled:opacity-35 disabled:pointer-events-none transition-colors"
        >
          <Undo2 className="w-4 h-4" aria-hidden="true" />
        </button>

        <button
          type="button"
          onClick={() => engine.redo()}
          disabled={!canRedo}
          aria-label={t.redo}
          title={t.redo}
          className="min-h-[36px] min-w-[34px] sm:min-h-[40px] sm:min-w-[38px] px-1 rounded-lg flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/[0.06] disabled:opacity-35 disabled:pointer-events-none transition-colors"
        >
          <Redo2 className="w-4 h-4" aria-hidden="true" />
        </button>

        <button
          type="button"
          onClick={handleSave}
          aria-label={t.save}
          className={`min-h-[36px] sm:min-h-[40px] px-2 sm:px-2.5 rounded-lg flex items-center gap-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
            justSaved
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : isDirty
                ? 'bg-violet-600 hover:bg-violet-500 text-white'
                : 'bg-[#161B2A] hover:bg-[#1E2438] text-slate-200 border border-white/[0.08]'
          }`}
        >
          {justSaved ? (
            <Check className="w-3.5 h-3.5" aria-hidden="true" />
          ) : (
            <Save className="w-3.5 h-3.5" aria-hidden="true" />
          )}
          <span className="hidden md:inline">{justSaved ? t.saved : t.save}</span>
        </button>

        <button
          type="button"
          onClick={onOpenRenderSettings}
          aria-label={t.renderSettings}
          title={t.renderSettings}
          className="min-h-[36px] sm:min-h-[40px] px-2 sm:px-2.5 rounded-lg bg-[#161B2A] hover:bg-[#1E2438] border border-white/[0.08] text-slate-200 flex items-center gap-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0"
        >
          <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-300 shrink-0" aria-hidden="true" />
          <span className="hidden sm:inline text-[11px] sm:text-xs">{t.renderButtonShort}</span>
        </button>

        <button
          type="button"
          onClick={onOpenExport}
          aria-label={t.exportImage}
          title={t.exportImage}
          className="min-h-[36px] sm:min-h-[40px] px-2.5 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-cyan-200 flex items-center gap-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
        >
          <Camera className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span className="text-[11px] sm:text-xs">{t.exportShort}</span>
        </button>

        <button
          type="button"
          onClick={onOpenSettings}
          aria-label={t.settings}
          title={t.settings}
          className="min-h-[36px] min-w-[34px] sm:min-h-[40px] sm:min-w-[38px] px-1 rounded-lg flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/[0.06] transition-colors"
        >
          <Settings className="w-4 h-4" aria-hidden="true" />
        </button>
      </div>
    </header>
  );
}
