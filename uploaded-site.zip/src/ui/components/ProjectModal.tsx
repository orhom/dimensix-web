import { useState } from 'react';
import { FolderPlus, Trash2, X } from 'lucide-react';
import type { ProjectTemplateId } from '../../core/project/ProjectTypes';
import { useEditor } from '../context/EditorContext';

interface ProjectModalProps {
  open: boolean;
  onClose: () => void;
}

export function ProjectModal({ open, onClose }: ProjectModalProps) {
  const { engine, project, settings, t } = useEditor();
  const [newName, setNewName] = useState('');
  const [template, setTemplate] = useState<ProjectTemplateId>('studio-starter');
  const [renameDraft, setRenameDraft] = useState(project.name);
  const [projects, setProjects] = useState(() => engine.listProjects());

  if (!open) return null;

  const refreshList = () => {
    setProjects(engine.listProjects());
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const created = engine.createProject(newName.trim() || t.newProjectName, template);
    setNewName('');
    setRenameDraft(created.name);
    refreshList();
    onClose();
  };

  const handleRename = (e: React.FormEvent) => {
    e.preventDefault();
    if (!renameDraft.trim()) return;
    engine.renameCurrentProject(renameDraft.trim());
    refreshList();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="project-modal-title"
      data-testid="dimensix-project-modal"
    >
      <div className="w-full max-w-lg rounded-2xl bg-[#121622] border border-white/[0.1] overflow-hidden flex flex-col max-h-[88vh]">
        {/* Modal Header */}
        <div className="px-5 py-3.5 border-b border-white/[0.08] flex items-center justify-between">
          <h2 id="project-modal-title" className="text-sm font-semibold text-white">
            {t.projectManagerTitle}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="min-h-[36px] min-w-[36px] rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/[0.06]"
          >
            <X className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto dx-scroll space-y-5">
          {/* Rename Current Project */}
          <form onSubmit={handleRename} className="space-y-2">
            <label htmlFor="active-project-rename" className="block text-xs font-medium text-slate-300">
              {t.renameProject}
            </label>
            <div className="flex gap-2">
              <input
                id="active-project-rename"
                type="text"
                value={renameDraft}
                onChange={(e) => setRenameDraft(e.target.value)}
                className="flex-1 h-10 px-3 rounded-xl bg-[#0B0E17] border border-white/[0.1] text-sm text-white focus:outline-none focus:border-violet-500"
              />
              <button
                type="submit"
                className="min-h-[40px] px-4 rounded-xl bg-[#1A2033] hover:bg-[#232B42] border border-white/[0.1] text-xs font-medium text-slate-100 whitespace-nowrap"
              >
                {t.confirm}
              </button>
            </div>
          </form>

          {/* Create New Project */}
          <form
            onSubmit={handleCreate}
            className="pt-4 border-t border-white/[0.08] space-y-3"
          >
            <h3 className="text-xs font-semibold text-slate-200 flex items-center gap-2">
              <FolderPlus className="w-4 h-4 text-cyan-400" aria-hidden="true" />
              <span>{t.createProject}</span>
            </h3>

            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder={t.newProjectName}
              aria-label={t.newProjectName}
              className="w-full h-10 px-3 rounded-xl bg-[#0B0E17] border border-white/[0.1] text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
            />

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setTemplate('validation-showcase')}
                className={`min-h-[40px] px-2.5 rounded-xl text-[11px] font-medium border transition-colors ${
                  template === 'validation-showcase'
                    ? 'bg-cyan-500/20 border-cyan-500/50 text-white'
                    : 'bg-[#0B0E17] border-white/[0.08] text-slate-400 hover:text-slate-200'
                }`}
              >
                {t.templateShowcase}
              </button>
              <button
                type="button"
                onClick={() => setTemplate('studio-starter')}
                className={`min-h-[40px] px-2.5 rounded-xl text-[11px] font-medium border transition-colors ${
                  template === 'studio-starter'
                    ? 'bg-violet-600/20 border-violet-500/50 text-white'
                    : 'bg-[#0B0E17] border-white/[0.08] text-slate-400 hover:text-slate-200'
                }`}
              >
                {t.templateStarter}
              </button>
              <button
                type="button"
                onClick={() => setTemplate('empty')}
                className={`min-h-[40px] px-2.5 rounded-xl text-[11px] font-medium border transition-colors ${
                  template === 'empty'
                    ? 'bg-violet-600/20 border-violet-500/50 text-white'
                    : 'bg-[#0B0E17] border-white/[0.08] text-slate-400 hover:text-slate-200'
                }`}
              >
                {t.templateEmpty}
              </button>
            </div>

            <button
              type="submit"
              className="w-full min-h-[42px] rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold transition-colors"
            >
              {t.createProject}
            </button>
          </form>

          {/* Saved Projects List */}
          <div className="pt-4 border-t border-white/[0.08] space-y-2.5">
            <h3 className="text-xs font-semibold text-slate-200">{t.savedProjects}</h3>

            <div className="space-y-2">
              {projects.map((item) => {
                const isActive = item.id === project.id;
                const formattedDate = new Intl.DateTimeFormat(
                  settings.language === 'ar' ? 'ar-EG' : 'en-US',
                  { dateStyle: 'short', timeStyle: 'short' },
                ).format(new Date(item.updatedAt));

                return (
                  <div
                    key={item.id}
                    className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${
                      isActive
                        ? 'bg-violet-600/15 border-violet-500/40'
                        : 'bg-[#0B0E17] border-white/[0.08]'
                    }`}
                  >
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-white truncate">{item.name}</p>
                      <p className="text-[11px] text-slate-400 tabular-nums truncate">
                        {item.nodeCount} {t.nodesCount} · {formattedDate}
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {isActive ? (
                        <span className="px-2.5 py-1 text-[11px] font-medium text-cyan-300">
                          {t.active}
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            engine.openProject(item.id);
                            onClose();
                          }}
                          className="min-h-[34px] px-3 rounded-lg bg-[#1A2033] hover:bg-[#232B42] text-xs font-medium text-slate-100"
                        >
                          {t.open}
                        </button>
                      )}

                      {projects.length > 1 && (
                        <button
                          type="button"
                          onClick={() => {
                            engine.deleteProject(item.id);
                            refreshList();
                          }}
                          aria-label={`${t.delete} ${item.name}`}
                          className="min-h-[34px] min-w-[34px] rounded-lg flex items-center justify-center text-slate-400 hover:text-red-400 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
