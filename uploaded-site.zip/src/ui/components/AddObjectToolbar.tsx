import { useRef, useState } from 'react';
import {
  Box,
  ChevronUp,
  Circle,
  Cone,
  Copy,
  Cylinder,
  Flashlight,
  FolderPlus,
  Lightbulb,
  RectangleHorizontal,
  Square,
  Sun,
  Torus,
  Trash2,
  Upload,
  Video,
} from 'lucide-react';
import type { NodeType } from '../../core/scene/SceneNode';
import { useEditor } from '../context/EditorContext';

interface AddObjectToolbarProps {
  compact?: boolean;
  onActionDone?: () => void;
}

export function AddObjectToolbar({ compact = false, onActionDone }: AddObjectToolbarProps) {
  const { engine, selectedNode, clearImportError, t } = useEditor();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [lightsOpen, setLightsOpen] = useState(false);
  const [importing, setImporting] = useState(false);

  const meshItems: Array<{ type: NodeType; label: string; icon: typeof Box }> = [
    { type: 'box', label: t.nodeTypes.box, icon: Box },
    { type: 'sphere', label: t.nodeTypes.sphere, icon: Circle },
    { type: 'cylinder', label: t.nodeTypes.cylinder, icon: Cylinder },
    { type: 'cone', label: t.nodeTypes.cone, icon: Cone },
    { type: 'torus', label: t.nodeTypes.torus, icon: Torus },
    { type: 'plane', label: t.nodeTypes.plane, icon: Square },
    { type: 'group', label: t.nodeTypes.group, icon: FolderPlus },
    { type: 'camera', label: t.nodeTypes.camera, icon: Video },
  ];

  const lightItems: Array<{ type: NodeType; label: string; icon: typeof Lightbulb }> = [
    { type: 'pointLight', label: t.nodeTypes.pointLight, icon: Lightbulb },
    { type: 'directionalLight', label: t.nodeTypes.directionalLight, icon: Sun },
    { type: 'spotLight', label: t.nodeTypes.spotLight, icon: Flashlight },
    { type: 'areaLight', label: t.nodeTypes.areaLight, icon: RectangleHorizontal },
  ];

  const handleAdd = (type: NodeType) => {
    const parentId = selectedNode?.type === 'group' ? selectedNode.id : null;
    engine.addNode(type, undefined, parentId);
    setLightsOpen(false);
    onActionDone?.();
  };

  const handleFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    clearImportError();
    setImporting(true);
    try {
      await engine.importModelFile(file);
      onActionDone?.();
    } catch {
      // Explicit error event emitted by EditorEngine and shown in ViewportCanvas
    } finally {
      setImporting(false);
    }
  };

  const triggerFileInput = () => {
    setLightsOpen(false);
    fileInputRef.current?.click();
  };

  const hiddenFileInput = (
    <input
      ref={fileInputRef}
      type="file"
      accept=".glb,.gltf,.obj,.stl,.fbx"
      onChange={handleFileSelected}
      className="hidden"
      data-testid="dimensix-model-file-input"
      aria-label={t.importModel}
    />
  );

  if (compact) {
    return (
      <div className="space-y-3" data-testid="dimensix-add-toolbar">
        {hiddenFileInput}

        <div className="grid grid-cols-4 gap-2">
          {meshItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.type}
                type="button"
                onClick={() => handleAdd(item.type)}
                className="min-h-[54px] px-2 py-2 rounded-xl bg-[#161B29] hover:bg-[#1E2438] active:scale-[0.98] border border-white/[0.08] flex flex-col items-center justify-center gap-1 text-slate-200 transition-all"
              >
                <Icon className="w-4 h-4 text-cyan-400" aria-hidden="true" />
                <span className="text-[11px] font-medium truncate max-w-full">{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* All 4 Light Types */}
        <div className="pt-2 border-t border-white/[0.08] space-y-1.5">
          <p className="text-[11px] font-medium text-slate-400">{t.lightsMenu}</p>
          <div className="grid grid-cols-4 gap-2">
            {lightItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.type}
                  type="button"
                  onClick={() => handleAdd(item.type)}
                  className="min-h-[52px] px-1.5 py-2 rounded-xl bg-[#161B29] hover:bg-amber-500/10 border border-white/[0.08] flex flex-col items-center justify-center gap-1 text-slate-200 transition-colors"
                >
                  <Icon className="w-4 h-4 text-amber-300" aria-hidden="true" />
                  <span className="text-[10px] font-medium truncate max-w-full">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Import 3D Model */}
        <button
          type="button"
          disabled={importing}
          onClick={triggerFileInput}
          className="w-full min-h-[44px] px-3 rounded-xl bg-violet-600/20 hover:bg-violet-600/30 border border-violet-500/40 flex items-center justify-center gap-2 text-xs font-semibold text-violet-100 disabled:opacity-50"
        >
          <Upload className="w-4 h-4 text-cyan-300" aria-hidden="true" />
          <span>{importing ? t.importing : t.importModel}</span>
          <span className="text-[10px] text-slate-400 font-normal" dir="ltr">
            (GLB, GLTF, OBJ, STL, FBX)
          </span>
        </button>

        {selectedNode && (
          <div className="flex items-center gap-2 pt-2 border-t border-white/[0.08]">
            <button
              type="button"
              onClick={() => {
                engine.duplicateSelected();
                onActionDone?.();
              }}
              className="flex-1 min-h-[42px] px-3 rounded-xl bg-[#161B29] hover:bg-[#1E2438] border border-white/[0.08] flex items-center justify-center gap-2 text-xs font-medium text-slate-200"
            >
              <Copy className="w-3.5 h-3.5 text-violet-400" aria-hidden="true" />
              <span>{t.duplicate}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                engine.removeNode(selectedNode.id);
                onActionDone?.();
              }}
              className="flex-1 min-h-[42px] px-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 flex items-center justify-center gap-2 text-xs font-medium text-red-300"
            >
              <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t.delete}</span>
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="relative max-w-full" data-testid="dimensix-add-toolbar">
      {hiddenFileInput}

      {/* Lights Popover Menu above toolbar */}
      {lightsOpen && (
        <div
          className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 z-30 p-1.5 rounded-xl bg-[#121624] border border-amber-500/30 shadow-2xl flex items-center gap-1"
          role="menu"
          aria-label={t.lightsMenu}
          data-testid="dimensix-lights-menu"
        >
          {lightItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.type}
                type="button"
                role="menuitem"
                onClick={() => handleAdd(item.type)}
                className="min-h-[34px] px-2.5 py-1.5 rounded-lg hover:bg-amber-500/15 text-slate-100 flex items-center gap-1.5 text-xs font-medium whitespace-nowrap"
              >
                <Icon className="w-3.5 h-3.5 text-amber-300 shrink-0" aria-hidden="true" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      )}

      <div
        className="flex items-center gap-0.5 p-1 rounded-2xl bg-[#10141F]/95 border border-white/[0.08] overflow-x-auto dx-scroll max-w-full"
        role="toolbar"
        aria-label={t.addElements}
      >
        {meshItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.type}
              type="button"
              onClick={() => handleAdd(item.type)}
              aria-label={`${t.addElements}: ${item.label}`}
              title={item.label}
              className="min-h-[32px] px-1.5 py-1 rounded-lg hover:bg-white/[0.06] text-slate-200 flex items-center gap-1 text-[11px] font-medium transition-colors whitespace-nowrap shrink-0"
            >
              <Icon className="w-3.5 h-3.5 text-cyan-400 shrink-0" aria-hidden="true" />
              <span className="hidden 2xl:inline">{item.label}</span>
            </button>
          );
        })}

        {/* Lights Dropdown Trigger */}
        <button
          type="button"
          onClick={() => setLightsOpen((v) => !v)}
          aria-expanded={lightsOpen}
          aria-label={t.lightsMenu}
          title={t.lightsMenu}
          className={`min-h-[32px] px-2 py-1 rounded-lg flex items-center gap-1 text-[11px] font-medium transition-colors whitespace-nowrap shrink-0 ${
            lightsOpen
              ? 'bg-amber-500/20 text-amber-200 border border-amber-500/40'
              : 'hover:bg-white/[0.06] text-amber-300 border border-transparent'
          }`}
        >
          <Lightbulb className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>{t.lightsMenu}</span>
          <ChevronUp
            className={`w-3 h-3 transition-transform ${lightsOpen ? 'rotate-180' : ''}`}
            aria-hidden="true"
          />
        </button>

        {/* Import 3D Model Button */}
        <button
          type="button"
          disabled={importing}
          onClick={triggerFileInput}
          aria-label={t.importModel}
          title={t.importModel}
          className="min-h-[32px] px-2 py-1 rounded-lg bg-violet-600/20 hover:bg-violet-600/35 border border-violet-500/35 text-violet-200 flex items-center gap-1 text-[11px] font-medium transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
        >
          <Upload className="w-3.5 h-3.5 text-cyan-300 shrink-0" aria-hidden="true" />
          <span>{importing ? t.importing : t.importModel}</span>
        </button>

        {selectedNode && (
          <>
            <div className="w-px h-4 bg-white/10 mx-0.5 shrink-0" aria-hidden="true" />
            <button
              type="button"
              onClick={() => engine.duplicateSelected()}
              aria-label={t.duplicate}
              title={t.duplicate}
              className="min-h-[32px] min-w-[32px] px-1.5 rounded-lg hover:bg-violet-500/15 text-violet-300 flex items-center justify-center transition-colors shrink-0"
            >
              <Copy className="w-3.5 h-3.5" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={() => engine.removeNode(selectedNode.id)}
              aria-label={`${t.delete} ${selectedNode.name}`}
              title={t.delete}
              className="min-h-[32px] min-w-[32px] px-1.5 rounded-lg hover:bg-red-500/15 text-red-400 flex items-center justify-center transition-colors shrink-0"
            >
              <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
            </button>
          </>
        )}
      </div>
    </div>
  );
}
