import { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ChevronDown,
  ChevronUp,
  Compass,
  Crosshair,
  Maximize2,
  Move,
  Orbit,
  RotateCcw,
  RotateCw,
  Sparkles,
  X,
  Zap,
} from 'lucide-react';
import type { CameraPreset, TransformMode } from '../../core/rendering/IRenderEngine';
import { PATH_TRACING_DESCRIPTOR } from '../../core/rendering/PathTracingViewportEngine';
import { THREE_FOUNDATION_DESCRIPTOR } from '../../core/rendering/ThreeViewportEngine';
import { useEditor } from '../context/EditorContext';

export function ViewportCanvas() {
  const {
    engine,
    snapshot,
    selectedNode,
    transformMode,
    cameraMode,
    activeEngineId,
    pathTracerStatus,
    importError,
    clearImportError,
    t,
  } = useEditor();
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [engineError, setEngineError] = useState<string | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    engine.attachViewport(container, (message) => {
      setEngineError(message);
    });

    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        if (width > 0 && height > 0) {
          engine.resizeViewport(width, height);
        }
      }
    });
    observer.observe(container);

    return () => {
      observer.disconnect();
      engine.detachViewport();
    };
  }, [engine]);

  const modes: Array<{ id: TransformMode; label: string; icon: typeof Move }> = [
    { id: 'translate', label: t.moveMode, icon: Move },
    { id: 'rotate', label: t.rotateMode, icon: RotateCw },
    { id: 'scale', label: t.scaleMode, icon: Maximize2 },
  ];

  const cameraPresets: Array<{ id: CameraPreset; label: string }> = [
    { id: 'perspective', label: t.cameraPerspective },
    { id: 'top', label: t.cameraTop },
    { id: 'front', label: t.cameraFront },
  ];

  const isPathTracing = activeEngineId === PATH_TRACING_DESCRIPTOR.id;

  return (
    <div
      className="relative w-full h-full bg-[#0B0E17] overflow-hidden"
      data-testid="dimensix-viewport-container"
      data-node-count={snapshot.nodes.length}
      data-selected-id={selectedNode?.id ?? ''}
      data-camera-mode={cameraMode}
      data-active-engine={activeEngineId}
    >
      {/* Dedicated WebGL Canvas Mount Container */}
      <div ref={mountRef} className="w-full h-full" />

      {/* Top Overlay: Transform Mode, Render Engine Switch & Camera Controls */}
      <div className="absolute top-2.5 inset-x-2.5 flex flex-wrap items-center justify-between gap-1.5 sm:gap-2 pointer-events-none z-10">
        <div className="flex flex-wrap items-center gap-1.5 pointer-events-auto">
          {/* Transform Modes */}
          <div
            className="flex items-center gap-1 p-1 rounded-xl bg-[#10141F]/95 border border-white/[0.08]"
            role="toolbar"
            aria-label={t.transform}
          >
            {modes.map((mode) => {
              const Icon = mode.icon;
              const active = transformMode === mode.id;
              return (
                <button
                  key={mode.id}
                  type="button"
                  onClick={() => engine.setTransformMode(mode.id)}
                  aria-label={mode.label}
                  aria-pressed={active}
                  className={`min-h-[32px] sm:min-h-[34px] px-2 rounded-lg flex items-center gap-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                      : 'text-slate-300 hover:text-white hover:bg-white/[0.05] border border-transparent'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" aria-hidden="true" />
                  <span className="hidden lg:inline">{mode.label}</span>
                </button>
              );
            })}
          </div>

          {/* Instant Engine Switcher: Real-Time vs Path Tracing */}
          <div
            className="flex items-center gap-0.5 p-1 rounded-xl bg-[#10141F]/95 border border-white/[0.08]"
            role="group"
            aria-label={t.renderEngineLabel}
            data-testid="dimensix-engine-switcher"
          >
            <button
              type="button"
              onClick={() => engine.setActiveRenderEngine(THREE_FOUNDATION_DESCRIPTOR.id)}
              aria-pressed={!isPathTracing}
              className={`min-h-[32px] sm:min-h-[34px] px-2.5 rounded-lg flex items-center gap-1.5 text-[11px] sm:text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                !isPathTracing
                  ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-500/45'
                  : 'text-slate-400 hover:text-white border border-transparent'
              }`}
            >
              <Zap className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t.engineRealtime}</span>
            </button>

            <button
              type="button"
              onClick={() => engine.setActiveRenderEngine(PATH_TRACING_DESCRIPTOR.id)}
              aria-pressed={isPathTracing}
              className={`min-h-[32px] sm:min-h-[34px] px-2.5 rounded-lg flex items-center gap-1.5 text-[11px] sm:text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                isPathTracing
                  ? 'bg-violet-600/30 text-violet-200 border border-violet-500/55'
                  : 'text-slate-400 hover:text-white border border-transparent'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t.enginePathTracing}</span>
            </button>
          </div>
        </div>

        {/* Camera Mode, Presets, Focus & Reset */}
        <div className="flex items-center gap-1 p-1 rounded-xl bg-[#10141F]/95 border border-white/[0.08] pointer-events-auto max-w-full overflow-x-auto dx-scroll">
          {/* Orbit / Free Switch */}
          <div className="flex items-center gap-0.5 bg-[#0B0E17] rounded-lg p-0.5 border border-white/[0.06] shrink-0">
            <button
              type="button"
              onClick={() => engine.setCameraMode('orbit')}
              aria-label={t.orbitCameraMode}
              aria-pressed={cameraMode === 'orbit'}
              className={`min-h-[30px] px-2 rounded-md flex items-center gap-1 text-[11px] font-medium transition-colors whitespace-nowrap ${
                cameraMode === 'orbit'
                  ? 'bg-violet-600/30 text-violet-200 border border-violet-500/40'
                  : 'text-slate-400 hover:text-white border border-transparent'
              }`}
            >
              <Orbit className="w-3 h-3" aria-hidden="true" />
              <span>{t.orbitCameraMode}</span>
            </button>
            <button
              type="button"
              onClick={() => engine.setCameraMode('free')}
              aria-label={t.freeCameraMode}
              aria-pressed={cameraMode === 'free'}
              className={`min-h-[30px] px-2 rounded-md flex items-center gap-1 text-[11px] font-medium transition-colors whitespace-nowrap ${
                cameraMode === 'free'
                  ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-white border border-transparent'
              }`}
            >
              <Compass className="w-3 h-3" aria-hidden="true" />
              <span>{t.freeCameraMode}</span>
            </button>
          </div>

          <div className="w-px h-4 bg-white/10 mx-0.5 shrink-0 hidden sm:block" aria-hidden="true" />

          {cameraPresets.map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => engine.setCameraPreset(preset.id)}
              className="min-h-[32px] px-2 rounded-lg text-[11px] sm:text-xs font-medium text-slate-300 hover:text-white hover:bg-white/[0.06] transition-colors whitespace-nowrap shrink-0"
            >
              {preset.label}
            </button>
          ))}

          <button
            type="button"
            onClick={() => engine.focusSelected()}
            aria-label={t.focusSelected}
            title={t.focusSelected}
            className="min-h-[32px] min-w-[32px] px-2 rounded-lg flex items-center justify-center text-violet-300 hover:text-white hover:bg-violet-500/20 transition-colors shrink-0"
          >
            <Crosshair className="w-3.5 h-3.5" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={() => engine.resetCamera()}
            aria-label={t.resetCamera}
            title={t.resetCamera}
            className="min-h-[32px] min-w-[32px] px-2 rounded-lg flex items-center justify-center text-cyan-300 hover:text-white hover:bg-cyan-500/20 transition-colors shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
        </div>
      </div>

      {/* Path Tracing Progressive Status Bar */}
      {isPathTracing && pathTracerStatus && (
        <div
          className="absolute top-14 start-2.5 z-10 px-2.5 py-1 rounded-lg bg-[#10141F]/95 border border-violet-500/35 flex items-center gap-2 text-[11px] text-slate-200 pointer-events-none"
          data-testid="dimensix-pt-status"
          data-pt-mode={pathTracerStatus.mode}
          data-pt-samples={pathTracerStatus.samples}
          data-pt-cap={pathTracerStatus.sampleCap}
        >
          <span
            className={
              pathTracerStatus.mode === 'interactive'
                ? 'text-amber-300 font-medium'
                : pathTracerStatus.mode === 'idle'
                  ? 'text-emerald-300 font-medium'
                  : 'text-violet-300 font-medium'
            }
          >
            {pathTracerStatus.mode === 'interactive'
              ? t.ptModeInteractive
              : pathTracerStatus.mode === 'idle'
                ? t.ptModeIdle
                : t.ptModeConverging}
          </span>
          <span className="text-slate-500">·</span>
          <span className="font-mono tabular-nums text-cyan-300" dir="ltr">
            {pathTracerStatus.samples}/{pathTracerStatus.targetSamples} {t.ptSamplesLabel}
          </span>
          <span className="text-slate-500 hidden sm:inline">·</span>
          <span className="font-mono tabular-nums text-slate-400 hidden sm:inline" dir="ltr">
            {pathTracerStatus.triangleCount.toLocaleString()} tris
          </span>
        </div>
      )}

      {/* Explicit Model Import Error Banner */}
      {importError && (
        <div
          role="alert"
          data-testid="dimensix-import-error"
          className="absolute top-16 inset-x-3 sm:inset-x-auto sm:end-3 sm:max-w-sm z-30 p-3 rounded-xl bg-[#1C1219] border border-red-500/45 text-red-100 flex items-start gap-2.5 shadow-xl"
        >
          <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" aria-hidden="true" />
          <p className="text-xs leading-relaxed flex-1">{importError}</p>
          <button
            type="button"
            onClick={clearImportError}
            aria-label={t.close}
            className="min-h-[28px] min-w-[28px] rounded-lg flex items-center justify-center text-red-300 hover:bg-red-500/20 shrink-0"
          >
            <X className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
        </div>
      )}

      {/* Compact Free-Camera Touch Pad (visible only in Free mode) */}
      {cameraMode === 'free' && (
        <div
          className="absolute bottom-16 end-3 z-20 p-2 rounded-2xl bg-[#10141F]/95 border border-cyan-500/30 flex items-center gap-2 pointer-events-auto shadow-lg"
          data-testid="dimensix-free-cam-pad"
          dir="ltr"
        >
          <div className="grid grid-cols-3 gap-1">
            <span />
            <button
              type="button"
              onClick={() => engine.moveCameraFree(0.75, 0, 0)}
              aria-label={t.freeMoveForward}
              title={t.freeMoveForward}
              className="w-9 h-9 rounded-lg bg-[#161B29] hover:bg-cyan-500/25 active:scale-95 border border-white/[0.08] flex items-center justify-center text-slate-200"
            >
              <ArrowUp className="w-4 h-4" aria-hidden="true" />
            </button>
            <span />
            <button
              type="button"
              onClick={() => engine.moveCameraFree(0, -0.75, 0)}
              aria-label={t.freeMoveLeft}
              title={t.freeMoveLeft}
              className="w-9 h-9 rounded-lg bg-[#161B29] hover:bg-cyan-500/25 active:scale-95 border border-white/[0.08] flex items-center justify-center text-slate-200"
            >
              <ArrowLeft className="w-4 h-4" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={() => engine.moveCameraFree(-0.75, 0, 0)}
              aria-label={t.freeMoveBackward}
              title={t.freeMoveBackward}
              className="w-9 h-9 rounded-lg bg-[#161B29] hover:bg-cyan-500/25 active:scale-95 border border-white/[0.08] flex items-center justify-center text-slate-200"
            >
              <ArrowDown className="w-4 h-4" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={() => engine.moveCameraFree(0, 0.75, 0)}
              aria-label={t.freeMoveRight}
              title={t.freeMoveRight}
              className="w-9 h-9 rounded-lg bg-[#161B29] hover:bg-cyan-500/25 active:scale-95 border border-white/[0.08] flex items-center justify-center text-slate-200"
            >
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>

          <div className="flex flex-col gap-1 border-l border-white/[0.08] pl-2">
            <button
              type="button"
              onClick={() => engine.moveCameraFree(0, 0, 0.75)}
              aria-label={t.freeMoveUp}
              title={t.freeMoveUp}
              className="w-9 h-9 rounded-lg bg-[#161B29] hover:bg-violet-500/25 active:scale-95 border border-white/[0.08] flex items-center justify-center text-violet-300"
            >
              <ChevronUp className="w-4 h-4" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={() => engine.moveCameraFree(0, 0, -0.75)}
              aria-label={t.freeMoveDown}
              title={t.freeMoveDown}
              className="w-9 h-9 rounded-lg bg-[#161B29] hover:bg-violet-500/25 active:scale-95 border border-white/[0.08] flex items-center justify-center text-violet-300"
            >
              <ChevronDown className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>
        </div>
      )}

      {/* Empty Scene Guidance */}
      {snapshot.nodes.length === 0 && !engineError && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none p-6">
          <p className="px-4 py-2.5 rounded-xl bg-[#10141F]/95 border border-white/[0.08] text-xs sm:text-sm text-slate-300 text-center max-w-xs">
            {t.emptySceneHint}
          </p>
        </div>
      )}

      {/* WebGL Error State */}
      {engineError && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#090B10]/95 p-6 z-20">
          <div className="max-w-sm rounded-2xl bg-[#141824] border border-red-500/30 p-5 text-center space-y-2">
            <p className="text-sm font-semibold text-red-300">WebGL Viewport Notice</p>
            <p className="text-xs text-slate-300">{engineError}</p>
          </div>
        </div>
      )}
    </div>
  );
}
