import { useState } from 'react';
import {
  Box,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Circle,
  Cone,
  Cylinder,
  Eye,
  EyeOff,
  Flashlight,
  Folder,
  FolderPlus,
  Lightbulb,
  Package,
  RectangleHorizontal,
  Square,
  Sun,
  Torus,
  Trash2,
  Video,
} from 'lucide-react';
import { isLightNodeType, type NodeType } from '../../core/scene/SceneNode';
import { useEditor } from '../context/EditorContext';

const NODE_ICONS: Record<NodeType, typeof Box> = {
  box: Box,
  sphere: Circle,
  cylinder: Cylinder,
  cone: Cone,
  torus: Torus,
  plane: Square,
  group: Folder,
  pointLight: Lightbulb,
  directionalLight: Sun,
  spotLight: Flashlight,
  areaLight: RectangleHorizontal,
  camera: Video,
  model: Package,
};

interface HierarchyPanelProps {
  onSelectDone?: () => void;
}

export function HierarchyPanel({ onSelectDone }: HierarchyPanelProps) {
  const { engine, snapshot, settings, t } = useEditor();
  const [collapsedGroups, setCollapsedGroups] = useState<Set<string>>(new Set());

  const toggleGroup = (id: string) => {
    setCollapsedGroups((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const renderTree = (parentId: string | null, depth: number) => {
    const children = snapshot.nodes.filter((n) => n.parentId === parentId);
    if (children.length === 0) return null;

    return children.map((node) => {
      const hasChildren = snapshot.nodes.some((n) => n.parentId === node.id);
      const isCollapsed = collapsedGroups.has(node.id);
      const isSelected = snapshot.selectedId === node.id;
      const Icon = NODE_ICONS[node.type] ?? Box;
      const CollapseIcon = isCollapsed
        ? settings.language === 'ar'
          ? ChevronLeft
          : ChevronRight
        : ChevronDown;

      return (
        <div key={node.id}>
          <div
            className={`group flex items-center gap-1 rounded-lg px-1.5 py-1 transition-colors ${
              isSelected
                ? 'bg-violet-600/20 border border-violet-500/40 text-white'
                : 'border border-transparent hover:bg-white/[0.04] text-slate-300'
            }`}
            style={{ paddingInlineStart: `${depth * 14 + 6}px` }}
          >
            {hasChildren ? (
              <button
                type="button"
                onClick={() => toggleGroup(node.id)}
                aria-label={`${isCollapsed ? t.show : t.hide} ${node.name}`}
                className="min-h-[32px] min-w-[26px] flex items-center justify-center rounded hover:bg-white/10 text-slate-400 shrink-0"
              >
                <CollapseIcon className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            ) : (
              <span className="w-[26px] shrink-0" aria-hidden="true" />
            )}

            <button
              type="button"
              onClick={() => {
                engine.selectNode(node.id);
                onSelectDone?.();
              }}
              className="flex-1 min-w-0 min-h-[34px] flex items-center gap-2 text-start"
            >
              <Icon
                className={`w-3.5 h-3.5 shrink-0 ${
                  isLightNodeType(node.type)
                    ? 'text-amber-300'
                    : node.type === 'model'
                      ? 'text-violet-300'
                      : isSelected
                        ? 'text-cyan-400'
                        : 'text-slate-400'
                }`}
                aria-hidden="true"
              />
              <span
                dir="auto"
                className={`text-xs truncate block min-w-0 flex-1 text-start ${
                  !node.visible ? 'opacity-45 line-through' : ''
                }`}
              >
                {node.name}
              </span>
            </button>

            <div className="flex items-center gap-0.5 shrink-0">
              <button
                type="button"
                onClick={() => engine.toggleVisibility(node.id)}
                aria-label={`${node.visible ? t.hide : t.show} ${node.name}`}
                title={node.visible ? t.hide : t.show}
                className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded-md text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
              >
                {node.visible ? (
                  <Eye className="w-3.5 h-3.5" aria-hidden="true" />
                ) : (
                  <EyeOff className="w-3.5 h-3.5 text-slate-500" aria-hidden="true" />
                )}
              </button>
              <button
                type="button"
                onClick={() => engine.removeNode(node.id)}
                aria-label={`${t.delete} ${node.name}`}
                title={t.delete}
                className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded-md text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            </div>
          </div>

          {hasChildren && !isCollapsed && renderTree(node.id, depth + 1)}
        </div>
      );
    });
  };

  return (
    <div className="flex flex-col h-full min-h-0" data-testid="dimensix-hierarchy-panel">
      <div className="px-3 py-2.5 border-b border-white/[0.08] flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <h2 className="text-xs font-semibold text-slate-200 truncate">{t.hierarchy}</h2>
          <span className="text-[11px] text-slate-400 tabular-nums">
            · {snapshot.nodes.length}
          </span>
        </div>
        <button
          type="button"
          onClick={() => engine.addNode('group')}
          aria-label={t.nodeTypes.group}
          title={t.nodeTypes.group}
          className="min-h-[32px] px-2 rounded-lg bg-[#161B29] hover:bg-[#1E2438] border border-white/[0.08] flex items-center gap-1 text-[11px] text-slate-200 transition-colors shrink-0"
        >
          <FolderPlus className="w-3.5 h-3.5 text-cyan-400" aria-hidden="true" />
          <span>{t.nodeTypes.group}</span>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto dx-scroll p-2 space-y-0.5">
        {snapshot.nodes.length === 0 ? (
          <p className="text-xs text-slate-500 text-center py-8 px-3">{t.emptySceneHint}</p>
        ) : (
          renderTree(null, 0)
        )}
      </div>
    </div>
  );
}
