import { useState } from 'react';
import {
  Aperture,
  Cpu,
  RotateCcw,
  SlidersHorizontal,
  SunMedium,
  X,
} from 'lucide-react';
import type {
  AntiAliasingMode,
  QualityLevel,
  RenderPresetId,
  RenderQualityLevel,
  RenderResolutionPreset,
  ShadowQualityLevel,
  ShadowResolutionSize,
} from '../../core/rendering/RenderSettings';
import { useEditor } from '../context/EditorContext';

interface RenderSettingsModalProps {
  open: boolean;
  onClose: () => void;
}

type RenderTab = 'image' | 'lighting' | 'performance';

export function RenderSettingsModal({ open, onClose }: RenderSettingsModalProps) {
  const { engine, renderSettings, t } = useEditor();
  const [activeTab, setActiveTab] = useState<RenderTab>('image');
  const rp = t.renderPanel;

  if (!open) return null;

  const tabs: Array<{ id: RenderTab; label: string; icon: typeof Aperture }> = [
    { id: 'image', label: rp.groupImageQuality, icon: Aperture },
    { id: 'lighting', label: rp.groupLightingVisual, icon: SunMedium },
    { id: 'performance', label: rp.groupPerformance, icon: Cpu },
  ];

  const presets: Array<{ id: RenderPresetId; label: string }> = [
    { id: 'performance', label: rp.presetPerformance },
    { id: 'balanced', label: rp.presetBalanced },
    { id: 'cinematic', label: rp.presetCinematic },
  ];

  return (
    <div
      className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-3 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={rp.title}
      data-testid="dimensix-render-settings-modal"
    >
      <div className="w-full max-w-2xl max-h-[88dvh] bg-[#10141F] border border-white/[0.12] rounded-2xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="px-4 py-3 border-b border-white/[0.08] flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/35 flex items-center justify-center text-cyan-400 shrink-0">
              <SlidersHorizontal className="w-4 h-4" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm font-semibold text-white truncate">{rp.title}</h2>
              <p className="text-[11px] text-slate-400 truncate">{rp.subtitle}</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => engine.resetRenderSettings()}
              aria-label={rp.resetDefaults}
              className="min-h-[34px] px-2.5 rounded-lg bg-[#161B29] hover:bg-[#1E2438] border border-white/[0.08] text-xs text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5 text-cyan-400" aria-hidden="true" />
              <span className="hidden sm:inline">{rp.resetDefaults}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label={t.close}
              className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-white/[0.06]"
            >
              <X className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>
        </div>

        {/* Quick Presets Bar */}
        <div className="px-4 py-2.5 bg-[#0D101A] border-b border-white/[0.08] flex flex-wrap items-center justify-between gap-2 shrink-0">
          <span className="text-[11px] font-medium text-slate-400">{rp.presetsLabel}</span>
          <div className="flex items-center gap-1.5">
            {presets.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => engine.applyRenderPreset(p.id)}
                className="min-h-[32px] px-3 rounded-lg bg-[#161B29] hover:bg-violet-600/25 border border-white/[0.08] hover:border-violet-500/40 text-xs font-medium text-slate-200 transition-colors"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Category Tabs */}
        <div
          className="px-3 pt-2.5 bg-[#0D101A] border-b border-white/[0.08] grid grid-cols-3 gap-1.5 shrink-0"
          role="tablist"
          aria-label={rp.title}
        >
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setActiveTab(tab.id)}
                className={`min-h-[40px] px-2.5 pb-2.5 pt-1.5 rounded-t-xl flex items-center justify-center gap-1.5 text-xs font-medium border-b-2 transition-colors ${
                  active
                    ? 'border-cyan-400 text-cyan-300 bg-[#10141F]'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span className="truncate">{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto dx-scroll p-4 space-y-3">
          {activeTab === 'image' && (
            <>
              <SelectSettingRow
                id="rs-resolution"
                title={rp.resolution}
                description={rp.resolutionDesc}
                value={renderSettings.resolution}
                options={[
                  { value: 'native', label: rp.resolutionNative },
                  { value: '720p', label: '720p (HD)' },
                  { value: '1080p', label: '1080p (FHD)' },
                  { value: '1440p', label: '1440p (QHD)' },
                ]}
                onChange={(val) =>
                  engine.updateRenderSettings({ resolution: val as RenderResolutionPreset })
                }
              />

              <SliderSettingRow
                id="rs-render-scale"
                title={rp.renderScale}
                description={rp.renderScaleDesc}
                value={renderSettings.renderScale}
                displayValue={`${Math.round(renderSettings.renderScale * 100)}%`}
                min={0.5}
                max={2.0}
                step={0.05}
                onChange={(v) => engine.updateRenderSettings({ renderScale: v })}
              />

              <SliderSettingRow
                id="rs-pixel-ratio"
                title={rp.pixelRatio}
                description={rp.pixelRatioDesc}
                value={renderSettings.pixelRatio}
                displayValue={`${renderSettings.pixelRatio.toFixed(2)}x`}
                min={0.5}
                max={2.0}
                step={0.1}
                onChange={(v) => engine.updateRenderSettings({ pixelRatio: v })}
              />

              <SelectSettingRow
                id="rs-antialiasing"
                title={rp.antiAliasing}
                description={rp.antiAliasingDesc}
                value={renderSettings.antiAliasing}
                options={[
                  { value: 'none', label: rp.aaNone },
                  { value: 'fxaa', label: 'FXAA' },
                  { value: 'msaa', label: 'MSAA' },
                ]}
                onChange={(val) =>
                  engine.updateRenderSettings({ antiAliasing: val as AntiAliasingMode })
                }
              />

              <SelectSettingRow
                id="rs-shadow-quality"
                title={rp.shadowQuality}
                description={rp.shadowQualityDesc}
                value={renderSettings.shadowQuality}
                options={[
                  { value: 'off', label: rp.levelOff },
                  { value: 'low', label: rp.levelLow },
                  { value: 'medium', label: rp.levelMedium },
                  { value: 'high', label: rp.levelHigh },
                ]}
                onChange={(val) =>
                  engine.updateRenderSettings({ shadowQuality: val as ShadowQualityLevel })
                }
              />
            </>
          )}

          {activeTab === 'lighting' && (
            <>
              <ToggleSettingRow
                id="rs-ao"
                title={rp.ambientOcclusion}
                description={rp.ambientOcclusionDesc}
                checked={renderSettings.ambientOcclusion}
                onChange={(checked) => engine.updateRenderSettings({ ambientOcclusion: checked })}
              />

              <SliderSettingRow
                id="rs-exposure"
                title={rp.exposure}
                description={rp.exposureDesc}
                value={renderSettings.exposure}
                displayValue={renderSettings.exposure.toFixed(2)}
                min={0.4}
                max={2.2}
                step={0.05}
                onChange={(v) => engine.updateRenderSettings({ exposure: v })}
              />

              <SliderSettingRow
                id="rs-gamma"
                title={rp.gamma}
                description={rp.gammaDesc}
                value={renderSettings.gamma}
                displayValue={renderSettings.gamma.toFixed(2)}
                min={1.4}
                max={2.6}
                step={0.05}
                onChange={(v) => engine.updateRenderSettings({ gamma: v })}
              />

              <SliderSettingRow
                id="rs-contrast"
                title={rp.contrast}
                description={rp.contrastDesc}
                value={renderSettings.contrast}
                displayValue={renderSettings.contrast.toFixed(2)}
                min={0.5}
                max={1.8}
                step={0.05}
                onChange={(v) => engine.updateRenderSettings({ contrast: v })}
              />

              <div className="rounded-xl bg-[#0B0E17] border border-white/[0.08] p-3 space-y-2.5">
                <ToggleInlineHeader
                  id="rs-bloom"
                  title={rp.bloom}
                  description={rp.bloomDesc}
                  checked={renderSettings.bloomEnabled}
                  onChange={(checked) => engine.updateRenderSettings({ bloomEnabled: checked })}
                />
                {renderSettings.bloomEnabled && (
                  <div className="pt-2 border-t border-white/[0.06]">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <label htmlFor="rs-bloom-intensity" className="text-slate-300">
                        {rp.bloomIntensity}
                      </label>
                      <span className="font-mono tabular-nums text-cyan-300">
                        {renderSettings.bloomIntensity.toFixed(2)}
                      </span>
                    </div>
                    <input
                      id="rs-bloom-intensity"
                      type="range"
                      min={0}
                      max={2.0}
                      step={0.05}
                      value={renderSettings.bloomIntensity}
                      onChange={(e) =>
                        engine.updateRenderSettings({ bloomIntensity: parseFloat(e.target.value) })
                      }
                      className="w-full dx-range"
                    />
                  </div>
                )}
              </div>

              <div className="rounded-xl bg-[#0B0E17] border border-white/[0.08] p-3 space-y-2.5">
                <ToggleInlineHeader
                  id="rs-dof"
                  title={rp.dof}
                  description={rp.dofDesc}
                  checked={renderSettings.dofEnabled}
                  onChange={(checked) => engine.updateRenderSettings({ dofEnabled: checked })}
                />
                {renderSettings.dofEnabled && (
                  <div className="pt-2 border-t border-white/[0.06] grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <label htmlFor="rs-dof-focus" className="text-slate-300">
                          {rp.dofFocusDistance}
                        </label>
                        <span className="font-mono tabular-nums text-cyan-300">
                          {renderSettings.dofFocusDistance.toFixed(1)}m
                        </span>
                      </div>
                      <input
                        id="rs-dof-focus"
                        type="range"
                        min={1}
                        max={30}
                        step={0.5}
                        value={renderSettings.dofFocusDistance}
                        onChange={(e) =>
                          engine.updateRenderSettings({
                            dofFocusDistance: parseFloat(e.target.value),
                          })
                        }
                        className="w-full dx-range"
                      />
                    </div>
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <label htmlFor="rs-dof-aperture" className="text-slate-300">
                          {rp.dofAperture}
                        </label>
                        <span className="font-mono tabular-nums text-cyan-300">
                          {(renderSettings.dofAperture * 1000).toFixed(1)}
                        </span>
                      </div>
                      <input
                        id="rs-dof-aperture"
                        type="range"
                        min={0.001}
                        max={0.03}
                        step={0.001}
                        value={renderSettings.dofAperture}
                        onChange={(e) =>
                          engine.updateRenderSettings({ dofAperture: parseFloat(e.target.value) })
                        }
                        className="w-full dx-range"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="rounded-xl bg-[#0B0E17] border border-white/[0.08] p-3 space-y-2.5">
                <ToggleInlineHeader
                  id="rs-motion-blur"
                  title={rp.motionBlur}
                  description={rp.motionBlurDesc}
                  checked={renderSettings.motionBlurEnabled}
                  onChange={(checked) =>
                    engine.updateRenderSettings({ motionBlurEnabled: checked })
                  }
                />
                {renderSettings.motionBlurEnabled && (
                  <div className="pt-2 border-t border-white/[0.06]">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <label htmlFor="rs-motion-amount" className="text-slate-300">
                        {rp.motionBlurAmount}
                      </label>
                      <span className="font-mono tabular-nums text-cyan-300">
                        {renderSettings.motionBlurAmount.toFixed(2)}
                      </span>
                    </div>
                    <input
                      id="rs-motion-amount"
                      type="range"
                      min={0.1}
                      max={0.9}
                      step={0.05}
                      value={renderSettings.motionBlurAmount}
                      onChange={(e) =>
                        engine.updateRenderSettings({
                          motionBlurAmount: parseFloat(e.target.value),
                        })
                      }
                      className="w-full dx-range"
                    />
                  </div>
                )}
              </div>
            </>
          )}

          {activeTab === 'performance' && (
            <>
              <ToggleSettingRow
                id="rs-perf-mode"
                title={rp.performanceMode}
                description={rp.performanceModeDesc}
                checked={renderSettings.performanceMode}
                onChange={(checked) => engine.updateRenderSettings({ performanceMode: checked })}
              />

              <SelectSettingRow
                id="rs-preview-quality"
                title={rp.previewQuality}
                description={rp.previewQualityDesc}
                value={renderSettings.previewQuality}
                options={[
                  { value: 'low', label: rp.levelLow },
                  { value: 'medium', label: rp.levelMedium },
                  { value: 'high', label: rp.levelHigh },
                ]}
                onChange={(val) =>
                  engine.updateRenderSettings({ previewQuality: val as QualityLevel })
                }
              />

              <SelectSettingRow
                id="rs-render-quality"
                title={rp.renderQuality}
                description={rp.renderQualityDesc}
                value={renderSettings.renderQuality}
                options={[
                  { value: 'draft', label: rp.levelDraft },
                  { value: 'standard', label: rp.levelStandard },
                  { value: 'high', label: rp.levelHigh },
                ]}
                onChange={(val) =>
                  engine.updateRenderSettings({ renderQuality: val as RenderQualityLevel })
                }
              />

              <SelectSettingRow
                id="rs-texture-quality"
                title={rp.textureQuality}
                description={rp.textureQualityDesc}
                value={renderSettings.textureQuality}
                options={[
                  { value: 'low', label: rp.levelLow },
                  { value: 'medium', label: rp.levelMedium },
                  { value: 'high', label: rp.levelHigh },
                ]}
                onChange={(val) =>
                  engine.updateRenderSettings({ textureQuality: val as QualityLevel })
                }
              />

              <SelectSettingRow
                id="rs-shadow-resolution"
                title={rp.shadowResolution}
                description={rp.shadowResolutionDesc}
                value={String(renderSettings.shadowResolution)}
                options={[
                  { value: '512', label: '512 x 512' },
                  { value: '1024', label: '1024 x 1024' },
                  { value: '2048', label: '2048 x 2048' },
                ]}
                onChange={(val) =>
                  engine.updateRenderSettings({
                    shadowResolution: Number(val) as ShadowResolutionSize,
                  })
                }
              />
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-3 border-t border-white/[0.08] bg-[#0D101A] flex justify-end shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[38px] px-5 rounded-xl bg-violet-600 hover:bg-violet-500 text-xs font-semibold text-white transition-colors"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
}

function SliderSettingRow({
  id,
  title,
  description,
  value,
  displayValue,
  min,
  max,
  step,
  onChange,
}: {
  id: string;
  title: string;
  description: string;
  value: number;
  displayValue: string;
  min: number;
  max: number;
  step: number;
  onChange: (value: number) => void;
}) {
  return (
    <div className="rounded-xl bg-[#0B0E17] border border-white/[0.08] p-3 space-y-2">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <label htmlFor={id} className="block text-xs font-medium text-slate-100">
            {title}
          </label>
          <p className="text-[11px] text-slate-400 leading-relaxed mt-0.5">{description}</p>
        </div>
        <span
          className="text-xs font-mono tabular-nums text-cyan-300 bg-cyan-500/10 border border-cyan-500/25 px-2 py-0.5 rounded-md shrink-0"
          dir="ltr"
        >
          {displayValue}
        </span>
      </div>
      <input
        id={id}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full dx-range"
      />
    </div>
  );
}

function SelectSettingRow({
  id,
  title,
  description,
  value,
  options,
  onChange,
}: {
  id: string;
  title: string;
  description: string;
  value: string;
  options: Array<{ value: string; label: string }>;
  onChange: (value: string) => void;
}) {
  return (
    <div className="rounded-xl bg-[#0B0E17] border border-white/[0.08] p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
      <div className="min-w-0">
        <label htmlFor={id} className="block text-xs font-medium text-slate-100">
          {title}
        </label>
        <p className="text-[11px] text-slate-400 leading-relaxed mt-0.5">{description}</p>
      </div>
      <select
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-9 min-w-[140px] px-2.5 rounded-lg bg-[#151A28] border border-white/[0.1] text-xs text-slate-100 focus:outline-none focus:border-cyan-500 shrink-0"
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
}

function ToggleSettingRow({
  id,
  title,
  description,
  checked,
  onChange,
}: {
  id: string;
  title: string;
  description: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}) {
  return (
    <div className="rounded-xl bg-[#0B0E17] border border-white/[0.08] p-3">
      <ToggleInlineHeader
        id={id}
        title={title}
        description={description}
        checked={checked}
        onChange={onChange}
      />
    </div>
  );
}

function ToggleInlineHeader({
  id,
  title,
  description,
  checked,
  onChange,
}: {
  id: string;
  title: string;
  description: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}) {
  return (
    <label htmlFor={id} className="flex items-center justify-between gap-3 cursor-pointer">
      <div className="min-w-0">
        <span className="block text-xs font-medium text-slate-100">{title}</span>
        <p className="text-[11px] text-slate-400 leading-relaxed mt-0.5">{description}</p>
      </div>
      <input
        id={id}
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="w-4 h-4 accent-cyan-400 rounded shrink-0"
      />
    </label>
  );
}
