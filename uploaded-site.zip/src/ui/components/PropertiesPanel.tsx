import { useEffect, useState } from 'react';
import { Copy, Lock, RotateCcw, Trash2, Unlock, Video } from 'lucide-react';
import type { Vec3 } from '../../core/scene/SceneNode';
import { useEditor } from '../context/EditorContext';

export function PropertiesPanel() {
  const { engine, snapshot, selectedNode, t } = useEditor();
  const [nameDraft, setNameDraft] = useState(selectedNode?.name ?? '');

  useEffect(() => {
    setNameDraft(selectedNode?.name ?? '');
  }, [selectedNode?.id, selectedNode?.name]);

  if (!selectedNode) {
    return (
      <div
        className="flex flex-col items-center justify-center h-full p-6 text-center space-y-2"
        data-testid="dimensix-inspector-empty"
      >
        <p className="text-sm font-medium text-slate-300">{t.noSelectionTitle}</p>
        <p className="text-xs text-slate-500 max-w-[220px] leading-relaxed">{t.noSelectionHint}</p>
      </div>
    );
  }

  const commitName = () => {
    if (nameDraft.trim() && nameDraft.trim() !== selectedNode.name) {
      engine.renameNode(selectedNode.id, nameDraft.trim());
    } else {
      setNameDraft(selectedNode.name);
    }
  };

  const availableGroups = snapshot.nodes.filter(
    (n) => n.type === 'group' && n.id !== selectedNode.id,
  );

  const handleVectorChange = (
    channel: 'position' | 'rotation' | 'scale',
    axis: keyof Vec3,
    raw: string,
  ) => {
    const parsed = parseFloat(raw);
    if (Number.isNaN(parsed)) return;
    engine.updateTransform(selectedNode.id, {
      [channel]: { [axis]: parsed },
    });
  };

  return (
    <div className="flex flex-col h-full min-h-0" data-testid="dimensix-properties-panel">
      {/* Header */}
      <div className="px-3 py-2.5 border-b border-white/[0.08] flex items-center justify-between gap-2 shrink-0">
        <div className="min-w-0">
          <h2 className="text-xs font-semibold text-slate-200 truncate">{t.inspector}</h2>
          <p className="text-[11px] text-slate-400 truncate">
            {t.nodeTypes[selectedNode.type]}
          </p>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={() => engine.toggleLocked(selectedNode.id)}
            aria-label={selectedNode.locked ? t.unlock : t.lock}
            title={selectedNode.locked ? t.unlock : t.lock}
            className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded-lg hover:bg-white/[0.06] text-slate-300"
          >
            {selectedNode.locked ? (
              <Lock className="w-3.5 h-3.5 text-amber-400" aria-hidden="true" />
            ) : (
              <Unlock className="w-3.5 h-3.5" aria-hidden="true" />
            )}
          </button>
          <button
            type="button"
            onClick={() => engine.duplicateNode(selectedNode.id)}
            aria-label={t.duplicate}
            title={t.duplicate}
            className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded-lg hover:bg-white/[0.06] text-violet-300"
          >
            <Copy className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
          <button
            type="button"
            onClick={() => engine.removeNode(selectedNode.id)}
            aria-label={`${t.delete} ${selectedNode.name}`}
            title={t.delete}
            className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded-lg hover:bg-red-500/15 text-red-400"
          >
            <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
        </div>
      </div>

      {/* Scrollable Inspector Body */}
      <div className="flex-1 overflow-y-auto dx-scroll p-3 space-y-4">
        {/* Identity & Parent */}
        <div className="space-y-2.5">
          <div>
            <label
              htmlFor="inspector-node-name"
              className="block text-[11px] font-medium text-slate-400 mb-1"
            >
              {t.name}
            </label>
            <input
              id="inspector-node-name"
              type="text"
              value={nameDraft}
              onChange={(e) => setNameDraft(e.target.value)}
              onBlur={commitName}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  commitName();
                  (e.target as HTMLInputElement).blur();
                }
              }}
              className="w-full h-9 px-2.5 rounded-lg bg-[#0B0E17] border border-white/[0.1] text-xs text-white focus:outline-none focus:border-violet-500"
            />
          </div>

          <div>
            <label
              htmlFor="inspector-parent-select"
              className="block text-[11px] font-medium text-slate-400 mb-1"
            >
              {t.parentGroup}
            </label>
            <select
              id="inspector-parent-select"
              value={selectedNode.parentId ?? ''}
              onChange={(e) => engine.reparentNode(selectedNode.id, e.target.value || null)}
              className="w-full h-9 px-2.5 rounded-lg bg-[#0B0E17] border border-white/[0.1] text-xs text-slate-200 focus:outline-none focus:border-violet-500"
            >
              <option value="">{t.rootLevel}</option>
              {availableGroups.map((group) => (
                <option key={group.id} value={group.id}>
                  {group.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Imported Model Metadata */}
        {selectedNode.modelAsset && (
          <div className="pt-3 border-t border-white/[0.08] space-y-2">
            <h3 className="text-xs font-semibold text-slate-200">{t.modelInfo}</h3>
            <div className="rounded-xl bg-[#0B0E17] border border-white/[0.06] p-2.5 space-y-1.5 text-[11px]">
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-400">{t.modelFormat}</span>
                <span className="font-mono uppercase text-cyan-300" dir="ltr">
                  .{selectedNode.modelAsset.format}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-400">{t.modelMeshes}</span>
                <span className="font-mono tabular-nums text-slate-200">
                  {selectedNode.modelAsset.meshCount}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-400">{t.modelTriangles}</span>
                <span className="font-mono tabular-nums text-slate-200">
                  {selectedNode.modelAsset.triangleCount.toLocaleString()}
                </span>
              </div>
              {selectedNode.modelAsset.partNames.length > 0 && (
                <p className="text-[10px] text-slate-500 truncate pt-1 border-t border-white/[0.05]">
                  {selectedNode.modelAsset.partNames.slice(0, 4).join(' · ')}
                </p>
              )}
            </div>
          </div>
        )}

        {/* Transform Section */}
        <div className="pt-3 border-t border-white/[0.08] space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold text-slate-200">{t.transform}</h3>
            <button
              type="button"
              onClick={() => engine.resetTransform(selectedNode.id)}
              disabled={selectedNode.locked}
              className="min-h-[28px] px-2 rounded-md text-[11px] text-cyan-400 hover:bg-cyan-500/10 flex items-center gap-1 disabled:opacity-40"
            >
              <RotateCcw className="w-3 h-3" aria-hidden="true" />
              <span>{t.resetTransform}</span>
            </button>
          </div>

          <Vec3InputRow
            label={t.position}
            value={selectedNode.transform.position}
            step={0.1}
            disabled={selectedNode.locked}
            onChange={(axis, val) => handleVectorChange('position', axis, val)}
          />

          <Vec3InputRow
            label={t.rotation}
            value={selectedNode.transform.rotation}
            step={5}
            disabled={selectedNode.locked}
            onChange={(axis, val) => handleVectorChange('rotation', axis, val)}
          />

          <Vec3InputRow
            label={t.scale}
            value={selectedNode.transform.scale}
            step={0.1}
            disabled={selectedNode.locked}
            onChange={(axis, val) => handleVectorChange('scale', axis, val)}
          />
        </div>

        {/* Material Section */}
        {selectedNode.material && (
          <div className="pt-3 border-t border-white/[0.08] space-y-3">
            <h3 className="text-xs font-semibold text-slate-200">{t.material}</h3>

            {/* Quick Physical Surface Presets */}
            <div className="space-y-1.5">
              <span className="block text-[11px] text-slate-400">{t.materialPresets}</span>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  onClick={() =>
                    engine.updateMaterial(selectedNode.id, {
                      roughness: 0.72,
                      metalness: 0.05,
                      transmission: 0,
                      ior: 1.5,
                    })
                  }
                  className="min-h-[30px] rounded-lg bg-[#0B0E17] hover:bg-white/[0.06] border border-white/[0.08] text-[11px] text-slate-200"
                >
                  {t.presetMatte}
                </button>
                <button
                  type="button"
                  onClick={() =>
                    engine.updateMaterial(selectedNode.id, {
                      roughness: 0.06,
                      metalness: 0.98,
                      transmission: 0,
                      ior: 1.5,
                    })
                  }
                  className="min-h-[30px] rounded-lg bg-[#0B0E17] hover:bg-white/[0.06] border border-white/[0.08] text-[11px] text-cyan-200"
                >
                  {t.presetChrome}
                </button>
                <button
                  type="button"
                  onClick={() =>
                    engine.updateMaterial(selectedNode.id, {
                      roughness: 0.04,
                      metalness: 0.0,
                      transmission: 0.92,
                      ior: 1.52,
                    })
                  }
                  className="min-h-[30px] rounded-lg bg-[#0B0E17] hover:bg-white/[0.06] border border-white/[0.08] text-[11px] text-violet-200"
                >
                  {t.presetGlass}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between gap-2">
              <label htmlFor="inspector-mat-color" className="text-xs text-slate-400">
                {t.color}
              </label>
              <div className="flex items-center gap-2" dir="ltr">
                <input
                  id="inspector-mat-color"
                  type="color"
                  value={selectedNode.material.color}
                  onChange={(e) =>
                    engine.updateMaterial(selectedNode.id, { color: e.target.value })
                  }
                  className="w-8 h-8 rounded-md bg-transparent border border-white/15 cursor-pointer"
                />
                <span className="text-xs font-mono tabular-nums text-slate-300 uppercase w-16">
                  {selectedNode.material.color}
                </span>
              </div>
            </div>

            <RangeSliderRow
              id="inspector-mat-roughness"
              label={t.roughness}
              value={selectedNode.material.roughness}
              min={0}
              max={1}
              step={0.02}
              onChange={(v) => engine.updateMaterial(selectedNode.id, { roughness: v })}
            />

            <RangeSliderRow
              id="inspector-mat-metalness"
              label={t.metalness}
              value={selectedNode.material.metalness}
              min={0}
              max={1}
              step={0.02}
              onChange={(v) => engine.updateMaterial(selectedNode.id, { metalness: v })}
            />

            <RangeSliderRow
              id="inspector-mat-transmission"
              label={t.transmission}
              value={selectedNode.material.transmission ?? 0}
              min={0}
              max={1}
              step={0.02}
              onChange={(v) => engine.updateMaterial(selectedNode.id, { transmission: v })}
            />

            {(selectedNode.material.transmission ?? 0) > 0.02 && (
              <RangeSliderRow
                id="inspector-mat-ior"
                label={t.ior}
                value={selectedNode.material.ior ?? 1.5}
                min={1.0}
                max={2.5}
                step={0.02}
                onChange={(v) => engine.updateMaterial(selectedNode.id, { ior: v })}
              />
            )}

            <label className="flex items-center justify-between gap-2 min-h-[36px] cursor-pointer">
              <span className="text-xs text-slate-300">{t.wireframe}</span>
              <input
                type="checkbox"
                checked={selectedNode.material.wireframe}
                onChange={(e) =>
                  engine.updateMaterial(selectedNode.id, { wireframe: e.target.checked })
                }
                className="w-4 h-4 accent-violet-500 rounded"
              />
            </label>
          </div>
        )}

        {/* Light Section (All 4 Light Types) */}
        {selectedNode.light && (
          <div className="pt-3 border-t border-white/[0.08] space-y-3">
            <h3 className="text-xs font-semibold text-slate-200">{t.light}</h3>

            <div className="flex items-center justify-between gap-2">
              <label htmlFor="inspector-light-color" className="text-xs text-slate-400">
                {t.color}
              </label>
              <div className="flex items-center gap-2" dir="ltr">
                <input
                  id="inspector-light-color"
                  type="color"
                  value={selectedNode.light.color}
                  onChange={(e) => engine.updateLight(selectedNode.id, { color: e.target.value })}
                  className="w-8 h-8 rounded-md bg-transparent border border-white/15 cursor-pointer"
                />
                <span className="text-xs font-mono tabular-nums text-slate-300 uppercase w-16">
                  {selectedNode.light.color}
                </span>
              </div>
            </div>

            <RangeSliderRow
              id="inspector-light-intensity"
              label={t.intensity}
              value={selectedNode.light.intensity}
              min={0}
              max={40}
              step={0.5}
              decimals={1}
              onChange={(v) => engine.updateLight(selectedNode.id, { intensity: v })}
            />

            {(selectedNode.type === 'pointLight' || selectedNode.type === 'spotLight') && (
              <RangeSliderRow
                id="inspector-light-distance"
                label={t.distance}
                value={selectedNode.light.distance}
                min={2}
                max={45}
                step={1}
                decimals={0}
                onChange={(v) => engine.updateLight(selectedNode.id, { distance: v })}
              />
            )}

            {selectedNode.type === 'spotLight' && (
              <>
                <RangeSliderRow
                  id="inspector-light-angle"
                  label={t.lightAngle}
                  value={selectedNode.light.angle ?? 32}
                  min={5}
                  max={85}
                  step={1}
                  decimals={0}
                  suffix="°"
                  onChange={(v) => engine.updateLight(selectedNode.id, { angle: v })}
                />
                <RangeSliderRow
                  id="inspector-light-penumbra"
                  label={t.lightPenumbra}
                  value={selectedNode.light.penumbra ?? 0.45}
                  min={0}
                  max={1}
                  step={0.05}
                  onChange={(v) => engine.updateLight(selectedNode.id, { penumbra: v })}
                />
              </>
            )}

            {selectedNode.type === 'areaLight' && (
              <>
                <RangeSliderRow
                  id="inspector-light-width"
                  label={t.lightWidth}
                  value={selectedNode.light.width ?? 2.4}
                  min={0.3}
                  max={10}
                  step={0.1}
                  decimals={1}
                  onChange={(v) => engine.updateLight(selectedNode.id, { width: v })}
                />
                <RangeSliderRow
                  id="inspector-light-height"
                  label={t.lightHeight}
                  value={selectedNode.light.height ?? 1.6}
                  min={0.3}
                  max={10}
                  step={0.1}
                  decimals={1}
                  onChange={(v) => engine.updateLight(selectedNode.id, { height: v })}
                />
              </>
            )}

            <label className="flex items-center justify-between gap-2 min-h-[36px] cursor-pointer">
              <span className="text-xs text-slate-300">{t.castShadow}</span>
              <input
                type="checkbox"
                checked={selectedNode.light.castShadow ?? true}
                onChange={(e) =>
                  engine.updateLight(selectedNode.id, { castShadow: e.target.checked })
                }
                className="w-4 h-4 accent-cyan-400 rounded"
              />
            </label>
          </div>
        )}

        {/* Camera Node Section */}
        {selectedNode.camera && (
          <div className="pt-3 border-t border-white/[0.08] space-y-3">
            <h3 className="text-xs font-semibold text-slate-200">{t.cameraNodeTitle}</h3>

            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <label htmlFor="inspector-cam-fov" className="text-slate-400">
                  {t.cameraFov}
                </label>
                <span className="font-mono tabular-nums text-cyan-300" dir="ltr">
                  {selectedNode.camera.fov}°
                </span>
              </div>
              <input
                id="inspector-cam-fov"
                type="range"
                min={20}
                max={110}
                step={1}
                value={selectedNode.camera.fov}
                onChange={(e) =>
                  engine.updateCameraNode(selectedNode.id, { fov: parseFloat(e.target.value) })
                }
                className="w-full dx-range"
              />
            </div>

            <div className="grid grid-cols-2 gap-2" dir="ltr">
              <label className="block space-y-1">
                <span className="block text-[11px] text-slate-400">{t.cameraNear}</span>
                <input
                  type="number"
                  step={0.05}
                  min={0.01}
                  max={10}
                  value={selectedNode.camera.near}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value);
                    if (!Number.isNaN(v) && v > 0) {
                      engine.updateCameraNode(selectedNode.id, { near: v });
                    }
                  }}
                  className="w-full h-8 px-2 rounded-lg bg-[#0B0E17] border border-white/[0.08] text-xs font-mono tabular-nums text-slate-100 focus:outline-none focus:border-cyan-500"
                />
              </label>

              <label className="block space-y-1">
                <span className="block text-[11px] text-slate-400">{t.cameraFar}</span>
                <input
                  type="number"
                  step={10}
                  min={10}
                  max={1000}
                  value={selectedNode.camera.far}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value);
                    if (!Number.isNaN(v) && v >= 10) {
                      engine.updateCameraNode(selectedNode.id, { far: v });
                    }
                  }}
                  className="w-full h-8 px-2 rounded-lg bg-[#0B0E17] border border-white/[0.08] text-xs font-mono tabular-nums text-slate-100 focus:outline-none focus:border-cyan-500"
                />
              </label>
            </div>

            <button
              type="button"
              onClick={() => engine.alignViewToCameraNode(selectedNode.id)}
              className="w-full min-h-[38px] px-3 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/35 text-xs font-medium text-cyan-200 flex items-center justify-center gap-2 transition-colors"
            >
              <Video className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t.alignViewToCamera}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function RangeSliderRow({
  id,
  label,
  value,
  min,
  max,
  step,
  decimals = 2,
  suffix = '',
  onChange,
}: {
  id: string;
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  decimals?: number;
  suffix?: string;
  onChange: (value: number) => void;
}) {
  return (
    <div>
      <div className="flex items-center justify-between text-xs mb-1.5">
        <label htmlFor={id} className="text-slate-400">
          {label}
        </label>
        <span className="font-mono tabular-nums text-slate-300" dir="ltr">
          {value.toFixed(decimals)}
          {suffix}
        </span>
      </div>
      <input
        id={id}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full dx-range"
      />
    </div>
  );
}

interface Vec3InputRowProps {
  label: string;
  value: Vec3;
  step: number;
  disabled: boolean;
  onChange: (axis: keyof Vec3, raw: string) => void;
}

function Vec3InputRow({ label, value, step, disabled, onChange }: Vec3InputRowProps) {
  const axes: Array<{ key: keyof Vec3; tag: string; accent: string }> = [
    { key: 'x', tag: 'X', accent: 'text-rose-400' },
    { key: 'y', tag: 'Y', accent: 'text-emerald-400' },
    { key: 'z', tag: 'Z', accent: 'text-sky-400' },
  ];

  return (
    <div className="space-y-1.5">
      <span className="block text-[11px] font-medium text-slate-400">{label}</span>
      <div className="grid grid-cols-3 gap-1.5" dir="ltr">
        {axes.map((axis) => (
          <label
            key={axis.key}
            className="flex items-center gap-1 px-2 h-8 rounded-lg bg-[#0B0E17] border border-white/[0.08] focus-within:border-cyan-500/60"
          >
            <span className={`text-[10px] font-bold ${axis.accent}`}>{axis.tag}</span>
            <input
              type="number"
              step={step}
              disabled={disabled}
              aria-label={`${label} ${axis.tag}`}
              value={Number(value[axis.key].toFixed(2))}
              onChange={(e) => onChange(axis.key, e.target.value)}
              className="w-full bg-transparent text-xs font-mono tabular-nums text-slate-100 focus:outline-none disabled:opacity-45"
            />
          </label>
        ))}
      </div>
    </div>
  );
}
