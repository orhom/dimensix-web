import { useEffect, useState } from 'react';

export type ViewportLayoutMode = 'mobile-portrait' | 'mobile-landscape' | 'desktop';

export function useViewportMode(): ViewportLayoutMode {
  const [mode, setMode] = useState<ViewportLayoutMode>(() => computeLayoutMode());

  useEffect(() => {
    const onResize = () => {
      setMode(computeLayoutMode());
    };
    window.addEventListener('resize', onResize);
    window.addEventListener('orientationchange', onResize);
    return () => {
      window.removeEventListener('resize', onResize);
      window.removeEventListener('orientationchange', onResize);
    };
  }, []);

  return mode;
}

function computeLayoutMode(): ViewportLayoutMode {
  if (typeof window === 'undefined') return 'desktop';
  const w = window.innerWidth;
  const h = window.innerHeight;
  if (w >= 1024 && h >= 540) {
    return 'desktop';
  }
  if (w > h && w >= 560) {
    return 'mobile-landscape';
  }
  return 'mobile-portrait';
}
