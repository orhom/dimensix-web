import { useEffect, useState } from 'react';
import {
  Box,
  ChevronDown,
  Layers,
  PanelLeft,
  PanelRight,
  PlusSquare,
  Sliders,
} from 'lucide-react';
import { useEditor } from './context/EditorContext';
import { useViewportMode } from './hooks/useViewportMode';
import { AddObjectToolbar } from './components/AddObjectToolbar';
import { ExportImageModal } from './components/ExportImageModal';
import { HierarchyPanel } from './components/HierarchyPanel';
import { ProjectModal } from './components/ProjectModal';
import { PropertiesPanel } from './components/PropertiesPanel';
import { RenderSettingsModal } from './components/RenderSettingsModal';
import { SettingsModal } from './components/SettingsModal';
import { TopHeaderBar } from './components/TopHeaderBar';
import { ViewportCanvas } from './components/ViewportCanvas';

type MobileSheetTab = 'viewport' | 'add' | 'hierarchy' | 'inspector';

export function EditorShell() {
  const { engine, selectedNode, t } = useEditor();
  const layoutMode = useViewportMode();

  const [projectsOpen, setProjectsOpen] = useState(false);
  const [renderSettingsOpen, setRenderSettingsOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  // Sidebars state for desktop & landscape
  const [showHierarchySide, setShowHierarchySide] = useState(true);
  const [showInspectorSide, setShowInspectorSide] = useState(true);

  // Portrait bottom sheet tab
  const [mobileTab, setMobileTab] = useState<MobileSheetTab>('viewport');

  // Auto-collapse side panels on narrow mobile landscape so center viewport remains wide
  useEffect(() => {
    if (layoutMode === 'mobile-landscape') {
      setShowHierarchySide(false);
      setShowInspectorSide(false);
    } else if (layoutMode === 'desktop') {
      setShowHierarchySide(true);
      setShowInspectorSide(true);
    }
  }, [layoutMode]);

  // Global keyboard shortcuts (undo, redo, save, delete, transform modes)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isTyping =
        target?.tagName === 'INPUT' ||
        target?.tagName === 'TEXTAREA' ||
        target?.tagName === 'SELECT';
      if (isTyping) return;

      const mod = e.metaKey || e.ctrlKey;
      if (mod && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) engine.redo();
        else engine.undo();
        return;
      }
      if (mod && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        engine.redo();
        return;
      }
      if (mod && e.key.toLowerCase() === 's') {
        e.preventDefault();
        engine.saveCurrentProject();
        return;
      }
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedNode) {
        e.preventDefault();
        engine.removeNode(selectedNode.id);
        return;
      }
      if (!mod && e.key.toLowerCase() === 'g') {
        engine.setTransformMode('translate');
      } else if (!mod && e.key.toLowerCase() === 'r') {
        engine.setTransformMode('rotate');
      } else if (!mod && e.key.toLowerCase() === 's') {
        engine.setTransformMode('scale');
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [engine, selectedNode]);

  const isPortrait = layoutMode === 'mobile-portrait';

  return (
    <div
      className="w-full h-dvh flex flex-col bg-[#090B10] text-slate-100 overflow-hidden"
      data-layout-mode={layoutMode}
    >
      <TopHeaderBar
        onOpenProjects={() => setProjectsOpen(true)}
        onOpenRenderSettings={() => setRenderSettingsOpen(true)}
        onOpenExport={() => setExportOpen(true)}
        onOpenSettings={() => setSettingsOpen(true)}
      />

      {/* Main Editor Workspace */}
      <div className="flex-1 min-h-0 flex relative overflow-hidden">
        {/* Start Sidebar: Hierarchy (Desktop & Mobile Landscape) */}
        {!isPortrait && showHierarchySide && (
          <aside
            className="w-52 md:w-60 lg:w-64 shrink-0 bg-[#10141F] border-e border-white/[0.08] flex flex-col min-h-0 z-20"
            aria-label={t.hierarchy}
          >
            <HierarchyPanel />
          </aside>
        )}

        {/* Central 3D Viewport + Floating Add Toolbar */}
        <main className="flex-1 min-w-0 min-h-0 relative flex flex-col">
          <div className="flex-1 min-h-0 relative">
            <ViewportCanvas />

            {/* Desktop & Landscape Bottom Non-Overlapping Control Row */}
            {!isPortrait && (
              <div className="absolute bottom-2.5 inset-x-2.5 z-20 flex items-center justify-between gap-2 pointer-events-none">
                <button
                  type="button"
                  onClick={() => setShowHierarchySide((v) => !v)}
                  aria-label={t.hierarchy}
                  aria-expanded={showHierarchySide}
                  className="pointer-events-auto shrink-0 min-h-[38px] px-2.5 rounded-xl bg-[#10141F]/95 border border-white/[0.08] text-xs text-slate-200 hover:text-white flex items-center gap-1.5"
                >
                  <PanelLeft className="w-3.5 h-3.5 text-violet-400" aria-hidden="true" />
                  <span className="hidden md:inline">{t.hierarchy}</span>
                </button>

                <div className="pointer-events-auto flex-1 min-w-0 flex justify-center">
                  <AddObjectToolbar />
                </div>

                <button
                  type="button"
                  onClick={() => setShowInspectorSide((v) => !v)}
                  aria-label={t.inspector}
                  aria-expanded={showInspectorSide}
                  className="pointer-events-auto shrink-0 min-h-[38px] px-2.5 rounded-xl bg-[#10141F]/95 border border-white/[0.08] text-xs text-slate-200 hover:text-white flex items-center gap-1.5"
                >
                  <PanelRight className="w-3.5 h-3.5 text-cyan-400" aria-hidden="true" />
                  <span className="hidden md:inline">{t.inspector}</span>
                </button>
              </div>
            )}
          </div>

          {/* Mobile Portrait Active Bottom Sheet Drawer */}
          {isPortrait && mobileTab !== 'viewport' && (
            <section
              aria-label={
                mobileTab === 'add'
                  ? t.addElements
                  : mobileTab === 'hierarchy'
                    ? t.hierarchy
                    : t.inspector
              }
              className="shrink-0 max-h-[45dvh] bg-[#10141F] border-t border-white/[0.1] flex flex-col min-h-0 z-20"
              data-testid="dimensix-mobile-sheet"
            >
              <div className="px-3 py-1.5 border-b border-white/[0.06] flex items-center justify-between shrink-0">
                <span className="text-xs font-semibold text-slate-200">
                  {mobileTab === 'add'
                    ? t.addElements
                    : mobileTab === 'hierarchy'
                      ? t.hierarchy
                      : t.inspector}
                </span>
                <button
                  type="button"
                  onClick={() => setMobileTab('viewport')}
                  aria-label={t.close}
                  className="min-h-[34px] min-w-[34px] flex items-center justify-center rounded-lg text-slate-400 hover:text-white"
                >
                  <ChevronDown className="w-4 h-4" aria-hidden="true" />
                </button>
              </div>

              <div className="flex-1 min-h-0 overflow-y-auto dx-scroll">
                {mobileTab === 'add' && (
                  <div className="p-3">
                    <AddObjectToolbar
                      compact
                      onActionDone={() => setMobileTab('viewport')}
                    />
                  </div>
                )}
                {mobileTab === 'hierarchy' && (
                  <HierarchyPanel onSelectDone={() => setMobileTab('inspector')} />
                )}
                {mobileTab === 'inspector' && <PropertiesPanel />}
              </div>
            </section>
          )}
        </main>

        {/* End Sidebar: Properties Inspector (Desktop & Mobile Landscape) */}
        {!isPortrait && showInspectorSide && (
          <aside
            className="w-60 md:w-68 lg:w-72 shrink-0 bg-[#10141F] border-s border-white/[0.08] flex flex-col min-h-0 z-20"
            aria-label={t.inspector}
          >
            <PropertiesPanel />
          </aside>
        )}
      </div>

      {/* Mobile Portrait Thumb-Zone Bottom Navigation Bar */}
      {isPortrait && (
        <nav
          aria-label="Mobile Navigation"
          className="h-14 shrink-0 bg-[#0D101A] border-t border-white/[0.08] grid grid-cols-4 items-center px-1 z-30"
          data-testid="dimensix-mobile-nav"
        >
          <MobileTabButton
            label={t.viewport}
            icon={Box}
            active={mobileTab === 'viewport'}
            onClick={() => setMobileTab('viewport')}
          />
          <MobileTabButton
            label={t.addElements}
            icon={PlusSquare}
            active={mobileTab === 'add'}
            onClick={() => setMobileTab((prev) => (prev === 'add' ? 'viewport' : 'add'))}
          />
          <MobileTabButton
            label={t.hierarchy}
            icon={Layers}
            active={mobileTab === 'hierarchy'}
            onClick={() =>
              setMobileTab((prev) => (prev === 'hierarchy' ? 'viewport' : 'hierarchy'))
            }
          />
          <MobileTabButton
            label={t.inspector}
            icon={Sliders}
            active={mobileTab === 'inspector'}
            onClick={() =>
              setMobileTab((prev) => (prev === 'inspector' ? 'viewport' : 'inspector'))
            }
          />
        </nav>
      )}

      {/* Modals */}
      <ProjectModal open={projectsOpen} onClose={() => setProjectsOpen(false)} />
      <RenderSettingsModal
        open={renderSettingsOpen}
        onClose={() => setRenderSettingsOpen(false)}
      />
      <ExportImageModal open={exportOpen} onClose={() => setExportOpen(false)} />
      <SettingsModal open={settingsOpen} onClose={() => setSettingsOpen(false)} />
    </div>
  );
}

function MobileTabButton({
  label,
  icon: Icon,
  active,
  onClick,
}: {
  label: string;
  icon: typeof Box;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`min-h-[46px] flex flex-col items-center justify-center gap-0.5 rounded-xl transition-colors px-1 ${
        active ? 'text-cyan-400 bg-cyan-500/10' : 'text-slate-400 hover:text-slate-200'
      }`}
    >
      <Icon className="w-4 h-4" aria-hidden="true" />
      <span className="text-[10px] font-medium truncate max-w-full">{label}</span>
    </button>
  );
}
