import { EditorProvider } from './ui/context/EditorContext';
import { EditorShell } from './ui/EditorShell';

export default function App() {
  return (
    <EditorProvider>
      <EditorShell />
    </EditorProvider>
  );
}
