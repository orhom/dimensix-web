import type { RenderSettings } from '../rendering/RenderSettings';
import type { SceneSnapshot } from '../scene/SceneNode';

export type EditorLanguage = 'ar' | 'en';

export type ProjectTemplateId = 'studio-starter' | 'validation-showcase' | 'empty';

export interface EmbeddedModelAsset {
  assetId: string;
  fileName: string;
  base64: string;
}

export interface EditorSettings {
  language: EditorLanguage;
  activeEngineId: string;
  showGrid: boolean;
  showAxes: boolean;
  snapToGrid: boolean;
  fov: number;
}

export interface DimensiXProject {
  id: string;
  name: string;
  schemaVersion: number;
  createdAt: number;
  updatedAt: number;
  scene: SceneSnapshot;
  renderSettings?: RenderSettings;
  embeddedAssets?: EmbeddedModelAsset[];
}

export interface ProjectSummary {
  id: string;
  name: string;
  nodeCount: number;
  updatedAt: number;
}

export const DEFAULT_EDITOR_SETTINGS: EditorSettings = {
  language: 'ar',
  activeEngineId: 'three-webgl-foundation',
  showGrid: true,
  showAxes: true,
  snapToGrid: false,
  fov: 50,
};
