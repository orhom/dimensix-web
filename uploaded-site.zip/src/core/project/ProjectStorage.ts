import {
  sanitizeRenderSettings,
  type RenderSettings,
} from '../rendering/RenderSettings';
import { createDefaultNode, type SceneNode, type SceneSnapshot } from '../scene/SceneNode';
import {
  DEFAULT_EDITOR_SETTINGS,
  type DimensiXProject,
  type EditorSettings,
  type ProjectSummary,
  type ProjectTemplateId,
} from './ProjectTypes';

export interface StorageBackend {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

export interface IProjectStorage {
  listProjects(): ProjectSummary[];
  loadProject(id: string): DimensiXProject | null;
  saveProject(project: DimensiXProject): DimensiXProject;
  deleteProject(id: string): void;
  getActiveProjectId(): string | null;
  setActiveProjectId(id: string): void;
  loadSettings(): EditorSettings;
  saveSettings(settings: EditorSettings): void;
  loadRenderSettings(): RenderSettings;
  saveRenderSettings(settings: RenderSettings): void;
}

export const SHOWCASE_GLB_ASSET_ID = 'showcase_glb_artifact';

const PROJECTS_KEY = 'dimensix.projects.v1';
const ACTIVE_PROJECT_KEY = 'dimensix.activeProjectId.v1';
const SETTINGS_KEY = 'dimensix.settings.v1';
const RENDER_SETTINGS_KEY = 'dimensix.renderSettings.v1';

export function createTemplateScene(template: ProjectTemplateId): SceneSnapshot {
  if (template === 'empty') {
    return {
      nodes: [
        createDefaultNode('pointLight', 'light_1', 'Key Point Light', {
          position: { x: 2.5, y: 4, z: 2.5 },
          color: '#FFF7ED',
          intensity: 8,
        }),
      ],
      selectedId: 'light_1',
    };
  }

  if (template === 'validation-showcase') {
    const floorPlane = createDefaultNode('plane', 'showcase_floor', 'Studio Floor Plane', {
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: -90, y: 0, z: 0 },
      scale: { x: 9, y: 9, z: 1 },
      color: '#1E293B',
      roughness: 0.42,
      metalness: 0.12,
    });

    const matteCube = createDefaultNode('box', 'showcase_cube', 'Violet Architectural Cube', {
      position: { x: -1.65, y: 0.55, z: -0.35 },
      rotation: { x: 0, y: 28, z: 0 },
      scale: { x: 1.05, y: 1.1, z: 1.05 },
      color: '#8B5CF6',
      roughness: 0.32,
      metalness: 0.15,
    });

    const glassSphere = createDefaultNode('sphere', 'showcase_glass_sphere', 'Refractive Glass Sphere', {
      position: { x: 1.5, y: 0.65, z: 0.65 },
      scale: { x: 1.1, y: 1.1, z: 1.1 },
      color: '#E0F2FE',
      roughness: 0.04,
      metalness: 0.0,
      transmission: 0.92,
      ior: 1.52,
    });

    const mirrorSphere = createDefaultNode('sphere', 'showcase_chrome_sphere', 'Chrome Mirror Sphere', {
      position: { x: 1.35, y: 0.52, z: -1.15 },
      scale: { x: 0.9, y: 0.9, z: 0.9 },
      color: '#F8FAFC',
      roughness: 0.06,
      metalness: 0.98,
    });

    const glbSculpture = createDefaultNode('model', 'showcase_glb_model', 'Precision Artifact (GLB)', {
      position: { x: 0, y: 0.01, z: 0.2 },
      rotation: { x: 0, y: -18, z: 0 },
      scale: { x: 1.0, y: 1.0, z: 1.0 },
      modelAsset: {
        assetId: SHOWCASE_GLB_ASSET_ID,
        fileName: 'precision_artifact.glb',
        format: 'glb',
        meshCount: 3,
        triangleCount: 228,
        partNames: ['Glb_Brass_Base', 'Glb_Titanium_Collar', 'Glb_Faceted_Spire'],
      },
    });

    const pointLight = createDefaultNode('pointLight', 'showcase_point_light', 'Warm Point Light', {
      position: { x: -2.6, y: 2.6, z: 2.1 },
      color: '#FDBA74',
      intensity: 12,
      distance: 18,
    });

    const sunLight = createDefaultNode('directionalLight', 'showcase_sun_light', 'Sun Key Light', {
      position: { x: 4.5, y: 6.0, z: 4.0 },
      rotation: { x: -50, y: 38, z: 0 },
      color: '#FFF7ED',
      intensity: 1.8,
    });

    const spotLight = createDefaultNode('spotLight', 'showcase_spot_light', 'Cyan Rim Spot', {
      position: { x: 2.8, y: 3.4, z: -2.4 },
      rotation: { x: -45, y: 135, z: 0 },
      color: '#38BDF8',
      intensity: 18,
      distance: 22,
      angle: 34,
      penumbra: 0.45,
    });

    const areaLight = createDefaultNode('areaLight', 'showcase_area_light', 'Overhead Softbox Area', {
      position: { x: 0, y: 3.8, z: 0.6 },
      rotation: { x: -78, y: 0, z: 0 },
      color: '#F8FAFC',
      intensity: 5.5,
      width: 2.8,
      height: 1.8,
    });

    return {
      nodes: [
        floorPlane,
        matteCube,
        glassSphere,
        mirrorSphere,
        glbSculpture,
        pointLight,
        sunLight,
        spotLight,
        areaLight,
      ],
      selectedId: glbSculpture.id,
    };
  }

  // Studio Starter Scene: clean multi-element architectural studio composition
  const group = createDefaultNode('group', 'group_studio', 'Studio Assembly', {
    position: { x: 0, y: 0, z: 0 },
  });

  const pedestal = createDefaultNode('cylinder', 'cyl_pedestal', 'Studio Pedestal', {
    parentId: group.id,
    position: { x: 0, y: 0.15, z: 0 },
    scale: { x: 2.2, y: 0.3, z: 2.2 },
    color: '#1E293B',
    roughness: 0.65,
    metalness: 0.25,
  });

  const prism = createDefaultNode('box', 'box_monolith', 'Violet Monolith', {
    parentId: group.id,
    position: { x: -0.6, y: 0.9, z: 0 },
    rotation: { x: 0, y: 24, z: 0 },
    scale: { x: 0.9, y: 1.2, z: 0.9 },
    color: '#8B5CF6',
    roughness: 0.3,
    metalness: 0.35,
  });

  const orb = createDefaultNode('sphere', 'sphere_orb', 'Cyan Core', {
    parentId: group.id,
    position: { x: 0.85, y: 0.85, z: 0.45 },
    scale: { x: 0.85, y: 0.85, z: 0.85 },
    color: '#06B6D4',
    roughness: 0.18,
    metalness: 0.72,
  });

  const ring = createDefaultNode('torus', 'torus_halo', 'Orbital Ring', {
    parentId: group.id,
    position: { x: 0.85, y: 0.85, z: 0.45 },
    rotation: { x: 65, y: 20, z: 0 },
    scale: { x: 0.75, y: 0.75, z: 0.75 },
    color: '#22D3EE',
    roughness: 0.22,
    metalness: 0.85,
  });

  const accentLight = createDefaultNode('pointLight', 'light_accent', 'Accent Light', {
    position: { x: -2.5, y: 3.2, z: 2.4 },
    color: '#A78BFA',
    intensity: 8,
  });

  const nodes: SceneNode[] = [group, pedestal, prism, orb, ring, accentLight];
  return {
    nodes,
    selectedId: prism.id,
  };
}

export function createNewProject(
  name: string,
  template: ProjectTemplateId = 'studio-starter',
): DimensiXProject {
  const now = Date.now();
  const safeName = name.trim() || 'مشهد جديد';
  const id = `proj_${now}_${Math.random().toString(36).slice(2, 7)}`;
  return {
    id,
    name: safeName,
    schemaVersion: 1,
    createdAt: now,
    updatedAt: now,
    scene: createTemplateScene(template),
  };
}

export class MemoryStorageBackend implements StorageBackend {
  private map = new Map<string, string>();
  getItem(key: string): string | null {
    return this.map.get(key) ?? null;
  }
  setItem(key: string, value: string): void {
    this.map.set(key, value);
  }
  removeItem(key: string): void {
    this.map.delete(key);
  }
}

export class LocalStorageProjectStorage implements IProjectStorage {
  private backend: StorageBackend;

  constructor(backend?: StorageBackend) {
    if (backend) {
      this.backend = backend;
    } else if (typeof window !== 'undefined' && window.localStorage) {
      this.backend = window.localStorage;
    } else {
      this.backend = new MemoryStorageBackend();
    }
  }

  listProjects(): ProjectSummary[] {
    const map = this.readProjectsMap();
    return Object.values(map)
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .map((p) => ({
        id: p.id,
        name: p.name,
        nodeCount: p.scene.nodes.length,
        updatedAt: p.updatedAt,
      }));
  }

  loadProject(id: string): DimensiXProject | null {
    const map = this.readProjectsMap();
    return map[id] ?? null;
  }

  saveProject(project: DimensiXProject): DimensiXProject {
    const map = this.readProjectsMap();
    const updated: DimensiXProject = {
      ...project,
      updatedAt: Date.now(),
    };
    map[updated.id] = updated;
    this.writeProjectsMap(map);
    this.setActiveProjectId(updated.id);
    return updated;
  }

  deleteProject(id: string): void {
    const map = this.readProjectsMap();
    delete map[id];
    this.writeProjectsMap(map);
    if (this.getActiveProjectId() === id) {
      const remaining = Object.keys(map);
      if (remaining.length > 0) {
        this.setActiveProjectId(remaining[0]);
      } else {
        this.backend.removeItem(ACTIVE_PROJECT_KEY);
      }
    }
  }

  getActiveProjectId(): string | null {
    return this.backend.getItem(ACTIVE_PROJECT_KEY);
  }

  setActiveProjectId(id: string): void {
    this.backend.setItem(ACTIVE_PROJECT_KEY, id);
  }

  loadSettings(): EditorSettings {
    try {
      const raw = this.backend.getItem(SETTINGS_KEY);
      if (!raw) return { ...DEFAULT_EDITOR_SETTINGS };
      const parsed = JSON.parse(raw) as Partial<EditorSettings>;
      return {
        ...DEFAULT_EDITOR_SETTINGS,
        ...parsed,
      };
    } catch {
      return { ...DEFAULT_EDITOR_SETTINGS };
    }
  }

  saveSettings(settings: EditorSettings): void {
    try {
      this.backend.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch {
      // Ignore quota errors cleanly
    }
  }

  loadRenderSettings(): RenderSettings {
    try {
      const raw = this.backend.getItem(RENDER_SETTINGS_KEY);
      if (!raw) return sanitizeRenderSettings();
      const parsed = JSON.parse(raw) as Partial<RenderSettings>;
      return sanitizeRenderSettings(parsed);
    } catch {
      return sanitizeRenderSettings();
    }
  }

  saveRenderSettings(settings: RenderSettings): void {
    try {
      this.backend.setItem(RENDER_SETTINGS_KEY, JSON.stringify(settings));
    } catch {
      // Ignore quota errors cleanly
    }
  }

  private readProjectsMap(): Record<string, DimensiXProject> {
    try {
      const raw = this.backend.getItem(PROJECTS_KEY);
      if (!raw) return {};
      const parsed = JSON.parse(raw) as Record<string, DimensiXProject>;
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch {
      return {};
    }
  }

  private writeProjectsMap(map: Record<string, DimensiXProject>): void {
    this.backend.setItem(PROJECTS_KEY, JSON.stringify(map));
  }
}
