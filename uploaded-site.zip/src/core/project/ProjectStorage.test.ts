import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createNewProject,
  LocalStorageProjectStorage,
  MemoryStorageBackend,
} from './ProjectStorage';

test('LocalStorageProjectStorage saves, lists, loads, and deletes projects', () => {
  const storage = new LocalStorageProjectStorage(new MemoryStorageBackend());

  const p1 = createNewProject('مشهد أول', 'studio-starter');
  const p2 = createNewProject('مشهد فارغ', 'empty');

  storage.saveProject(p1);
  storage.saveProject(p2);

  const list = storage.listProjects();
  assert.equal(list.length, 2);
  assert.equal(storage.getActiveProjectId(), p2.id);

  const loaded = storage.loadProject(p1.id);
  assert.ok(loaded);
  assert.equal(loaded.name, 'مشهد أول');
  assert.ok(loaded.scene.nodes.length >= 5);

  storage.deleteProject(p2.id);
  assert.equal(storage.listProjects().length, 1);
  assert.equal(storage.getActiveProjectId(), p1.id);
});
