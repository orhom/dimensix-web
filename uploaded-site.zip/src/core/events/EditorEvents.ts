import type { CameraMode } from '../camera/CameraController';
import type { SceneNode, SceneSnapshot } from '../scene/SceneNode';
import type { PathTracerStatus, TransformMode } from '../rendering/IRenderEngine';
import type { RenderSettings } from '../rendering/RenderSettings';
import type { DimensiXProject, EditorSettings } from '../project/ProjectTypes';

export interface EditorEventMap {
  [key: string]: unknown;
  'scene:changed': {
    snapshot: SceneSnapshot;
    reason: string;
  };
  'selection:changed': {
    selectedId: string | null;
    node: SceneNode | null;
  };
  'node:added': {
    node: SceneNode;
  };
  'node:removed': {
    nodeId: string;
  };
  'node:updated': {
    node: SceneNode;
  };
  'history:changed': {
    canUndo: boolean;
    canRedo: boolean;
  };
  'viewport:transformModeChanged': {
    mode: TransformMode;
  };
  'camera:modeChanged': {
    mode: CameraMode;
  };
  'project:loaded': {
    project: DimensiXProject;
  };
  'project:saved': {
    project: DimensiXProject;
    savedAt: number;
  };
  'project:dirtyChanged': {
    isDirty: boolean;
  };
  'settings:changed': {
    settings: EditorSettings;
  };
  'renderSettings:changed': {
    renderSettings: RenderSettings;
  };
  'engine:changed': {
    engineId: string;
  };
  'pathtracer:status': PathTracerStatus;
  'model:importError': {
    message: string;
  };
}
