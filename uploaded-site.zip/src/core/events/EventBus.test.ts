import test from 'node:test';
import assert from 'node:assert/strict';
import { EventBus } from './EventBus';

interface TestEvents {
  [key: string]: unknown;
  ping: { count: number };
  reset: void;
}

test('EventBus delivers payloads to listeners and supports unsubscribe', () => {
  const bus = new EventBus<TestEvents>();
  const received: number[] = [];

  const unsub = bus.on('ping', ({ count }) => received.push(count));
  bus.emit('ping', { count: 1 });
  bus.emit('ping', { count: 2 });
  unsub();
  bus.emit('ping', { count: 3 });

  assert.deepEqual(received, [1, 2]);
  assert.equal(bus.listenerCount('ping'), 0);
});

test('EventBus once fires only a single time', () => {
  const bus = new EventBus<TestEvents>();
  let calls = 0;

  bus.once('reset', () => {
    calls += 1;
  });

  bus.emit('reset', undefined);
  bus.emit('reset', undefined);
  assert.equal(calls, 1);
});
