export type NodeType =
  | 'box'
  | 'sphere'
  | 'cylinder'
  | 'cone'
  | 'torus'
  | 'plane'
  | 'group'
  | 'pointLight'
  | 'directionalLight'
  | 'spotLight'
  | 'areaLight'
  | 'camera'
  | 'model';

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export interface TransformData {
  position: Vec3;
  rotation: Vec3; // Euler degrees for inspector ergonomics
  scale: Vec3;
}

export interface MaterialData {
  color: string;
  roughness: number; // 0..1
  metalness: number; // 0..1
  wireframe: boolean;
  transmission?: number; // 0..1 (glass / transparent refraction)
  ior?: number; // 1.0..2.5
  emissive?: string;
  emissiveIntensity?: number;
}

export interface LightData {
  color: string;
  intensity: number; // 0..40
  distance: number; // range for point/spot
  castShadow?: boolean;
  angle?: number; // cone half-angle in degrees (5..85) for spotLight
  penumbra?: number; // soft edge 0..1 for spotLight
  width?: number; // width in meters for areaLight
  height?: number; // height in meters for areaLight
  softness?: number; // physical source radius for soft shadows in Path Tracing
}

export interface CameraNodeData {
  fov: number; // degrees 20..110
  near: number;
  far: number;
}

export type ModelFormat = 'glb' | 'gltf' | 'obj' | 'stl' | 'fbx';

export interface ModelAssetRef {
  assetId: string;
  fileName: string;
  format: ModelFormat;
  meshCount: number;
  triangleCount: number;
  partNames: string[];
}

export interface SceneNode {
  id: string;
  name: string;
  type: NodeType;
  parentId: string | null;
  visible: boolean;
  locked: boolean;
  transform: TransformData;
  material?: MaterialData;
  light?: LightData;
  camera?: CameraNodeData;
  modelAsset?: ModelAssetRef;
}

export interface SceneSnapshot {
  nodes: SceneNode[];
  selectedId: string | null;
}

export function isLightNodeType(type: NodeType): boolean {
  return (
    type === 'pointLight' ||
    type === 'directionalLight' ||
    type === 'spotLight' ||
    type === 'areaLight'
  );
}

export function cloneVec3(v: Vec3): Vec3 {
  return { x: v.x, y: v.y, z: v.z };
}

export function cloneNode(node: SceneNode): SceneNode {
  return {
    id: node.id,
    name: node.name,
    type: node.type,
    parentId: node.parentId,
    visible: node.visible,
    locked: node.locked,
    transform: {
      position: cloneVec3(node.transform.position),
      rotation: cloneVec3(node.transform.rotation),
      scale: cloneVec3(node.transform.scale),
    },
    material: node.material ? { ...node.material } : undefined,
    light: node.light ? { ...node.light } : undefined,
    camera: node.camera ? { ...node.camera } : undefined,
    modelAsset: node.modelAsset
      ? {
          ...node.modelAsset,
          partNames: [...node.modelAsset.partNames],
        }
      : undefined,
  };
}

export function cloneSnapshot(snapshot: SceneSnapshot): SceneSnapshot {
  return {
    nodes: snapshot.nodes.map(cloneNode),
    selectedId: snapshot.selectedId,
  };
}

const DEFAULT_COLORS: Record<NodeType, string> = {
  box: '#8B5CF6',
  sphere: '#06B6D4',
  cylinder: '#6366F1',
  cone: '#EC4899',
  torus: '#22D3EE',
  plane: '#334155',
  group: '#94A3B8',
  pointLight: '#FDE047',
  directionalLight: '#FFF3C4',
  spotLight: '#38BDF8',
  areaLight: '#F8FAFC',
  camera: '#38BDF8',
  model: '#CBD5E1',
};

export function createDefaultNode(
  type: NodeType,
  id: string,
  name: string,
  options?: {
    parentId?: string | null;
    position?: Partial<Vec3>;
    rotation?: Partial<Vec3>;
    scale?: Partial<Vec3>;
    color?: string;
    roughness?: number;
    metalness?: number;
    transmission?: number;
    ior?: number;
    emissive?: string;
    emissiveIntensity?: number;
    intensity?: number;
    distance?: number;
    angle?: number;
    penumbra?: number;
    width?: number;
    height?: number;
    castShadow?: boolean;
    modelAsset?: ModelAssetRef;
  },
): SceneNode {
  const defaultY =
    type === 'plane'
      ? 0
      : type === 'pointLight'
        ? 2.8
        : type === 'directionalLight'
          ? 5.0
          : type === 'spotLight'
            ? 3.8
            : type === 'areaLight'
              ? 3.2
              : type === 'camera'
                ? 2.0
                : type === 'model'
                  ? 0
                  : 0.6;

  const defaultRotX =
    type === 'plane'
      ? -90
      : type === 'camera'
        ? -18
        : type === 'directionalLight'
          ? -52
          : type === 'spotLight'
            ? -62
            : type === 'areaLight'
              ? -70
              : 0;

  const defaultRotY =
    type === 'camera' ? 38 : type === 'directionalLight' ? 35 : type === 'spotLight' ? -25 : 0;

  const base: SceneNode = {
    id,
    name,
    type,
    parentId: options?.parentId ?? null,
    visible: true,
    locked: false,
    transform: {
      position: {
        x:
          options?.position?.x ??
          (type === 'camera'
            ? 3.2
            : type === 'directionalLight'
              ? 4
              : type === 'spotLight'
                ? -2.2
                : 0),
        y: options?.position?.y ?? defaultY,
        z:
          options?.position?.z ??
          (type === 'camera'
            ? 3.8
            : type === 'directionalLight'
              ? 4
              : type === 'spotLight'
                ? 2.4
                : 0),
      },
      rotation: {
        x: options?.rotation?.x ?? defaultRotX,
        y: options?.rotation?.y ?? defaultRotY,
        z: options?.rotation?.z ?? 0,
      },
      scale: {
        x: options?.scale?.x ?? (type === 'plane' ? 4 : 1),
        y: options?.scale?.y ?? (type === 'plane' ? 4 : 1),
        z: options?.scale?.z ?? 1,
      },
    },
  };

  if (type === 'pointLight') {
    base.light = {
      color: options?.color ?? DEFAULT_COLORS.pointLight,
      intensity: options?.intensity ?? 8,
      distance: options?.distance ?? 18,
      castShadow: options?.castShadow ?? true,
      softness: 0.18,
    };
  } else if (type === 'directionalLight') {
    base.light = {
      color: options?.color ?? DEFAULT_COLORS.directionalLight,
      intensity: options?.intensity ?? 2.2,
      distance: 40,
      castShadow: options?.castShadow ?? true,
      softness: 0.04,
    };
  } else if (type === 'spotLight') {
    base.light = {
      color: options?.color ?? DEFAULT_COLORS.spotLight,
      intensity: options?.intensity ?? 14,
      distance: options?.distance ?? 24,
      angle: options?.angle ?? 32,
      penumbra: options?.penumbra ?? 0.45,
      castShadow: options?.castShadow ?? true,
      softness: 0.14,
    };
  } else if (type === 'areaLight') {
    base.light = {
      color: options?.color ?? DEFAULT_COLORS.areaLight,
      intensity: options?.intensity ?? 6.5,
      distance: options?.distance ?? 20,
      width: options?.width ?? 2.4,
      height: options?.height ?? 1.6,
      castShadow: options?.castShadow ?? true,
      softness: 0.5,
    };
  } else if (type === 'camera') {
    base.camera = {
      fov: 50,
      near: 0.1,
      far: 150,
    };
  } else if (type === 'model') {
    base.modelAsset = options?.modelAsset;
  } else if (type !== 'group') {
    base.material = {
      color: options?.color ?? DEFAULT_COLORS[type],
      roughness: options?.roughness ?? 0.38,
      metalness: options?.metalness ?? 0.22,
      wireframe: false,
      transmission: options?.transmission ?? 0,
      ior: options?.ior ?? 1.5,
      emissive: options?.emissive ?? '#000000',
      emissiveIntensity: options?.emissiveIntensity ?? 0,
    };
  }

  return base;
}
