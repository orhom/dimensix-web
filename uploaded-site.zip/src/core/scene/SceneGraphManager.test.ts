import test from 'node:test';
import assert from 'node:assert/strict';
import { SceneGraphManager } from './SceneGraphManager';

test('SceneGraphManager adds, selects, transforms, and undoes/redoes nodes', () => {
  const manager = new SceneGraphManager();

  const cube = manager.addNode('box', 'Hero Cube');
  assert.equal(manager.getNodes().length, 1);
  assert.equal(manager.getSelectedId(), cube.id);
  assert.equal(manager.canUndo(), true);

  manager.updateTransform(cube.id, { position: { x: 2.5, y: 1 } });
  assert.equal(manager.getNode(cube.id)?.transform.position.x, 2.5);

  const undone = manager.undo();
  assert.ok(undone);
  assert.equal(manager.getNode(cube.id)?.transform.position.x, 0);
  assert.equal(manager.canRedo(), true);

  const redone = manager.redo();
  assert.ok(redone);
  assert.equal(manager.getNode(cube.id)?.transform.position.x, 2.5);
});

test('SceneGraphManager prevents cyclic reparenting and cascades subtree removal', () => {
  const manager = new SceneGraphManager();
  const parent = manager.addNode('group', 'Rig');
  const child = manager.addNode('sphere', 'Joint', { parentId: parent.id });

  // Attempt to make parent a child of its own child
  const cyclic = manager.reparentNode(parent.id, child.id);
  assert.equal(cyclic, false);

  // Removing parent removes child too
  const removed = manager.removeNode(parent.id);
  assert.deepEqual(removed.sort(), [child.id, parent.id].sort());
  assert.equal(manager.getNodes().length, 0);
});

test('SceneGraphManager duplicates subtrees with fresh IDs and updates material/light', () => {
  const manager = new SceneGraphManager();
  const group = manager.addNode('group', 'Cluster');
  const orb = manager.addNode('sphere', 'Orb', { parentId: group.id });
  manager.updateMaterial(orb.id, { color: '#22D3EE', roughness: 0.15 });

  const copyGroup = manager.duplicateNode(group.id);
  assert.ok(copyGroup);
  assert.notEqual(copyGroup.id, group.id);
  assert.equal(manager.getNodes().length, 4);

  const copiedOrb = manager.getChildren(copyGroup.id)[0];
  assert.ok(copiedOrb);
  assert.notEqual(copiedOrb.id, orb.id);
  assert.equal(copiedOrb.material?.color, '#22D3EE');
});
