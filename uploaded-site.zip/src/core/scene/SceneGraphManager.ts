import {
  cloneNode,
  cloneSnapshot,
  createDefaultNode,
  type CameraNodeData,
  type LightData,
  type MaterialData,
  type NodeType,
  type SceneNode,
  type SceneSnapshot,
  type TransformData,
  type Vec3,
} from './SceneNode';

const MAX_HISTORY = 100;

export class SceneGraphManager {
  private nodes: SceneNode[] = [];
  private selectedId: string | null = null;
  private undoStack: SceneSnapshot[] = [];
  private redoStack: SceneSnapshot[] = [];
  private idCounter = 1;

  constructor(initialSnapshot?: SceneSnapshot) {
    if (initialSnapshot) {
      this.loadSnapshot(initialSnapshot);
    }
  }

  loadSnapshot(snapshot: SceneSnapshot): void {
    const cloned = cloneSnapshot(snapshot);
    this.nodes = cloned.nodes;
    this.selectedId =
      cloned.selectedId && this.nodes.some((n) => n.id === cloned.selectedId)
        ? cloned.selectedId
        : null;
    this.undoStack = [];
    this.redoStack = [];
    this.syncIdCounter();
  }

  getSnapshot(): SceneSnapshot {
    return cloneSnapshot({
      nodes: this.nodes,
      selectedId: this.selectedId,
    });
  }

  getNodes(): SceneNode[] {
    return this.nodes.map(cloneNode);
  }

  getNode(id: string): SceneNode | null {
    const found = this.nodes.find((n) => n.id === id);
    return found ? cloneNode(found) : null;
  }

  getSelectedId(): string | null {
    return this.selectedId;
  }

  getSelectedNode(): SceneNode | null {
    return this.selectedId ? this.getNode(this.selectedId) : null;
  }

  getChildren(parentId: string | null): SceneNode[] {
    return this.nodes.filter((n) => n.parentId === parentId).map(cloneNode);
  }

  canUndo(): boolean {
    return this.undoStack.length > 0;
  }

  canRedo(): boolean {
    return this.redoStack.length > 0;
  }

  selectNode(id: string | null): SceneNode | null {
    if (id !== null && !this.nodes.some((n) => n.id === id)) {
      return this.getSelectedNode();
    }
    this.selectedId = id;
    return this.getSelectedNode();
  }

  addNode(
    type: NodeType,
    name?: string,
    options?: {
      parentId?: string | null;
      position?: Partial<Vec3>;
      rotation?: Partial<Vec3>;
      scale?: Partial<Vec3>;
      color?: string;
      select?: boolean;
      modelAsset?: SceneNode['modelAsset'];
    },
  ): SceneNode {
    this.pushUndo();
    const id = this.generateId(type);
    const resolvedName = name?.trim() || this.generateDefaultName(type);
    const parentId =
      options?.parentId && this.nodes.some((n) => n.id === options.parentId)
        ? options.parentId
        : null;

    const node = createDefaultNode(type, id, resolvedName, {
      parentId,
      position: options?.position,
      rotation: options?.rotation,
      scale: options?.scale,
      color: options?.color,
      modelAsset: options?.modelAsset,
    });
    this.nodes.push(node);
    if (options?.select !== false) {
      this.selectedId = node.id;
    }
    return cloneNode(node);
  }

  duplicateNode(id: string): SceneNode | null {
    const source = this.nodes.find((n) => n.id === id);
    if (!source) return null;

    this.pushUndo();
    const idMap = new Map<string, string>();
    const subtree = this.collectSubtreeIds(id);
    const created: SceneNode[] = [];

    for (const oldId of subtree) {
      const original = this.nodes.find((n) => n.id === oldId);
      if (!original) continue;
      const newId = this.generateId(original.type);
      idMap.set(oldId, newId);
    }

    for (const oldId of subtree) {
      const original = this.nodes.find((n) => n.id === oldId);
      if (!original) continue;
      const copy = cloneNode(original);
      copy.id = idMap.get(oldId)!;
      if (oldId === id) {
        copy.name = `${original.name} (Copy)`;
        copy.transform.position.x = Number((copy.transform.position.x + 0.8).toFixed(3));
        copy.transform.position.z = Number((copy.transform.position.z + 0.8).toFixed(3));
      } else if (copy.parentId && idMap.has(copy.parentId)) {
        copy.parentId = idMap.get(copy.parentId)!;
      }
      this.nodes.push(copy);
      created.push(copy);
    }

    const rootCopy = created[0] ?? null;
    if (rootCopy) {
      this.selectedId = rootCopy.id;
      return cloneNode(rootCopy);
    }
    return null;
  }

  removeNode(id: string): string[] {
    if (!this.nodes.some((n) => n.id === id)) return [];

    this.pushUndo();
    const toRemove = new Set(this.collectSubtreeIds(id));
    this.nodes = this.nodes.filter((n) => !toRemove.has(n.id));
    if (this.selectedId && toRemove.has(this.selectedId)) {
      this.selectedId = this.nodes[0]?.id ?? null;
    }
    return [...toRemove];
  }

  renameNode(id: string, nextName: string): SceneNode | null {
    const trimmed = nextName.trim();
    if (!trimmed) return null;
    const target = this.nodes.find((n) => n.id === id);
    if (!target || target.name === trimmed) return null;

    this.pushUndo();
    target.name = trimmed;
    return cloneNode(target);
  }

  setVisibility(id: string, visible: boolean): SceneNode | null {
    const target = this.nodes.find((n) => n.id === id);
    if (!target || target.visible === visible) return null;

    this.pushUndo();
    target.visible = visible;
    return cloneNode(target);
  }

  setLocked(id: string, locked: boolean): SceneNode | null {
    const target = this.nodes.find((n) => n.id === id);
    if (!target || target.locked === locked) return null;

    this.pushUndo();
    target.locked = locked;
    return cloneNode(target);
  }

  reparentNode(id: string, newParentId: string | null): boolean {
    const target = this.nodes.find((n) => n.id === id);
    if (!target) return false;
    if (target.parentId === newParentId) return false;
    if (newParentId !== null) {
      const parent = this.nodes.find((n) => n.id === newParentId);
      if (!parent) return false;
      const subtree = new Set(this.collectSubtreeIds(id));
      if (subtree.has(newParentId)) return false; // Prevent cycles
    }

    this.pushUndo();
    target.parentId = newParentId;
    return true;
  }

  updateTransform(
    id: string,
    patch: Partial<{ position: Partial<Vec3>; rotation: Partial<Vec3>; scale: Partial<Vec3> }>,
    recordHistory = true,
  ): SceneNode | null {
    const target = this.nodes.find((n) => n.id === id);
    if (!target || target.locked) return null;

    if (recordHistory) {
      this.pushUndo();
    }

    const next: TransformData = {
      position: { ...target.transform.position, ...patch.position },
      rotation: { ...target.transform.rotation, ...patch.rotation },
      scale: { ...target.transform.scale, ...patch.scale },
    };

    // Guard against zero scale collapsing matrices
    next.scale.x = Math.abs(next.scale.x) < 0.01 ? 0.01 : next.scale.x;
    next.scale.y = Math.abs(next.scale.y) < 0.01 ? 0.01 : next.scale.y;
    next.scale.z = Math.abs(next.scale.z) < 0.01 ? 0.01 : next.scale.z;

    target.transform = next;
    return cloneNode(target);
  }

  resetTransform(id: string): SceneNode | null {
    const target = this.nodes.find((n) => n.id === id);
    if (!target || target.locked) return null;

    this.pushUndo();
    target.transform = {
      position: { x: 0, y: target.type === 'plane' || target.type === 'model' ? 0 : 0.6, z: 0 },
      rotation: { x: target.type === 'plane' ? -90 : 0, y: 0, z: 0 },
      scale: { x: target.type === 'plane' ? 4 : 1, y: target.type === 'plane' ? 4 : 1, z: 1 },
    };
    return cloneNode(target);
  }

  updateMaterial(id: string, patch: Partial<MaterialData>, recordHistory = true): SceneNode | null {
    const target = this.nodes.find((n) => n.id === id);
    if (!target || !target.material) return null;

    if (recordHistory) {
      this.pushUndo();
    }

    target.material = {
      ...target.material,
      ...patch,
      roughness: clamp(patch.roughness ?? target.material.roughness, 0, 1),
      metalness: clamp(patch.metalness ?? target.material.metalness, 0, 1),
      transmission: clamp(patch.transmission ?? target.material.transmission ?? 0, 0, 1),
      ior: clamp(patch.ior ?? target.material.ior ?? 1.5, 1.0, 2.5),
      emissiveIntensity: clamp(patch.emissiveIntensity ?? target.material.emissiveIntensity ?? 0, 0, 10),
    };
    return cloneNode(target);
  }

  updateLight(id: string, patch: Partial<LightData>, recordHistory = true): SceneNode | null {
    const target = this.nodes.find((n) => n.id === id);
    if (!target || !target.light) return null;

    if (recordHistory) {
      this.pushUndo();
    }

    target.light = {
      ...target.light,
      ...patch,
      intensity: clamp(patch.intensity ?? target.light.intensity, 0, 40),
      distance: clamp(patch.distance ?? target.light.distance, 1, 100),
      angle:
        patch.angle !== undefined || target.light.angle !== undefined
          ? clamp(patch.angle ?? target.light.angle ?? 32, 5, 85)
          : undefined,
      penumbra:
        patch.penumbra !== undefined || target.light.penumbra !== undefined
          ? clamp(patch.penumbra ?? target.light.penumbra ?? 0.45, 0, 1)
          : undefined,
      width:
        patch.width !== undefined || target.light.width !== undefined
          ? clamp(patch.width ?? target.light.width ?? 2.4, 0.2, 20)
          : undefined,
      height:
        patch.height !== undefined || target.light.height !== undefined
          ? clamp(patch.height ?? target.light.height ?? 1.6, 0.2, 20)
          : undefined,
      softness:
        patch.softness !== undefined || target.light.softness !== undefined
          ? clamp(patch.softness ?? target.light.softness ?? 0.15, 0, 2)
          : undefined,
    };
    return cloneNode(target);
  }

  updateCamera(id: string, patch: Partial<CameraNodeData>, recordHistory = true): SceneNode | null {
    const target = this.nodes.find((n) => n.id === id);
    if (!target || !target.camera) return null;

    if (recordHistory) {
      this.pushUndo();
    }

    const near = clamp(patch.near ?? target.camera.near, 0.01, 10);
    const far = clamp(patch.far ?? target.camera.far, near + 5, 1000);
    target.camera = {
      ...target.camera,
      ...patch,
      fov: clamp(patch.fov ?? target.camera.fov, 20, 110),
      near,
      far,
    };
    return cloneNode(target);
  }

  recordHistoryCheckpoint(): void {
    this.pushUndo();
  }

  undo(): SceneSnapshot | null {
    const previous = this.undoStack.pop();
    if (!previous) return null;

    this.redoStack.push(this.getSnapshot());
    const restored = cloneSnapshot(previous);
    this.nodes = restored.nodes;
    this.selectedId =
      restored.selectedId && this.nodes.some((n) => n.id === restored.selectedId)
        ? restored.selectedId
        : null;
    return this.getSnapshot();
  }

  redo(): SceneSnapshot | null {
    const next = this.redoStack.pop();
    if (!next) return null;

    this.undoStack.push(this.getSnapshot());
    const restored = cloneSnapshot(next);
    this.nodes = restored.nodes;
    this.selectedId =
      restored.selectedId && this.nodes.some((n) => n.id === restored.selectedId)
        ? restored.selectedId
        : null;
    return this.getSnapshot();
  }

  private pushUndo(): void {
    this.undoStack.push(this.getSnapshot());
    if (this.undoStack.length > MAX_HISTORY) {
      this.undoStack.shift();
    }
    this.redoStack = [];
  }

  private collectSubtreeIds(rootId: string): string[] {
    const result: string[] = [rootId];
    const queue = [rootId];
    while (queue.length > 0) {
      const current = queue.shift()!;
      for (const node of this.nodes) {
        if (node.parentId === current) {
          result.push(node.id);
          queue.push(node.id);
        }
      }
    }
    return result;
  }

  private generateId(type: NodeType): string {
    let candidate = `${type}_${this.idCounter++}`;
    while (this.nodes.some((n) => n.id === candidate)) {
      candidate = `${type}_${this.idCounter++}`;
    }
    return candidate;
  }

  private generateDefaultName(type: NodeType): string {
    const prefixMap: Record<NodeType, string> = {
      box: 'Cube',
      sphere: 'Sphere',
      cylinder: 'Cylinder',
      cone: 'Cone',
      torus: 'Torus',
      plane: 'Plane',
      group: 'Group',
      pointLight: 'Point Light',
      directionalLight: 'Sun Light',
      spotLight: 'Spot Light',
      areaLight: 'Area Light',
      camera: 'Camera',
      model: 'Model',
    };
    const prefix = prefixMap[type];
    const existing = this.nodes.filter((n) => n.type === type).length;
    return `${prefix} ${existing + 1}`;
  }

  private syncIdCounter(): void {
    this.idCounter = this.nodes.length + 1;
  }
}

function clamp(val: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, val));
}
