import test from 'node:test';
import assert from 'node:assert/strict';
import { CameraController } from './CameraController';

test('CameraController allows unrestricted pitch past straight-down (-90deg) and straight-up (+90deg)', () => {
  const cam = new CameraController();
  cam.reset(true);

  // Rotate downward well past -90 degrees (-Math.PI/2) and even -180 degrees
  cam.rotate(0, -Math.PI * 0.75);
  const poseDown = cam.getPose();
  assert.ok(poseDown.pitch < -Math.PI / 2, 'Pitch should freely cross -90 degrees');
  assert.ok(Number.isFinite(poseDown.position.x));
  assert.ok(Number.isFinite(poseDown.position.y));
  assert.ok(Number.isFinite(poseDown.position.z));

  // Rotate upward past +90 degrees (+Math.PI/2)
  cam.rotate(0, Math.PI * 1.6);
  const poseUp = cam.getPose();
  assert.ok(poseUp.pitch > Math.PI / 2, 'Pitch should freely cross +90 degrees');
  assert.ok(Number.isFinite(poseUp.up.y));
});

test('CameraController free mode moves along rotated forward and right directions', () => {
  const cam = new CameraController();
  cam.reset(true);
  cam.setMode('free');

  // Turn 90 degrees left (yaw = +PI/2) -> forward becomes (-1, 0, 0) when pitch = 0
  cam.setPreset('side', true); // yaw = +PI/2, pitch = -0.08
  const before = cam.getPose();
  cam.moveFree(2, 0, 0);
  const after = cam.getPose();

  const dx = after.position.x - before.position.x;
  const dy = after.position.y - before.position.y;
  const dz = after.position.z - before.position.z;

  // Movement vector must match forward * 2
  assert.ok(Math.abs(dx - before.forward.x * 2) < 1e-4);
  assert.ok(Math.abs(dy - before.forward.y * 2) < 1e-4);
  assert.ok(Math.abs(dz - before.forward.z * 2) < 1e-4);
});

test('CameraController reset and focusOn update target and distance accurately', () => {
  const cam = new CameraController();
  cam.pan(100, 50);
  cam.zoom(1.0);
  cam.focusOn({ x: 3, y: 2, z: -1 }, 2, true);

  const focused = cam.getPose();
  assert.deepEqual(focused.target, { x: 3, y: 2, z: -1 });
  assert.ok(focused.distance >= 5.5);

  cam.reset(true);
  const resetPose = cam.getPose();
  assert.deepEqual(resetPose.target, { x: 0, y: 0.5, z: 0 });
});
