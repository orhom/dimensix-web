export type CameraMode = 'orbit' | 'free';

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export interface Quat {
  x: number;
  y: number;
  z: number;
  w: number;
}

export interface CameraPose {
  position: Vec3;
  target: Vec3;
  orientation: Quat;
  up: Vec3;
  forward: Vec3;
  right: Vec3;
  distance: number;
  yaw: number;
  pitch: number;
  mode: CameraMode;
}

const DEFAULT_TARGET: Vec3 = { x: 0, y: 0.5, z: 0 };
const DEFAULT_YAW = 0.74;
const DEFAULT_PITCH = -0.44;
const DEFAULT_DISTANCE = 8.4;

export class CameraController {
  private mode: CameraMode = 'orbit';
  private target: Vec3 = { ...DEFAULT_TARGET };
  private yaw = DEFAULT_YAW;
  private pitch = DEFAULT_PITCH;
  private distance = DEFAULT_DISTANCE;

  private transition: {
    targetPos: Vec3;
    targetLook: Vec3;
    targetYaw: number;
    targetPitch: number;
    targetDistance: number;
  } | null = null;

  getMode(): CameraMode {
    return this.mode;
  }

  setMode(nextMode: CameraMode): void {
    if (this.mode === nextMode) return;
    this.transition = null;
    this.mode = nextMode;
  }

  getPose(): CameraPose {
    const orientation = computeYawPitchQuat(this.yaw, this.pitch);
    const right = rotateVectorByQuat({ x: 1, y: 0, z: 0 }, orientation);
    const up = rotateVectorByQuat({ x: 0, y: 1, z: 0 }, orientation);
    const forward = rotateVectorByQuat({ x: 0, y: 0, z: -1 }, orientation);
    const position: Vec3 = {
      x: this.target.x - forward.x * this.distance,
      y: this.target.y - forward.y * this.distance,
      z: this.target.z - forward.z * this.distance,
    };

    return {
      position,
      target: { ...this.target },
      orientation,
      up,
      forward,
      right,
      distance: this.distance,
      yaw: this.yaw,
      pitch: this.pitch,
      mode: this.mode,
    };
  }

  getState(): {
    mode: CameraMode;
    target: Vec3;
    yaw: number;
    pitch: number;
    distance: number;
  } {
    return {
      mode: this.mode,
      target: { ...this.target },
      yaw: this.yaw,
      pitch: this.pitch,
      distance: this.distance,
    };
  }

  setState(state: {
    mode: CameraMode;
    target: Vec3;
    yaw: number;
    pitch: number;
    distance: number;
  }): void {
    this.transition = null;
    this.mode = state.mode;
    this.target = { ...state.target };
    this.yaw = state.yaw;
    this.pitch = state.pitch;
    this.distance = clamp(state.distance, 0.35, 180);
  }

  /**
   * Unrestricted 360-degree rotation around the target (in orbit mode)
   * or around the camera eye (in free mode). No pitch clamping!
   */
  rotate(deltaYaw: number, deltaPitch: number): void {
    this.transition = null;
    const prevPose = this.getPose();

    // Keep horizontal drag natural even when camera is upside down
    const cosPitch = Math.cos(this.pitch);
    const yawSign = cosPitch >= 0 ? 1 : -1;

    this.yaw += deltaYaw * yawSign;
    this.pitch += deltaPitch;

    if (this.mode === 'free') {
      // Keep eye position anchored; move target in front of the newly rotated camera
      const nextOrientation = computeYawPitchQuat(this.yaw, this.pitch);
      const nextForward = rotateVectorByQuat({ x: 0, y: 0, z: -1 }, nextOrientation);
      this.target = {
        x: prevPose.position.x + nextForward.x * this.distance,
        y: prevPose.position.y + nextForward.y * this.distance,
        z: prevPose.position.z + nextForward.z * this.distance,
      };
    }
  }

  /**
   * Pan along the camera's true rotated right & up axes.
   */
  pan(deltaRight: number, deltaUp: number): void {
    this.transition = null;
    const pose = this.getPose();
    const scale = Math.max(this.distance * 0.0022, 0.002);

    this.target.x += (-pose.right.x * deltaRight + pose.up.x * deltaUp) * scale;
    this.target.y += (-pose.right.y * deltaRight + pose.up.y * deltaUp) * scale;
    this.target.z += (-pose.right.z * deltaRight + pose.up.z * deltaUp) * scale;
  }

  /**
   * Zoom smoothly in orbit mode or dolly along forward vector in free mode.
   */
  zoom(delta: number): void {
    this.transition = null;
    if (this.mode === 'orbit') {
      const factor = Math.exp(clamp(delta, -0.6, 0.6));
      this.distance = clamp(this.distance * factor, 0.35, 180);
    } else {
      const pose = this.getPose();
      const step = -delta * Math.max(this.distance * 0.35, 0.6);
      this.target.x += pose.forward.x * step;
      this.target.y += pose.forward.y * step;
      this.target.z += pose.forward.z * step;
    }
  }

  /**
   * Move freely along camera-relative forward, right, and up axes.
   * Preserves direction accurately regardless of pitch/yaw rotation.
   */
  moveFree(forwardAmount: number, rightAmount: number, upAmount: number): void {
    this.transition = null;
    const pose = this.getPose();
    this.target.x +=
      pose.forward.x * forwardAmount + pose.right.x * rightAmount + pose.up.x * upAmount;
    this.target.y +=
      pose.forward.y * forwardAmount + pose.right.y * rightAmount + pose.up.y * upAmount;
    this.target.z +=
      pose.forward.z * forwardAmount + pose.right.z * rightAmount + pose.up.z * upAmount;
  }

  setPreset(preset: 'perspective' | 'top' | 'front' | 'side', immediate = false): void {
    let nextYaw = DEFAULT_YAW;
    let nextPitch = DEFAULT_PITCH;

    switch (preset) {
      case 'top':
        nextYaw = 0;
        nextPitch = -Math.PI / 2;
        break;
      case 'front':
        nextYaw = 0;
        nextPitch = -0.08;
        break;
      case 'side':
        nextYaw = Math.PI / 2;
        nextPitch = -0.08;
        break;
      case 'perspective':
      default:
        nextYaw = DEFAULT_YAW;
        nextPitch = DEFAULT_PITCH;
        break;
    }

    if (immediate) {
      this.yaw = nextYaw;
      this.pitch = nextPitch;
      this.transition = null;
      return;
    }

    this.transition = {
      targetLook: { ...this.target },
      targetPos: { ...this.target },
      targetYaw: nextYaw,
      targetPitch: nextPitch,
      targetDistance: this.distance,
    };
  }

  reset(immediate = false): void {
    if (immediate) {
      this.target = { ...DEFAULT_TARGET };
      this.yaw = DEFAULT_YAW;
      this.pitch = DEFAULT_PITCH;
      this.distance = DEFAULT_DISTANCE;
      this.transition = null;
      return;
    }

    this.transition = {
      targetLook: { ...DEFAULT_TARGET },
      targetPos: { ...DEFAULT_TARGET },
      targetYaw: DEFAULT_YAW,
      targetPitch: DEFAULT_PITCH,
      targetDistance: DEFAULT_DISTANCE,
    };
  }

  focusOn(center: Vec3, radius = 1.5, immediate = false): void {
    const nextDist = clamp(radius * 2.8, 2.8, 45);
    if (immediate) {
      this.target = { ...center };
      this.distance = nextDist;
      this.transition = null;
      return;
    }

    this.transition = {
      targetLook: { ...center },
      targetPos: { ...center },
      targetYaw: this.yaw,
      targetPitch: this.pitch,
      targetDistance: nextDist,
    };
  }

  alignToPose(position: Vec3, rotationDeg: Vec3): void {
    this.transition = null;
    this.yaw = (rotationDeg.y * Math.PI) / 180;
    this.pitch = (rotationDeg.x * Math.PI) / 180;
    const orientation = computeYawPitchQuat(this.yaw, this.pitch);
    const forward = rotateVectorByQuat({ x: 0, y: 0, z: -1 }, orientation);
    this.target = {
      x: position.x + forward.x * this.distance,
      y: position.y + forward.y * this.distance,
      z: position.z + forward.z * this.distance,
    };
  }

  /**
   * Advances active camera transition with frame-rate-independent damping.
   * Returns true while still animating.
   */
  stepTransition(dt: number, snapImmediate = false): boolean {
    if (!this.transition) return false;

    if (snapImmediate) {
      this.target = { ...this.transition.targetLook };
      this.yaw = this.transition.targetYaw;
      this.pitch = this.transition.targetPitch;
      this.distance = this.transition.targetDistance;
      this.transition = null;
      return false;
    }

    const alpha = 1 - Math.exp(-10 * clamp(dt, 0.001, 0.05));
    this.target.x = lerp(this.target.x, this.transition.targetLook.x, alpha);
    this.target.y = lerp(this.target.y, this.transition.targetLook.y, alpha);
    this.target.z = lerp(this.target.z, this.transition.targetLook.z, alpha);
    this.yaw = lerp(this.yaw, this.transition.targetYaw, alpha);
    this.pitch = lerp(this.pitch, this.transition.targetPitch, alpha);
    this.distance = lerp(this.distance, this.transition.targetDistance, alpha);

    const settled =
      Math.abs(this.target.x - this.transition.targetLook.x) < 0.005 &&
      Math.abs(this.target.y - this.transition.targetLook.y) < 0.005 &&
      Math.abs(this.target.z - this.transition.targetLook.z) < 0.005 &&
      Math.abs(this.yaw - this.transition.targetYaw) < 0.003 &&
      Math.abs(this.pitch - this.transition.targetPitch) < 0.003 &&
      Math.abs(this.distance - this.transition.targetDistance) < 0.01;

    if (settled) {
      this.target = { ...this.transition.targetLook };
      this.yaw = this.transition.targetYaw;
      this.pitch = this.transition.targetPitch;
      this.distance = this.transition.targetDistance;
      this.transition = null;
      return false;
    }

    return true;
  }

  hasActiveTransition(): boolean {
    return this.transition !== null;
  }
}

/**
 * Computes quaternion = Q_yaw(Y) * Q_pitch(X) without gimbal clamp.
 */
export function computeYawPitchQuat(yaw: number, pitch: number): Quat {
  const hy = yaw * 0.5;
  const hp = pitch * 0.5;

  const sy = Math.sin(hy);
  const cy = Math.cos(hy);
  const sp = Math.sin(hp);
  const cp = Math.cos(hp);

  // qYaw = (0, sy, 0, cy), qPitch = (sp, 0, 0, cp)
  // q = qYaw * qPitch
  return normalizeQuat({
    x: cy * sp,
    y: sy * cp,
    z: -sy * sp,
    w: cy * cp,
  });
}

export function rotateVectorByQuat(v: Vec3, q: Quat): Vec3 {
  const ix = q.w * v.x + q.y * v.z - q.z * v.y;
  const iy = q.w * v.y + q.z * v.x - q.x * v.z;
  const iz = q.w * v.z + q.x * v.y - q.y * v.x;
  const iw = -q.x * v.x - q.y * v.y - q.z * v.z;

  return {
    x: ix * q.w + iw * -q.x + iy * -q.z - iz * -q.y,
    y: iy * q.w + iw * -q.y + iz * -q.x - ix * -q.z,
    z: iz * q.w + iw * -q.z + ix * -q.y - iy * -q.x,
  };
}

function normalizeQuat(q: Quat): Quat {
  const len = Math.hypot(q.x, q.y, q.z, q.w) || 1;
  return {
    x: q.x / len,
    y: q.y / len,
    z: q.z / len,
    w: q.w / len,
  };
}

function clamp(v: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, v));
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}
