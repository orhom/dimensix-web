import { ModelAssetRegistry } from '../assets/ModelAssetRegistry';
import {
  base64ToArrayBuffer,
  importModelFile as parseUploadedModelFile,
  ModelImportError,
  parseModelFromBuffer,
} from '../assets/ModelImporter';
import { buildShowcaseGlbBuffer } from '../assets/SampleGlbGenerator';
import { CameraController, type CameraMode } from '../camera/CameraController';
import type { EditorEventMap } from '../events/EditorEvents';
import { EventBus } from '../events/EventBus';
import {
  createNewProject,
  LocalStorageProjectStorage,
  SHOWCASE_GLB_ASSET_ID,
  type IProjectStorage,
} from '../project/ProjectStorage';
import {
  DEFAULT_EDITOR_SETTINGS,
  type DimensiXProject,
  type EditorSettings,
  type EmbeddedModelAsset,
  type ProjectSummary,
  type ProjectTemplateId,
} from '../project/ProjectTypes';
import type {
  CameraPoseState,
  CameraPreset,
  EngineMemoryStats,
  IRenderEngine,
  PathTracerStatus,
  RenderEngineDescriptor,
  TransformMode,
  ViewportCallbacks,
} from '../rendering/IRenderEngine';
import { clampSampleCount } from '../rendering/AspectAndResolution';
import {
  PATH_TRACING_DESCRIPTOR,
  PathTracingViewportEngine,
} from '../rendering/PathTracingViewportEngine';
import { RenderEngineRegistry } from '../rendering/RenderEngineRegistry';
import {
  RenderSettingsManager,
  type RenderPresetId,
  type RenderSettings,
} from '../rendering/RenderSettings';
import {
  buildPackedSceneForPathTracer,
  PrimitiveGeometryCache,
} from '../rendering/SceneBridge';
import {
  runTiledPathTracingExportSession,
  type ExportPauseController,
  type TiledExportProgressEvent,
  type TileOutputUpdate,
} from '../rendering/TiledPathTracingExportSession';
import {
  THREE_FOUNDATION_DESCRIPTOR,
  ThreeViewportEngine,
} from '../rendering/ThreeViewportEngine';
import { SceneGraphManager } from '../scene/SceneGraphManager';
import type {
  CameraNodeData,
  LightData,
  MaterialData,
  NodeType,
  SceneNode,
  SceneSnapshot,
  TransformData,
  Vec3,
} from '../scene/SceneNode';

export class EditorEngine {
  readonly events = new EventBus<EditorEventMap>();
  readonly registry = new RenderEngineRegistry();
  readonly modelRegistry = new ModelAssetRegistry();

  private readonly sceneManager = new SceneGraphManager();
  private readonly renderSettingsManager = new RenderSettingsManager();
  private readonly storage: IProjectStorage;

  private activeProject: DimensiXProject;
  private settings: EditorSettings;
  private renderEngine: IRenderEngine | null = null;
  private viewportContainer: HTMLElement | null = null;
  private lastViewportErrorHandler: ((message: string) => void) | undefined;

  private transformMode: TransformMode = 'translate';
  private cameraMode: CameraMode = 'orbit';
  private preservedCameraState: CameraPoseState | null = null;
  private lastPathTracerStatus: PathTracerStatus | null = null;
  private isDirty = false;
  private lastSavedAt: number | null = null;

  constructor(storage?: IProjectStorage) {
    this.storage = storage ?? new LocalStorageProjectStorage();

    // Register both independent render engines sharing unified Scene & Asset Data
    this.registry.register(THREE_FOUNDATION_DESCRIPTOR, () => new ThreeViewportEngine());
    this.registry.register(PATH_TRACING_DESCRIPTOR, () => new PathTracingViewportEngine());

    this.settings = this.storage.loadSettings();
    if (!this.registry.has(this.settings.activeEngineId)) {
      this.settings.activeEngineId = THREE_FOUNDATION_DESCRIPTOR.id;
    }

    const activeId = this.storage.getActiveProjectId();
    const existing = activeId ? this.storage.loadProject(activeId) : null;
    if (existing) {
      this.activeProject = existing;
      this.lastSavedAt = existing.updatedAt;
    } else {
      const list = this.storage.listProjects();
      if (list.length > 0) {
        this.activeProject = this.storage.loadProject(list[0].id)!;
        this.lastSavedAt = this.activeProject.updatedAt;
      } else {
        const starter = createNewProject('مشهد العرض الفيزيائي', 'validation-showcase');
        this.activeProject = this.storage.saveProject(starter);
        this.lastSavedAt = this.activeProject.updatedAt;
      }
    }

    const storedRenderSettings =
      this.activeProject.renderSettings ?? this.storage.loadRenderSettings();
    this.renderSettingsManager.load(storedRenderSettings);
    this.sceneManager.loadSnapshot(this.activeProject.scene);

    void this.hydrateProjectAssets(this.activeProject);
  }

  // --- Viewport & Render Engine Lifecycle ---

  attachViewport(container: HTMLElement, onError?: (message: string) => void): void {
    this.viewportContainer = container;
    this.lastViewportErrorHandler = onError;
    this.mountActiveRenderEngine(onError);
  }

  detachViewport(): void {
    if (this.renderEngine) {
      this.preservedCameraState = this.renderEngine.getCameraState();
      this.renderEngine.unmount();
      this.renderEngine = null;
    }
    this.viewportContainer = null;
  }

  resizeViewport(width: number, height: number): void {
    this.renderEngine?.resize(width, height);
  }

  listRenderEngines(): RenderEngineDescriptor[] {
    return this.registry.listDescriptors();
  }

  getActiveEngineId(): string {
    return this.settings.activeEngineId;
  }

  getPathTracerStatus(): PathTracerStatus | null {
    return this.lastPathTracerStatus;
  }

  getMemoryStats(): EngineMemoryStats {
    return (
      this.renderEngine?.getMemoryStats() ?? {
        bvhBytes: 0,
        textureBytes: this.modelRegistry.getEstimatedMemoryBytes(),
        triangleCount: 0,
      }
    );
  }

  setActiveRenderEngine(engineId: string, onError?: (message: string) => void): void {
    if (!this.registry.has(engineId)) return;
    if (this.settings.activeEngineId === engineId && this.renderEngine) return;

    if (this.renderEngine) {
      this.preservedCameraState = this.renderEngine.getCameraState();
    }

    this.updateSettings({ activeEngineId: engineId });
    if (this.viewportContainer) {
      this.mountActiveRenderEngine(onError ?? this.lastViewportErrorHandler);
    }
    this.events.emit('engine:changed', { engineId });
  }

  private mountActiveRenderEngine(onError?: (message: string) => void): void {
    if (!this.viewportContainer) return;

    if (this.renderEngine) {
      this.preservedCameraState = this.renderEngine.getCameraState();
      this.renderEngine.unmount();
    }

    const engine = this.registry.create(this.settings.activeEngineId);
    this.renderEngine = engine;
    engine.setAssetRegistry(this.modelRegistry);

    let transformCheckpointOpen = false;

    const callbacks: ViewportCallbacks = {
      onNodeSelected: (nodeId) => {
        this.selectNode(nodeId);
      },
      onNodeTransformPreview: (nodeId, transform) => {
        if (!transformCheckpointOpen) {
          this.sceneManager.recordHistoryCheckpoint();
          transformCheckpointOpen = true;
        }
        const updated = this.sceneManager.updateTransform(nodeId, transform, false);
        if (updated) {
          this.markDirty();
          this.events.emit('node:updated', { node: updated });
          this.emitHistoryChanged();
        }
      },
      onNodeTransformCommit: (nodeId, transform) => {
        const updated = this.sceneManager.updateTransform(nodeId, transform, false);
        transformCheckpointOpen = false;
        if (updated) {
          this.markDirty();
          this.emitSceneChanged('transform-gizmo');
          this.renderEngine?.syncScene(this.sceneManager.getSnapshot());
        }
      },
      onPathTracerStatus: (status) => {
        this.lastPathTracerStatus = status;
        this.events.emit('pathtracer:status', status);
      },
      onEngineError: onError,
    };

    engine.mount(this.viewportContainer, callbacks);
    engine.setViewportSettings({
      showGrid: this.settings.showGrid,
      showAxes: this.settings.showAxes,
      snapToGrid: this.settings.snapToGrid,
      fov: this.settings.fov,
    });
    engine.setRenderSettings(this.renderSettingsManager.getSettings());
    engine.setCameraMode(this.cameraMode);
    engine.setTransformMode(this.transformMode);
    if (this.preservedCameraState) {
      engine.setCameraState(this.preservedCameraState);
      this.cameraMode = this.preservedCameraState.mode;
    }
    engine.syncScene(this.sceneManager.getSnapshot());
  }

  // --- Model Import & Asset Hydration ---

  async importModelFile(file: File): Promise<SceneNode> {
    try {
      const asset = await parseUploadedModelFile(file);
      this.modelRegistry.register(asset);

      const cleanTitle = file.name.replace(/\.[^/.]+$/, '') || 'Imported Model';
      const node = this.sceneManager.addNode('model', cleanTitle, {
        modelAsset: {
          assetId: asset.assetId,
          fileName: asset.fileName,
          format: asset.format,
          meshCount: asset.meshCount,
          triangleCount: asset.triangleCount,
          partNames: asset.partNames,
        },
      });

      this.markDirty();
      this.renderEngine?.syncScene(this.sceneManager.getSnapshot());
      this.events.emit('node:added', { node });
      this.emitSceneChanged('import-model');
      this.events.emit('selection:changed', { selectedId: node.id, node });
      return node;
    } catch (err) {
      const message =
        err instanceof ModelImportError
          ? err.message
          : err instanceof Error
            ? err.message
            : 'Failed to import 3D model.';
      this.events.emit('model:importError', { message });
      throw err;
    }
  }

  async hydrateProjectAssets(project: DimensiXProject): Promise<void> {
    const neededAssetIds = new Set<string>();
    for (const node of project.scene.nodes) {
      if (node.type === 'model' && node.modelAsset?.assetId) {
        neededAssetIds.add(node.modelAsset.assetId);
      }
    }
    if (neededAssetIds.size === 0) return;

    let hydratedAny = false;

    if (neededAssetIds.has(SHOWCASE_GLB_ASSET_ID) && !this.modelRegistry.has(SHOWCASE_GLB_ASSET_ID)) {
      try {
        const asset = await parseModelFromBuffer(
          buildShowcaseGlbBuffer(),
          'precision_artifact.glb',
          { assetId: SHOWCASE_GLB_ASSET_ID },
        );
        this.modelRegistry.register(asset);
        hydratedAny = true;
      } catch {
        // Ignore if test env lacks parser support
      }
    }

    if (project.embeddedAssets) {
      for (const emb of project.embeddedAssets) {
        if (!neededAssetIds.has(emb.assetId) || this.modelRegistry.has(emb.assetId)) continue;
        try {
          const buf = base64ToArrayBuffer(emb.base64);
          const asset = await parseModelFromBuffer(buf, emb.fileName, {
            assetId: emb.assetId,
            encodeBase64: true,
          });
          this.modelRegistry.register(asset);
          hydratedAny = true;
        } catch {
          // Leave missing if corrupted
        }
      }
    }

    if (hydratedAny && this.activeProject.id === project.id) {
      this.renderEngine?.syncScene(this.sceneManager.getSnapshot());
    }
  }

  // --- Clean Offscreen Render / Image Export ---

  async exportRenderImage(options: {
    engineId: string;
    width: number;
    height: number;
    samples: number;
    targetCanvas?: HTMLCanvasElement;
    onTileOutput?: (tile: TileOutputUpdate) => void;
    onTiledProgress?: (event: TiledExportProgressEvent) => void;
    onProgress?: (progress01: number, currentSample: number, totalSamples: number) => void;
    pauseController?: ExportPauseController;
    signal?: AbortSignal;
  }): Promise<Blob> {
    const renderSettings = this.renderSettingsManager.getSettings();
    const snapshot = this.sceneManager.getSnapshot();
    const camState = this.renderEngine?.getCameraState() ?? this.preservedCameraState;

    // Pause active viewport loop to eliminate WebGL context contention and memory spikes
    this.renderEngine?.setPaused?.(true);

    try {
      // Fast direct path when exporting with the currently mounted viewport engine
      if (options.engineId === this.settings.activeEngineId && this.renderEngine) {
        return await this.renderEngine.exportImage({
          width: options.width,
          height: options.height,
          samples: options.samples,
          renderSettings,
          targetCanvas: options.targetCanvas,
          onTileOutput: options.onTileOutput,
          onTiledProgress: options.onTiledProgress,
          onProgress: options.onProgress,
          pauseController: options.pauseController,
          signal: options.signal,
        });
      }

      // Path Tracing export from Real-Time viewport: run dedicated lightweight chunked session
      // directly without mounting a duplicate full-viewport WebGLRenderer.
      if (options.engineId === PATH_TRACING_DESCRIPTOR.id) {
        const exportW = Math.max(64, Math.round(options.width));
        const exportH = Math.max(64, Math.round(options.height));
        const totalSamples = clampSampleCount(options.samples);

        const camCtrl = new CameraController();
        if (camState) camCtrl.setState(camState);
        const pose = camCtrl.getPose();

        const primCache = new PrimitiveGeometryCache();
        const exportCanvas = options.targetCanvas ?? document.createElement('canvas');
        if (exportCanvas.width !== exportW || exportCanvas.height !== exportH) {
          exportCanvas.width = exportW;
          exportCanvas.height = exportH;
        }
        const ctx = exportCanvas.getContext('2d');
        if (!ctx) throw new Error('Failed to create 2D export canvas.');
        ctx.fillStyle = '#090D16';
        ctx.fillRect(0, 0, exportW, exportH);

        try {
          const packedScene = buildPackedSceneForPathTracer(
            snapshot,
            this.modelRegistry,
            primCache,
          );

          await runTiledPathTracingExportSession({
            packedScene,
            cameraPose: pose,
            fovDeg: this.settings.fov,
            width: exportW,
            height: exportH,
            samples: totalSamples,
            renderSettings,
            pauseController: options.pauseController,
            signal: options.signal,
            onTileOutput: (tile) => {
              const imgData = ctx.createImageData(tile.tw, tile.th);
              imgData.data.set(tile.rgba8);
              ctx.putImageData(imgData, tile.tx, tile.tyTop);
              options.onTileOutput?.(tile);
            },
            onProgress: (ev) => {
              this.lastPathTracerStatus = {
                mode: 'exporting',
                samples: ev.currentSample,
                targetSamples: ev.totalSamples,
                sampleCap: ev.totalSamples,
                resolutionScale: 1,
                triangleCount: packedScene.gpuBvh.totalInstancedTriangles,
                bvhMemoryBytes: packedScene.gpuBvh.estimatedGpuBytes,
              };
              this.events.emit('pathtracer:status', this.lastPathTracerStatus);
              options.onTiledProgress?.(ev);
              options.onProgress?.(ev.progress01, ev.currentSample, ev.totalSamples);
            },
          });

          return await new Promise<Blob>((resolve, reject) => {
            exportCanvas.toBlob(
              (b) => (b ? resolve(b) : reject(new Error('Failed to encode exported PNG.'))),
              'image/png',
            );
          });
        } finally {
          primCache.dispose();
        }
      }

      // Isolated Real-Time export when Path Tracer is currently mounted in viewport
      const tempHost = document.createElement('div');
      tempHost.style.position = 'fixed';
      tempHost.style.left = '-99999px';
      tempHost.style.top = '-99999px';
      tempHost.style.width = `${Math.max(64, Math.min(options.width, 1920))}px`;
      tempHost.style.height = `${Math.max(64, Math.min(options.height, 1080))}px`;
      tempHost.style.pointerEvents = 'none';
      tempHost.style.opacity = '0';
      document.body.appendChild(tempHost);

      const tempEngine = this.registry.create(options.engineId);
      try {
        tempEngine.setAssetRegistry(this.modelRegistry);
        tempEngine.mount(tempHost, {
          onNodeSelected: () => {},
          onNodeTransformPreview: () => {},
          onNodeTransformCommit: () => {},
        });
        tempEngine.setViewportSettings({
          showGrid: false,
          showAxes: false,
          snapToGrid: false,
          fov: this.settings.fov,
        });
        tempEngine.setRenderSettings(renderSettings);
        if (camState) {
          tempEngine.setCameraState(camState);
        }
        tempEngine.syncScene(snapshot);

        return await tempEngine.exportImage({
          width: options.width,
          height: options.height,
          samples: options.samples,
          renderSettings,
          targetCanvas: options.targetCanvas,
          onProgress: options.onProgress,
          signal: options.signal,
        });
      } finally {
        tempEngine.unmount();
        tempHost.remove();
      }
    } finally {
      this.renderEngine?.setPaused?.(false);
    }
  }

  // --- Read Queries ---

  getSnapshot(): SceneSnapshot {
    return this.sceneManager.getSnapshot();
  }

  getNodes(): SceneNode[] {
    return this.sceneManager.getNodes();
  }

  getSelectedNode(): SceneNode | null {
    return this.sceneManager.getSelectedNode();
  }

  getTransformMode(): TransformMode {
    return this.transformMode;
  }

  getCameraMode(): CameraMode {
    return this.cameraMode;
  }

  getActiveProject(): DimensiXProject {
    return this.activeProject;
  }

  getSettings(): EditorSettings {
    return { ...this.settings };
  }

  getRenderSettings(): RenderSettings {
    return this.renderSettingsManager.getSettings();
  }

  canUndo(): boolean {
    return this.sceneManager.canUndo();
  }

  canRedo(): boolean {
    return this.sceneManager.canRedo();
  }

  getIsDirty(): boolean {
    return this.isDirty;
  }

  getLastSavedAt(): number | null {
    return this.lastSavedAt;
  }

  // --- Scene Editing Commands ---

  selectNode(id: string | null): void {
    const node = this.sceneManager.selectNode(id);
    this.renderEngine?.setSelection(node?.id ?? null);
    this.events.emit('selection:changed', {
      selectedId: node?.id ?? null,
      node,
    });
  }

  addNode(type: NodeType, name?: string, parentId?: string | null): SceneNode {
    const node = this.sceneManager.addNode(type, name, { parentId });
    this.markDirty();
    this.renderEngine?.syncScene(this.sceneManager.getSnapshot());
    this.events.emit('node:added', { node });
    this.emitSceneChanged('add-node');
    this.events.emit('selection:changed', { selectedId: node.id, node });
    return node;
  }

  duplicateSelected(): SceneNode | null {
    const selectedId = this.sceneManager.getSelectedId();
    if (!selectedId) return null;
    return this.duplicateNode(selectedId);
  }

  duplicateNode(id: string): SceneNode | null {
    const copy = this.sceneManager.duplicateNode(id);
    if (!copy) return null;
    this.markDirty();
    this.renderEngine?.syncScene(this.sceneManager.getSnapshot());
    this.emitSceneChanged('duplicate-node');
    this.events.emit('selection:changed', { selectedId: copy.id, node: copy });
    return copy;
  }

  removeNode(id: string): void {
    const removed = this.sceneManager.removeNode(id);
    if (removed.length === 0) return;
    this.markDirty();
    this.renderEngine?.syncScene(this.sceneManager.getSnapshot());
    this.events.emit('node:removed', { nodeId: id });
    this.emitSceneChanged('remove-node');
    const selected = this.sceneManager.getSelectedNode();
    this.events.emit('selection:changed', {
      selectedId: selected?.id ?? null,
      node: selected,
    });
  }

  renameNode(id: string, name: string): void {
    const updated = this.sceneManager.renameNode(id, name);
    if (!updated) return;
    this.markDirty();
    this.renderEngine?.updateNode(updated);
    this.emitSceneChanged('rename-node');
  }

  toggleVisibility(id: string): void {
    const current = this.sceneManager.getNode(id);
    if (!current) return;
    const updated = this.sceneManager.setVisibility(id, !current.visible);
    if (!updated) return;
    this.markDirty();
    this.renderEngine?.updateNode(updated);
    if (this.sceneManager.getSelectedId() === id) {
      this.renderEngine?.setSelection(id);
    }
    this.emitSceneChanged('toggle-visibility');
  }

  toggleLocked(id: string): void {
    const current = this.sceneManager.getNode(id);
    if (!current) return;
    const updated = this.sceneManager.setLocked(id, !current.locked);
    if (!updated) return;
    this.markDirty();
    this.emitSceneChanged('toggle-locked');
  }

  reparentNode(id: string, parentId: string | null): void {
    const changed = this.sceneManager.reparentNode(id, parentId);
    if (!changed) return;
    this.markDirty();
    this.renderEngine?.syncScene(this.sceneManager.getSnapshot());
    this.emitSceneChanged('reparent-node');
  }

  updateTransform(
    id: string,
    patch: Partial<{ position: Partial<Vec3>; rotation: Partial<Vec3>; scale: Partial<Vec3> }>,
  ): void {
    const updated = this.sceneManager.updateTransform(id, patch, true);
    if (!updated) return;
    this.markDirty();
    this.renderEngine?.updateNode(updated);
    this.events.emit('node:updated', { node: updated });
    this.emitSceneChanged('update-transform');
  }

  resetTransform(id: string): void {
    const updated = this.sceneManager.resetTransform(id);
    if (!updated) return;
    this.markDirty();
    this.renderEngine?.updateNode(updated);
    this.emitSceneChanged('reset-transform');
  }

  updateMaterial(id: string, patch: Partial<MaterialData>): void {
    const updated = this.sceneManager.updateMaterial(id, patch, true);
    if (!updated) return;
    this.markDirty();
    this.renderEngine?.updateNode(updated);
    this.emitSceneChanged('update-material');
  }

  updateLight(id: string, patch: Partial<LightData>): void {
    const updated = this.sceneManager.updateLight(id, patch, true);
    if (!updated) return;
    this.markDirty();
    this.renderEngine?.updateNode(updated);
    this.emitSceneChanged('update-light');
  }

  updateCameraNode(id: string, patch: Partial<CameraNodeData>): void {
    const updated = this.sceneManager.updateCamera(id, patch, true);
    if (!updated) return;
    this.markDirty();
    this.renderEngine?.updateNode(updated);
    this.emitSceneChanged('update-camera');
  }

  undo(): void {
    const restored = this.sceneManager.undo();
    if (!restored) return;
    this.markDirty();
    this.renderEngine?.syncScene(restored);
    this.emitSceneChanged('undo');
    const selected = this.sceneManager.getSelectedNode();
    this.events.emit('selection:changed', {
      selectedId: selected?.id ?? null,
      node: selected,
    });
  }

  redo(): void {
    const restored = this.sceneManager.redo();
    if (!restored) return;
    this.markDirty();
    this.renderEngine?.syncScene(restored);
    this.emitSceneChanged('redo');
    const selected = this.sceneManager.getSelectedNode();
    this.events.emit('selection:changed', {
      selectedId: selected?.id ?? null,
      node: selected,
    });
  }

  // --- Viewport & Camera Controls ---

  setTransformMode(mode: TransformMode): void {
    this.transformMode = mode;
    this.renderEngine?.setTransformMode(mode);
    this.events.emit('viewport:transformModeChanged', { mode });
  }

  setCameraMode(mode: CameraMode): void {
    this.cameraMode = mode;
    this.renderEngine?.setCameraMode(mode);
    this.events.emit('camera:modeChanged', { mode });
  }

  setCameraPreset(preset: CameraPreset): void {
    this.renderEngine?.setCameraPreset(preset);
  }

  moveCameraFree(forward: number, right: number, up: number): void {
    this.renderEngine?.moveCameraFree(forward, right, up);
  }

  resetCamera(): void {
    this.renderEngine?.resetCamera();
  }

  focusSelected(): void {
    this.renderEngine?.focusSelected();
  }

  alignViewToCameraNode(nodeId: string): void {
    this.renderEngine?.alignViewToNode(nodeId);
  }

  // --- Project Management ---

  listProjects(): ProjectSummary[] {
    return this.storage.listProjects();
  }

  createProject(name: string, template: ProjectTemplateId = 'studio-starter'): DimensiXProject {
    const project = createNewProject(name, template);
    const saved = this.storage.saveProject(project);
    this.applyLoadedProject(saved);
    return saved;
  }

  openProject(id: string): DimensiXProject | null {
    const loaded = this.storage.loadProject(id);
    if (!loaded) return null;
    this.storage.setActiveProjectId(loaded.id);
    this.applyLoadedProject(loaded);
    return loaded;
  }

  saveCurrentProject(): DimensiXProject {
    const snapshot = this.sceneManager.getSnapshot();
    const embeddedAssets: EmbeddedModelAsset[] = [];
    const seen = new Set<string>();
    let totalBase64Chars = 0;

    for (const node of snapshot.nodes) {
      if (node.type === 'model' && node.modelAsset && !seen.has(node.modelAsset.assetId)) {
        seen.add(node.modelAsset.assetId);
        if (node.modelAsset.assetId === SHOWCASE_GLB_ASSET_ID) continue;
        const asset = this.modelRegistry.get(node.modelAsset.assetId);
        if (asset?.rawBufferBase64 && totalBase64Chars + asset.rawBufferBase64.length < 1_800_000) {
          embeddedAssets.push({
            assetId: asset.assetId,
            fileName: asset.fileName,
            base64: asset.rawBufferBase64,
          });
          totalBase64Chars += asset.rawBufferBase64.length;
        }
      }
    }

    this.activeProject = {
      ...this.activeProject,
      scene: snapshot,
      renderSettings: this.renderSettingsManager.getSettings(),
      embeddedAssets: embeddedAssets.length > 0 ? embeddedAssets : undefined,
    };
    const saved = this.storage.saveProject(this.activeProject);
    this.activeProject = saved;
    this.isDirty = false;
    this.lastSavedAt = saved.updatedAt;
    this.events.emit('project:dirtyChanged', { isDirty: false });
    this.events.emit('project:saved', { project: saved, savedAt: saved.updatedAt });
    return saved;
  }

  renameCurrentProject(newName: string): void {
    const trimmed = newName.trim();
    if (!trimmed) return;
    this.activeProject = {
      ...this.activeProject,
      name: trimmed,
    };
    this.saveCurrentProject();
    this.events.emit('project:loaded', { project: this.activeProject });
  }

  deleteProject(id: string): void {
    const wasCurrent = this.activeProject.id === id;
    this.storage.deleteProject(id);
    if (wasCurrent) {
      const remaining = this.storage.listProjects();
      if (remaining.length > 0) {
        const next = this.storage.loadProject(remaining[0].id);
        if (next) {
          this.applyLoadedProject(next);
          return;
        }
      }
      this.createProject('مشهد العرض الفيزيائي', 'validation-showcase');
    }
  }

  // --- Settings & Render Settings ---

  updateSettings(patch: Partial<EditorSettings>): void {
    this.settings = {
      ...DEFAULT_EDITOR_SETTINGS,
      ...this.settings,
      ...patch,
    };
    this.storage.saveSettings(this.settings);
    this.renderEngine?.setViewportSettings({
      showGrid: this.settings.showGrid,
      showAxes: this.settings.showAxes,
      snapToGrid: this.settings.snapToGrid,
      fov: this.settings.fov,
    });
    this.events.emit('settings:changed', { settings: { ...this.settings } });
  }

  updateRenderSettings(patch: Partial<RenderSettings>): void {
    const next = this.renderSettingsManager.update(patch);
    this.storage.saveRenderSettings(next);
    this.markDirty();
    this.renderEngine?.setRenderSettings(next);
    this.events.emit('renderSettings:changed', { renderSettings: next });
  }

  applyRenderPreset(preset: RenderPresetId): void {
    const next = this.renderSettingsManager.applyPreset(preset);
    this.storage.saveRenderSettings(next);
    this.markDirty();
    this.renderEngine?.setRenderSettings(next);
    this.events.emit('renderSettings:changed', { renderSettings: next });
  }

  resetRenderSettings(): void {
    const next = this.renderSettingsManager.reset();
    this.storage.saveRenderSettings(next);
    this.markDirty();
    this.renderEngine?.setRenderSettings(next);
    this.events.emit('renderSettings:changed', { renderSettings: next });
  }

  private applyLoadedProject(project: DimensiXProject): void {
    this.activeProject = project;
    this.sceneManager.loadSnapshot(project.scene);
    const nextRender = this.renderSettingsManager.load(
      project.renderSettings ?? this.storage.loadRenderSettings(),
    );
    this.isDirty = false;
    this.lastSavedAt = project.updatedAt;
    this.renderEngine?.setRenderSettings(nextRender);
    this.renderEngine?.syncScene(this.sceneManager.getSnapshot());
    void this.hydrateProjectAssets(project);
    this.events.emit('project:loaded', { project });
    this.events.emit('renderSettings:changed', { renderSettings: nextRender });
    this.events.emit('project:dirtyChanged', { isDirty: false });
    this.emitSceneChanged('project-loaded');
    const selected = this.sceneManager.getSelectedNode();
    this.events.emit('selection:changed', {
      selectedId: selected?.id ?? null,
      node: selected,
    });
  }

  private markDirty(): void {
    if (!this.isDirty) {
      this.isDirty = true;
      this.events.emit('project:dirtyChanged', { isDirty: true });
    }
  }

  private emitSceneChanged(reason: string): void {
    this.events.emit('scene:changed', {
      snapshot: this.sceneManager.getSnapshot(),
      reason,
    });
    this.emitHistoryChanged();
  }

  private emitHistoryChanged(): void {
    this.events.emit('history:changed', {
      canUndo: this.sceneManager.canUndo(),
      canRedo: this.sceneManager.canRedo(),
    });
  }
}
