import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {
  buildTwoLevelBVH,
  intersectRayBruteForce,
  intersectRayTLAS,
  packBVHForGPU,
} from './BVHBuilder';
import { buildShowcaseGlbBuffer } from '../assets/SampleGlbGenerator';
import { parseModelFromBuffer } from '../assets/ModelImporter';

test('Two-level BVH matches brute-force intersection across rotated/scaled instances and multi-part GLB', async () => {
  const boxGeo = new THREE.BoxGeometry(1, 1, 1);
  const sphereGeo = new THREE.SphereGeometry(0.6, 16, 12);

  const glbAsset = await parseModelFromBuffer(buildShowcaseGlbBuffer(), 'artifact.glb', {
    assetId: 'bvh_glb',
  });

  const sources = [
    { geometryKey: 'box', geometry: boxGeo },
    { geometryKey: 'sphere', geometry: sphereGeo },
    ...glbAsset.parts.map((p) => ({
      geometryKey: p.geometryKey,
      geometry: p.geometry,
      submeshes: p.submeshes,
    })),
  ];

  // Shared BLAS instancing: 2 boxes, 1 sphere, plus all parts of 2 GLB instances
  const matBox1 = new THREE.Matrix4().compose(
    new THREE.Vector3(-1.4, 0.5, 0.2),
    new THREE.Quaternion().setFromEuler(new THREE.Euler(0.3, 0.7, -0.2)),
    new THREE.Vector3(1.1, 1.4, 0.8),
  );
  const matBox2 = new THREE.Matrix4().compose(
    new THREE.Vector3(1.8, 0.4, -0.8),
    new THREE.Quaternion().setFromEuler(new THREE.Euler(-0.4, 0.5, 0.3)),
    new THREE.Vector3(0.7, 0.9, 1.3),
  );
  const matSphere = new THREE.Matrix4().compose(
    new THREE.Vector3(0.1, 0.6, 1.2),
    new THREE.Quaternion(),
    new THREE.Vector3(1, 1, 1),
  );

  const instances = [
    {
      instanceIndex: 0,
      nodeId: 'box1',
      geometryKey: 'box',
      worldMatrix: matBox1,
      materialIndices: [0],
    },
    {
      instanceIndex: 1,
      nodeId: 'box2',
      geometryKey: 'box',
      worldMatrix: matBox2,
      materialIndices: [1],
    },
    {
      instanceIndex: 2,
      nodeId: 'sphere1',
      geometryKey: 'sphere',
      worldMatrix: matSphere,
      materialIndices: [2],
    },
  ];

  const glbRoot1 = new THREE.Matrix4().makeTranslation(0, 0.05, -0.4);
  const glbRoot2 = new THREE.Matrix4().compose(
    new THREE.Vector3(-0.3, 0.2, 2.2),
    new THREE.Quaternion().setFromEuler(new THREE.Euler(0, 1.1, 0)),
    new THREE.Vector3(0.75, 0.75, 0.75),
  );

  let nextIdx = instances.length;
  for (const part of glbAsset.parts) {
    const localMat = new THREE.Matrix4().fromArray(part.localMatrix);
    instances.push({
      instanceIndex: nextIdx++,
      nodeId: 'glb_1',
      geometryKey: part.geometryKey,
      worldMatrix: new THREE.Matrix4().multiplyMatrices(glbRoot1, localMat),
      materialIndices: [3],
    });
    instances.push({
      instanceIndex: nextIdx++,
      nodeId: 'glb_2',
      geometryKey: part.geometryKey,
      worldMatrix: new THREE.Matrix4().multiplyMatrices(glbRoot2, localMat),
      materialIndices: [4],
    });
  }

  const bvh = buildTwoLevelBVH(sources, instances);
  assert.equal(bvh.blases.length, 2 + glbAsset.parts.length);
  assert.equal(bvh.instances.length, instances.length);

  // Fire 140 deterministic rays from varying camera angles and compare BVH vs brute force
  let hits = 0;
  for (let i = 0; i < 140; i++) {
    const theta = (i * 2.39996) % (Math.PI * 2);
    const elevation = -0.3 + ((i % 10) / 9) * 2.2;
    const origin: [number, number, number] = [
      Math.cos(theta) * 4.5,
      elevation + 1.1,
      Math.sin(theta) * 4.5,
    ];
    const target: [number, number, number] = [
      ((i % 7) - 3) * 0.55,
      ((i % 5) - 1) * 0.35,
      (((i * 3) % 7) - 3) * 0.45,
    ];
    const dx = target[0] - origin[0];
    const dy = target[1] - origin[1];
    const dz = target[2] - origin[2];
    const len = Math.hypot(dx, dy, dz) || 1;
    const dir: [number, number, number] = [dx / len, dy / len, dz / len];

    const expected = intersectRayBruteForce(bvh, origin, dir);
    const actual = intersectRayTLAS(bvh, origin, dir);

    if (expected === null) {
      assert.equal(actual, null, `Ray ${i} should miss`);
    } else {
      hits++;
      assert.ok(actual !== null, `Ray ${i} missed unexpectedly`);
      assert.ok(
        Math.abs(actual.t - expected.t) < 1e-4,
        `Ray ${i} t mismatch: ${actual.t} vs ${expected.t}`,
      );
      assert.equal(actual.instanceIndex, expected.instanceIndex, `Ray ${i} instance mismatch`);
    }
  }
  assert.ok(hits > 45, `Expected plenty of ray hits, got ${hits}`);

  // Verify GPU packing outputs valid non-zero buffers
  const packed = packBVHForGPU(bvh);
  assert.ok(packed.bvhNodesData.length >= 8);
  assert.ok(packed.triData.length >= 28);
  assert.ok(packed.instanceData.length >= 48);
  assert.equal(packed.instanceCount, instances.length);
  assert.ok(packed.totalInstancedTriangles > packed.totalUniqueTriangles);
});
