import * as THREE from 'three';

export interface BVHGeometrySource {
  geometryKey: string;
  geometry: THREE.BufferGeometry;
  submeshes?: Array<{
    startIndex: number;
    count: number;
    materialIndex: number;
  }>;
}

export interface BVHInstanceDescriptor {
  instanceIndex: number;
  nodeId: string;
  geometryKey: string;
  worldMatrix: THREE.Matrix4;
  /** Offset into the global flat material table for each submesh materialIndex */
  materialIndices: number[];
}

export interface TriangleRecord {
  p0: [number, number, number];
  p1: [number, number, number];
  p2: [number, number, number];
  n0: [number, number, number];
  n1: [number, number, number];
  n2: [number, number, number];
  uv0: [number, number];
  uv1: [number, number];
  uv2: [number, number];
  materialIndex: number;
  centroid: [number, number, number];
  min: [number, number, number];
  max: [number, number, number];
}

export interface BVHNode {
  min: [number, number, number];
  max: [number, number, number];
  /**
   * Internal node: rightChild (>= 0), leftChild = nodeIndex + 1, primCount = 0.
   * Leaf node: leftFirst = first index in ordered primitives, primCount > 0, rightChild = -1.
   */
  leftFirst: number;
  rightChild: number;
  primCount: number;
}

export interface BLAS {
  geometryKey: string;
  nodes: BVHNode[];
  orderedTriangles: TriangleRecord[];
  localMin: [number, number, number];
  localMax: [number, number, number];
}

export interface TLASInstanceEntry {
  instanceIndex: number;
  nodeId: string;
  blasIndex: number;
  blasRootNodeOffset: number;
  blasTriOffset: number;
  materialBaseOffset: number;
  worldMatrix: number[];
  invWorldMatrix: number[];
  normalMatrix: number[]; // 3x3 column-major inverse-transpose upper-left
  worldMin: [number, number, number];
  worldMax: [number, number, number];
}

export interface TwoLevelBVH {
  blases: BLAS[];
  blasMap: Map<string, number>;
  tlasNodes: BVHNode[];
  instances: TLASInstanceEntry[];
  totalTriangles: number;
}

export interface PackedGPUBVH {
  /** RGBA32F DataTexture storing BVH nodes (2 texels per node: [minX,minY,minZ,leftFirst] and [maxX,maxY,maxZ,primCount_or_negRight]) */
  bvhNodesData: Float32Array;
  bvhNodesWidth: number;
  bvhNodesHeight: number;
  /** RGBA32F DataTexture storing Triangles (6 texels per tri: p0,p1,p2,n0,n1,n2+uvs+mat) */
  triData: Float32Array;
  triWidth: number;
  triHeight: number;
  /** RGBA32F DataTexture storing TLAS instances (9 texels per instance) */
  instanceData: Float32Array;
  instanceWidth: number;
  instanceHeight: number;
  tlasNodeCount: number;
  instanceCount: number;
  totalUniqueTriangles: number;
  totalInstancedTriangles: number;
  estimatedGpuBytes: number;
}

export interface RayHit {
  t: number;
  u: number;
  v: number;
  instanceIndex: number;
  triangleIndex: number;
  localMaterialIndex: number;
  materialIndex: number;
  normal: [number, number, number];
}

const EPSILON = 1e-6;
const AABB_PAD = 1e-4;

/**
 * Extracts triangle primitives from a Three.js BufferGeometry preserving
 * submesh materialIndex assignments and ensuring smooth/face normals.
 */
export function extractTrianglesFromGeometry(
  geometry: THREE.BufferGeometry,
  submeshes?: Array<{ startIndex: number; count: number; materialIndex: number }>,
): TriangleRecord[] {
  const posAttr = geometry.getAttribute('position');
  if (!posAttr || posAttr.count < 3) return [];

  if (!geometry.getAttribute('normal')) {
    geometry.computeVertexNormals();
  }
  const normAttr = geometry.getAttribute('normal');
  const uvAttr = geometry.getAttribute('uv');
  const indexAttr = geometry.getIndex();

  const totalIndices = indexAttr ? indexAttr.count : posAttr.count;
  const groups =
    submeshes && submeshes.length > 0
      ? submeshes
      : geometry.groups && geometry.groups.length > 0
        ? geometry.groups.map((g) => ({
            startIndex: g.start,
            count: g.count,
            materialIndex: g.materialIndex ?? 0,
          }))
        : [{ startIndex: 0, count: totalIndices, materialIndex: 0 }];

  const triangles: TriangleRecord[] = [];

  for (const grp of groups) {
    const start = Math.max(0, grp.startIndex);
    const end = Math.min(totalIndices, grp.startIndex + grp.count);
    for (let i = start; i + 2 < end; i += 3) {
      const i0 = indexAttr ? indexAttr.getX(i) : i;
      const i1 = indexAttr ? indexAttr.getX(i + 1) : i + 1;
      const i2 = indexAttr ? indexAttr.getX(i + 2) : i + 2;

      const p0: [number, number, number] = [posAttr.getX(i0), posAttr.getY(i0), posAttr.getZ(i0)];
      const p1: [number, number, number] = [posAttr.getX(i1), posAttr.getY(i1), posAttr.getZ(i1)];
      const p2: [number, number, number] = [posAttr.getX(i2), posAttr.getY(i2), posAttr.getZ(i2)];

      // Skip degenerate zero-area triangles
      const e1x = p1[0] - p0[0];
      const e1y = p1[1] - p0[1];
      const e1z = p1[2] - p0[2];
      const e2x = p2[0] - p0[0];
      const e2y = p2[1] - p0[1];
      const e2z = p2[2] - p0[2];
      const cx = e1y * e2z - e1z * e2y;
      const cy = e1z * e2x - e1x * e2z;
      const cz = e1x * e2y - e1y * e2x;
      const areaSq = cx * cx + cy * cy + cz * cz;
      if (areaSq < 1e-14) continue;

      const areaLen = Math.sqrt(areaSq) || 1;
      const faceN: [number, number, number] = [cx / areaLen, cy / areaLen, cz / areaLen];

      const readNorm = (idx: number): [number, number, number] => {
        if (!normAttr) return faceN;
        const nx = normAttr.getX(idx);
        const ny = normAttr.getY(idx);
        const nz = normAttr.getZ(idx);
        const l = Math.hypot(nx, ny, nz);
        return l > 1e-6 ? [nx / l, ny / l, nz / l] : faceN;
      };

      const readUv = (idx: number): [number, number] => {
        if (!uvAttr) return [0, 0];
        return [uvAttr.getX(idx), uvAttr.getY(idx)];
      };

      const min: [number, number, number] = [
        Math.min(p0[0], p1[0], p2[0]) - AABB_PAD,
        Math.min(p0[1], p1[1], p2[1]) - AABB_PAD,
        Math.min(p0[2], p1[2], p2[2]) - AABB_PAD,
      ];
      const max: [number, number, number] = [
        Math.max(p0[0], p1[0], p2[0]) + AABB_PAD,
        Math.max(p0[1], p1[1], p2[1]) + AABB_PAD,
        Math.max(p0[2], p1[2], p2[2]) + AABB_PAD,
      ];
      const centroid: [number, number, number] = [
        (p0[0] + p1[0] + p2[0]) / 3,
        (p0[1] + p1[1] + p2[1]) / 3,
        (p0[2] + p1[2] + p2[2]) / 3,
      ];

      triangles.push({
        p0,
        p1,
        p2,
        n0: readNorm(i0),
        n1: readNorm(i1),
        n2: readNorm(i2),
        uv0: readUv(i0),
        uv1: readUv(i1),
        uv2: readUv(i2),
        materialIndex: grp.materialIndex,
        centroid,
        min,
        max,
      });
    }
  }

  return triangles;
}

interface BoundedItem {
  min: [number, number, number];
  max: [number, number, number];
  centroid: [number, number, number];
}

function buildBVHOverItems<T extends BoundedItem>(
  items: T[],
  maxLeafSize: number,
): { nodes: BVHNode[]; ordered: T[] } {
  if (items.length === 0) {
    return {
      nodes: [
        {
          min: [0, 0, 0],
          max: [0, 0, 0],
          leftFirst: 0,
          rightChild: -1,
          primCount: 0,
        },
      ],
      ordered: [],
    };
  }

  const indices = new Int32Array(items.length);
  for (let i = 0; i < items.length; i++) indices[i] = i;

  const nodes: BVHNode[] = [];

  const buildNode = (start: number, count: number): number => {
    const nodeIdx = nodes.length;
    const min: [number, number, number] = [Infinity, Infinity, Infinity];
    const max: [number, number, number] = [-Infinity, -Infinity, -Infinity];
    const cMin: [number, number, number] = [Infinity, Infinity, Infinity];
    const cMax: [number, number, number] = [-Infinity, -Infinity, -Infinity];

    for (let i = start; i < start + count; i++) {
      const it = items[indices[i]];
      for (let a = 0; a < 3; a++) {
        if (it.min[a] < min[a]) min[a] = it.min[a];
        if (it.max[a] > max[a]) max[a] = it.max[a];
        if (it.centroid[a] < cMin[a]) cMin[a] = it.centroid[a];
        if (it.centroid[a] > cMax[a]) cMax[a] = it.centroid[a];
      }
    }

    nodes.push({
      min,
      max,
      leftFirst: start,
      rightChild: -1,
      primCount: count,
    });

    if (count <= maxLeafSize) {
      return nodeIdx;
    }

    // Choose split axis using binned SAH approximation over longest centroid extent
    const extX = cMax[0] - cMin[0];
    const extY = cMax[1] - cMin[1];
    const extZ = cMax[2] - cMin[2];
    const axis: 0 | 1 | 2 = extX >= extY && extX >= extZ ? 0 : extY >= extZ ? 1 : 2;
    const axisSpan = cMax[axis] - cMin[axis];

    if (axisSpan < 1e-6) {
      // Overlapping centroids -> split evenly by index so leaves stay bounded
      const mid = start + Math.floor(count / 2);
      const leftCount = mid - start;
      nodes[nodeIdx].primCount = 0;
      nodes[nodeIdx].leftFirst = buildNode(start, leftCount);
      nodes[nodeIdx].rightChild = buildNode(mid, count - leftCount);
      return nodeIdx;
    }

    // Evaluate 8 SAH split candidates along selected axis
    let bestCost = Infinity;
    let bestSplitPos = (cMin[axis] + cMax[axis]) * 0.5;
    const BINS = 8;

    for (let b = 1; b < BINS; b++) {
      const cand = cMin[axis] + (axisSpan * b) / BINS;
      let lCount = 0;
      let rCount = 0;
      const lMin: [number, number, number] = [Infinity, Infinity, Infinity];
      const lMax: [number, number, number] = [-Infinity, -Infinity, -Infinity];
      const rMin: [number, number, number] = [Infinity, Infinity, Infinity];
      const rMax: [number, number, number] = [-Infinity, -Infinity, -Infinity];

      for (let i = start; i < start + count; i++) {
        const it = items[indices[i]];
        if (it.centroid[axis] < cand) {
          lCount++;
          for (let a = 0; a < 3; a++) {
            if (it.min[a] < lMin[a]) lMin[a] = it.min[a];
            if (it.max[a] > lMax[a]) lMax[a] = it.max[a];
          }
        } else {
          rCount++;
          for (let a = 0; a < 3; a++) {
            if (it.min[a] < rMin[a]) rMin[a] = it.min[a];
            if (it.max[a] > rMax[a]) rMax[a] = it.max[a];
          }
        }
      }

      if (lCount > 0 && rCount > 0) {
        const cost = lCount * boxSurfaceArea(lMin, lMax) + rCount * boxSurfaceArea(rMin, rMax);
        if (cost < bestCost) {
          bestCost = cost;
          bestSplitPos = cand;
        }
      }
    }

    // Partition in-place around bestSplitPos
    let i = start;
    let j = start + count - 1;
    while (i <= j) {
      if (items[indices[i]].centroid[axis] < bestSplitPos) {
        i++;
      } else {
        const tmp = indices[i];
        indices[i] = indices[j];
        indices[j] = tmp;
        j--;
      }
    }

    let leftCount = i - start;
    if (leftCount === 0 || leftCount === count) {
      leftCount = Math.floor(count / 2);
    }

    nodes[nodeIdx].primCount = 0;
    nodes[nodeIdx].leftFirst = buildNode(start, leftCount);
    nodes[nodeIdx].rightChild = buildNode(start + leftCount, count - leftCount);
    return nodeIdx;
  };

  buildNode(0, items.length);

  const ordered: T[] = new Array(items.length);
  for (let i = 0; i < items.length; i++) {
    ordered[i] = items[indices[i]];
  }

  return { nodes, ordered };
}

export function buildBLAS(source: BVHGeometrySource): BLAS {
  const rawTris = extractTrianglesFromGeometry(source.geometry, source.submeshes);
  const { nodes, ordered } = buildBVHOverItems(rawTris, 4);
  const root = nodes[0];
  return {
    geometryKey: source.geometryKey,
    nodes,
    orderedTriangles: ordered,
    localMin: root ? [...root.min] : [0, 0, 0],
    localMax: root ? [...root.max] : [0, 0, 0],
  };
}

export function buildTwoLevelBVH(
  sources: BVHGeometrySource[],
  instancesInput: BVHInstanceDescriptor[],
): TwoLevelBVH {
  const blases: BLAS[] = [];
  const blasMap = new Map<string, number>();

  for (const src of sources) {
    if (blasMap.has(src.geometryKey)) continue;
    const blas = buildBLAS(src);
    if (blas.orderedTriangles.length === 0) continue;
    blasMap.set(src.geometryKey, blases.length);
    blases.push(blas);
  }

  // Compute global node & triangle offsets for each BLAS when packed contiguously
  const blasNodeOffsets: number[] = [];
  const blasTriOffsets: number[] = [];
  let runningNodeOffset = 0;
  let runningTriOffset = 0;
  for (const b of blases) {
    blasNodeOffsets.push(runningNodeOffset);
    blasTriOffsets.push(runningTriOffset);
    runningNodeOffset += b.nodes.length;
    runningTriOffset += b.orderedTriangles.length;
  }

  // Transform BLAS local AABBs into world-space AABBs for each instance
  interface TLASItem extends BoundedItem {
    entry: TLASInstanceEntry;
  }

  const tlasItems: TLASItem[] = [];
  let totalInstancedTriangles = 0;

  for (const inst of instancesInput) {
    const blasIndex = blasMap.get(inst.geometryKey);
    if (blasIndex === undefined) continue;
    const blas = blases[blasIndex];
    totalInstancedTriangles += blas.orderedTriangles.length;

    const worldBox = transformAABB(blas.localMin, blas.localMax, inst.worldMatrix);
    const invWorld = new THREE.Matrix4().copy(inst.worldMatrix).invert();
    const normalMat = new THREE.Matrix3().getNormalMatrix(inst.worldMatrix);

    const worldMin: [number, number, number] = [
      worldBox.min.x - AABB_PAD,
      worldBox.min.y - AABB_PAD,
      worldBox.min.z - AABB_PAD,
    ];
    const worldMax: [number, number, number] = [
      worldBox.max.x + AABB_PAD,
      worldBox.max.y + AABB_PAD,
      worldBox.max.z + AABB_PAD,
    ];
    const centroid: [number, number, number] = [
      (worldMin[0] + worldMax[0]) * 0.5,
      (worldMin[1] + worldMax[1]) * 0.5,
      (worldMin[2] + worldMax[2]) * 0.5,
    ];

    tlasItems.push({
      min: worldMin,
      max: worldMax,
      centroid,
      entry: {
        instanceIndex: inst.instanceIndex,
        nodeId: inst.nodeId,
        blasIndex,
        blasRootNodeOffset: blasNodeOffsets[blasIndex],
        blasTriOffset: blasTriOffsets[blasIndex],
        materialBaseOffset: inst.materialIndices[0] ?? 0,
        worldMatrix: Array.from(inst.worldMatrix.elements),
        invWorldMatrix: Array.from(invWorld.elements),
        normalMatrix: Array.from(normalMat.elements),
        worldMin,
        worldMax,
      },
    });
  }

  const { nodes: tlasNodes, ordered } = buildBVHOverItems(tlasItems, 1);
  const instances = ordered.map((item) => item.entry);

  return {
    blases,
    blasMap,
    tlasNodes,
    instances,
    totalTriangles: totalInstancedTriangles,
  };
}

/**
 * Packs TLAS + all BLAS nodes + unique triangles + instance transforms into
 * RGBA32F DataTexture-compatible Float32Arrays for WebGL2 GPU ray traversal.
 */
export function packBVHForGPU(bvh: TwoLevelBVH): PackedGPUBVH {
  // 1. Pack combined BVH nodes: TLAS nodes first [0 .. tlasLen-1], followed by BLAS nodes
  const tlasCount = bvh.tlasNodes.length;
  let totalBlasNodes = 0;
  let totalUniqueTris = 0;
  for (const blas of bvh.blases) {
    totalBlasNodes += blas.nodes.length;
    totalUniqueTris += blas.orderedTriangles.length;
  }

  const totalNodes = Math.max(1, tlasCount + totalBlasNodes);
  // 2 RGBA32F texels per node:
  // Texel 0: (minX, minY, minZ, leftFirstOrGlobalOffset)
  // Texel 1: (maxX, maxY, maxZ, primCount > 0 ? primCount : -(rightChildGlobal))
  const nodeTexels = totalNodes * 2;
  const bvhNodesWidth = 1024;
  const bvhNodesHeight = Math.max(1, Math.ceil(nodeTexels / bvhNodesWidth));
  const bvhNodesData = new Float32Array(bvhNodesWidth * bvhNodesHeight * 4);

  const writeNode = (
    globalIdx: number,
    node: BVHNode,
    nodeOffset: number,
    primOffset: number,
  ) => {
    const base = globalIdx * 8;
    bvhNodesData[base + 0] = node.min[0];
    bvhNodesData[base + 1] = node.min[1];
    bvhNodesData[base + 2] = node.min[2];
    if (node.primCount > 0) {
      bvhNodesData[base + 3] = node.leftFirst + primOffset;
      bvhNodesData[base + 4] = node.max[0];
      bvhNodesData[base + 5] = node.max[1];
      bvhNodesData[base + 6] = node.max[2];
      bvhNodesData[base + 7] = node.primCount;
    } else {
      bvhNodesData[base + 3] = node.leftFirst + nodeOffset;
      bvhNodesData[base + 4] = node.max[0];
      bvhNodesData[base + 5] = node.max[1];
      bvhNodesData[base + 6] = node.max[2];
      // Encode internal node by storing -(rightChild + nodeOffset + 1) so even right=0 is negative (< 0)
      bvhNodesData[base + 7] = -(node.rightChild + nodeOffset + 1);
    }
  };

  for (let i = 0; i < bvh.tlasNodes.length; i++) {
    writeNode(i, bvh.tlasNodes[i], 0, 0);
  }

  let nodeCursor = tlasCount;
  let triCursor = 0;
  for (const blas of bvh.blases) {
    const blasNodeStart = nodeCursor;
    const blasTriStart = triCursor;
    for (let i = 0; i < blas.nodes.length; i++) {
      writeNode(blasNodeStart + i, blas.nodes[i], blasNodeStart, blasTriStart);
    }
    nodeCursor += blas.nodes.length;
    triCursor += blas.orderedTriangles.length;
  }

  // Update instance blasRootNodeOffset to include tlasCount
  // 2. Pack triangles: 7 RGBA32F texels per triangle
  // T0: p0.xyz, uv0.x
  // T1: p1.xyz, uv0.y
  // T2: p2.xyz, uv1.x
  // T3: n0.xyz, uv1.y
  // T4: n1.xyz, uv2.x
  // T5: n2.xyz, uv2.y
  // T6: materialIndex, 0, 0, 0
  const safeTriCount = Math.max(1, totalUniqueTris);
  const triTexels = safeTriCount * 7;
  const triWidth = 1024;
  const triHeight = Math.max(1, Math.ceil(triTexels / triWidth));
  const triData = new Float32Array(triWidth * triHeight * 4);

  let triIndex = 0;
  for (const blas of bvh.blases) {
    for (const tri of blas.orderedTriangles) {
      const base = triIndex * 7 * 4;
      triData[base + 0] = tri.p0[0];
      triData[base + 1] = tri.p0[1];
      triData[base + 2] = tri.p0[2];
      triData[base + 3] = tri.uv0[0];

      triData[base + 4] = tri.p1[0];
      triData[base + 5] = tri.p1[1];
      triData[base + 6] = tri.p1[2];
      triData[base + 7] = tri.uv0[1];

      triData[base + 8] = tri.p2[0];
      triData[base + 9] = tri.p2[1];
      triData[base + 10] = tri.p2[2];
      triData[base + 11] = tri.uv1[0];

      triData[base + 12] = tri.n0[0];
      triData[base + 13] = tri.n0[1];
      triData[base + 14] = tri.n0[2];
      triData[base + 15] = tri.uv1[1];

      triData[base + 16] = tri.n1[0];
      triData[base + 17] = tri.n1[1];
      triData[base + 18] = tri.n1[2];
      triData[base + 19] = tri.uv2[0];

      triData[base + 20] = tri.n2[0];
      triData[base + 21] = tri.n2[1];
      triData[base + 22] = tri.n2[2];
      triData[base + 23] = tri.uv2[1];

      triData[base + 24] = tri.materialIndex;
      triIndex++;
    }
  }

  // 3. Pack TLAS instances: 12 RGBA32F texels per instance
  // T0..T3: invWorldMatrix cols 0..3
  // T4..T7: worldMatrix cols 0..3
  // T8..T10: normalMatrix cols 0..2 (xyz) + padding
  // T11: (blasGlobalRootNode, materialBaseOffset, instanceIndex, 0)
  const instCount = Math.max(1, bvh.instances.length);
  const instTexels = instCount * 12;
  const instanceWidth = 256;
  const instanceHeight = Math.max(1, Math.ceil(instTexels / instanceWidth));
  const instanceData = new Float32Array(instanceWidth * instanceHeight * 4);

  for (let i = 0; i < bvh.instances.length; i++) {
    const inst = bvh.instances[i];
    const base = i * 12 * 4;
    for (let j = 0; j < 16; j++) {
      instanceData[base + j] = inst.invWorldMatrix[j];
      instanceData[base + 16 + j] = inst.worldMatrix[j];
    }
    // normalMatrix is 3x3 column-major (9 elements)
    instanceData[base + 32] = inst.normalMatrix[0];
    instanceData[base + 33] = inst.normalMatrix[1];
    instanceData[base + 34] = inst.normalMatrix[2];
    instanceData[base + 36] = inst.normalMatrix[3];
    instanceData[base + 37] = inst.normalMatrix[4];
    instanceData[base + 38] = inst.normalMatrix[5];
    instanceData[base + 40] = inst.normalMatrix[6];
    instanceData[base + 41] = inst.normalMatrix[7];
    instanceData[base + 42] = inst.normalMatrix[8];

    instanceData[base + 44] = inst.blasRootNodeOffset + tlasCount;
    instanceData[base + 45] = inst.materialBaseOffset;
    instanceData[base + 46] = inst.instanceIndex;
  }

  const estimatedGpuBytes =
    bvhNodesData.byteLength + triData.byteLength + instanceData.byteLength;

  return {
    bvhNodesData,
    bvhNodesWidth,
    bvhNodesHeight,
    triData,
    triWidth,
    triHeight,
    instanceData,
    instanceWidth,
    instanceHeight,
    tlasNodeCount: tlasCount,
    instanceCount: bvh.instances.length,
    totalUniqueTriangles: totalUniqueTris,
    totalInstancedTriangles: bvh.totalTriangles,
    estimatedGpuBytes,
  };
}

/**
 * Reference CPU TLAS + BLAS ray-mesh intersector used both for CPU diagnostics and
 * deterministic unit-test verification against brute-force triangle traversal.
 */
export function intersectRayTLAS(
  bvh: TwoLevelBVH,
  origin: [number, number, number],
  dir: [number, number, number],
  tMin = 0.001,
  tMax = 1e6,
): RayHit | null {
  if (bvh.instances.length === 0 || bvh.tlasNodes.length === 0) return null;

  let bestT = tMax;
  let bestHit: RayHit | null = null;

  const invDir: [number, number, number] = [
    1 / (Math.abs(dir[0]) > 1e-12 ? dir[0] : 1e-12),
    1 / (Math.abs(dir[1]) > 1e-12 ? dir[1] : 1e-12),
    1 / (Math.abs(dir[2]) > 1e-12 ? dir[2] : 1e-12),
  ];

  const tlasStack: number[] = [0];
  while (tlasStack.length > 0) {
    const nodeIdx = tlasStack.pop()!;
    const node = bvh.tlasNodes[nodeIdx];
    const tBox = intersectAABB(origin, invDir, node.min, node.max, tMin, bestT);
    if (tBox === Infinity) continue;

    if (node.primCount > 0) {
      for (let i = 0; i < node.primCount; i++) {
        const inst = bvh.instances[node.leftFirst + i];
        const blas = bvh.blases[inst.blasIndex];

        const localOrigin = transformPointMat4(inst.invWorldMatrix, origin);
        const localDir = transformDirMat4(inst.invWorldMatrix, dir);
        const localInvDir: [number, number, number] = [
          1 / (Math.abs(localDir[0]) > 1e-12 ? localDir[0] : 1e-12),
          1 / (Math.abs(localDir[1]) > 1e-12 ? localDir[1] : 1e-12),
          1 / (Math.abs(localDir[2]) > 1e-12 ? localDir[2] : 1e-12),
        ];

        const blasStack: number[] = [0];
        while (blasStack.length > 0) {
          const bIdx = blasStack.pop()!;
          const bNode = blas.nodes[bIdx];
          if (intersectAABB(localOrigin, localInvDir, bNode.min, bNode.max, tMin, bestT) === Infinity) {
            continue;
          }

          if (bNode.primCount > 0) {
            for (let t = 0; t < bNode.primCount; t++) {
              const triIdx = bNode.leftFirst + t;
              const tri = blas.orderedTriangles[triIdx];
              const hit = intersectTriangleMT(localOrigin, localDir, tri, tMin, bestT);
              if (hit) {
                bestT = hit.t;
                const localNormal: [number, number, number] = [
                  tri.n0[0] * (1 - hit.u - hit.v) + tri.n1[0] * hit.u + tri.n2[0] * hit.v,
                  tri.n0[1] * (1 - hit.u - hit.v) + tri.n1[1] * hit.u + tri.n2[1] * hit.v,
                  tri.n0[2] * (1 - hit.u - hit.v) + tri.n1[2] * hit.u + tri.n2[2] * hit.v,
                ];
                const worldNormal = normalize3(transformNormalMat3(inst.normalMatrix, localNormal));
                bestHit = {
                  t: hit.t,
                  u: hit.u,
                  v: hit.v,
                  instanceIndex: inst.instanceIndex,
                  triangleIndex: triIdx,
                  localMaterialIndex: tri.materialIndex,
                  materialIndex: inst.materialBaseOffset + tri.materialIndex,
                  normal: worldNormal,
                };
              }
            }
          } else {
            blasStack.push(bNode.rightChild);
            blasStack.push(bNode.leftFirst);
          }
        }
      }
    } else {
      tlasStack.push(node.rightChild);
      tlasStack.push(node.leftFirst);
    }
  }

  return bestHit;
}

/**
 * Exact O(N) brute-force ray intersection across every instance & triangle
 * used as mathematical oracle in BVH tests.
 */
export function intersectRayBruteForce(
  bvh: TwoLevelBVH,
  origin: [number, number, number],
  dir: [number, number, number],
  tMin = 0.001,
  tMax = 1e6,
): RayHit | null {
  let bestT = tMax;
  let bestHit: RayHit | null = null;

  for (const inst of bvh.instances) {
    const blas = bvh.blases[inst.blasIndex];
    const localOrigin = transformPointMat4(inst.invWorldMatrix, origin);
    const localDir = transformDirMat4(inst.invWorldMatrix, dir);

    for (let triIdx = 0; triIdx < blas.orderedTriangles.length; triIdx++) {
      const tri = blas.orderedTriangles[triIdx];
      const hit = intersectTriangleMT(localOrigin, localDir, tri, tMin, bestT);
      if (hit) {
        bestT = hit.t;
        const localNormal: [number, number, number] = [
          tri.n0[0] * (1 - hit.u - hit.v) + tri.n1[0] * hit.u + tri.n2[0] * hit.v,
          tri.n0[1] * (1 - hit.u - hit.v) + tri.n1[1] * hit.u + tri.n2[1] * hit.v,
          tri.n0[2] * (1 - hit.u - hit.v) + tri.n1[2] * hit.u + tri.n2[2] * hit.v,
        ];
        bestHit = {
          t: hit.t,
          u: hit.u,
          v: hit.v,
          instanceIndex: inst.instanceIndex,
          triangleIndex: triIdx,
          localMaterialIndex: tri.materialIndex,
          materialIndex: inst.materialBaseOffset + tri.materialIndex,
          normal: normalize3(transformNormalMat3(inst.normalMatrix, localNormal)),
        };
      }
    }
  }

  return bestHit;
}

function intersectAABB(
  origin: [number, number, number],
  invDir: [number, number, number],
  min: [number, number, number],
  max: [number, number, number],
  tMin: number,
  tMax: number,
): number {
  let t0 = tMin;
  let t1 = tMax;
  for (let a = 0; a < 3; a++) {
    const ta = (min[a] - origin[a]) * invDir[a];
    const tb = (max[a] - origin[a]) * invDir[a];
    const sMin = Math.min(ta, tb);
    const sMax = Math.max(ta, tb);
    t0 = Math.max(t0, sMin);
    t1 = Math.min(t1, sMax);
    if (t1 < t0) return Infinity;
  }
  return t0;
}

function intersectTriangleMT(
  origin: [number, number, number],
  dir: [number, number, number],
  tri: TriangleRecord,
  tMin: number,
  tMax: number,
): { t: number; u: number; v: number } | null {
  const e1x = tri.p1[0] - tri.p0[0];
  const e1y = tri.p1[1] - tri.p0[1];
  const e1z = tri.p1[2] - tri.p0[2];
  const e2x = tri.p2[0] - tri.p0[0];
  const e2y = tri.p2[1] - tri.p0[1];
  const e2z = tri.p2[2] - tri.p0[2];

  const px = dir[1] * e2z - dir[2] * e2y;
  const py = dir[2] * e2x - dir[0] * e2z;
  const pz = dir[0] * e2y - dir[1] * e2x;

  const det = e1x * px + e1y * py + e1z * pz;
  if (Math.abs(det) < EPSILON) return null;

  const invDet = 1 / det;
  const tx = origin[0] - tri.p0[0];
  const ty = origin[1] - tri.p0[1];
  const tz = origin[2] - tri.p0[2];

  const u = (tx * px + ty * py + tz * pz) * invDet;
  if (u < 0 || u > 1) return null;

  const qx = ty * e1z - tz * e1y;
  const qy = tz * e1x - tx * e1z;
  const qz = tx * e1y - ty * e1x;

  const v = (dir[0] * qx + dir[1] * qy + dir[2] * qz) * invDet;
  if (v < 0 || u + v > 1) return null;

  const t = (e2x * qx + e2y * qy + e2z * qz) * invDet;
  if (t < tMin || t >= tMax) return null;

  return { t, u, v };
}

function boxSurfaceArea(min: [number, number, number], max: [number, number, number]): number {
  const dx = Math.max(0, max[0] - min[0]);
  const dy = Math.max(0, max[1] - min[1]);
  const dz = Math.max(0, max[2] - min[2]);
  return 2 * (dx * dy + dy * dz + dz * dx);
}

function transformAABB(
  localMin: [number, number, number],
  localMax: [number, number, number],
  mat: THREE.Matrix4,
): THREE.Box3 {
  const box = new THREE.Box3();
  const pt = new THREE.Vector3();
  for (let ix = 0; ix < 2; ix++) {
    for (let iy = 0; iy < 2; iy++) {
      for (let iz = 0; iz < 2; iz++) {
        pt.set(
          ix === 0 ? localMin[0] : localMax[0],
          iy === 0 ? localMin[1] : localMax[1],
          iz === 0 ? localMin[2] : localMax[2],
        );
        pt.applyMatrix4(mat);
        box.expandByPoint(pt);
      }
    }
  }
  return box;
}

function transformPointMat4(m: number[], p: [number, number, number]): [number, number, number] {
  return [
    m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12],
    m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13],
    m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14],
  ];
}

function transformDirMat4(m: number[], d: [number, number, number]): [number, number, number] {
  return [
    m[0] * d[0] + m[4] * d[1] + m[8] * d[2],
    m[1] * d[0] + m[5] * d[1] + m[9] * d[2],
    m[2] * d[0] + m[6] * d[1] + m[10] * d[2],
  ];
}

function transformNormalMat3(m: number[], n: [number, number, number]): [number, number, number] {
  return [
    m[0] * n[0] + m[3] * n[1] + m[6] * n[2],
    m[1] * n[0] + m[4] * n[1] + m[7] * n[2],
    m[2] * n[0] + m[5] * n[1] + m[8] * n[2],
  ];
}

function normalize3(v: [number, number, number]): [number, number, number] {
  const len = Math.hypot(v[0], v[1], v[2]) || 1;
  return [v[0] / len, v[1] / len, v[2] / len];
}
