import type { EditorLanguage } from '../project/ProjectTypes';
import type { NodeType } from '../scene/SceneNode';

export interface TranslationStrings {
  appName: string;
  projects: string;
  save: string;
  saved: string;
  unsaved: string;
  undo: string;
  redo: string;
  settings: string;
  renderSettings: string;
  renderButtonShort: string;
  exportImage: string;
  exportShort: string;
  hierarchy: string;
  inspector: string;
  addElements: string;
  lightsMenu: string;
  importModel: string;
  importing: string;
  viewport: string;
  emptySceneHint: string;
  noSelectionTitle: string;
  noSelectionHint: string;
  transform: string;
  position: string;
  rotation: string;
  scale: string;
  resetTransform: string;
  material: string;
  materialPresets: string;
  presetMatte: string;
  presetChrome: string;
  presetGlass: string;
  transmission: string;
  ior: string;
  light: string;
  lightAngle: string;
  lightPenumbra: string;
  lightWidth: string;
  lightHeight: string;
  castShadow: string;
  modelInfo: string;
  modelFormat: string;
  modelMeshes: string;
  modelTriangles: string;
  cameraNodeTitle: string;
  cameraNear: string;
  cameraFar: string;
  alignViewToCamera: string;
  color: string;
  roughness: string;
  metalness: string;
  wireframe: string;
  intensity: string;
  distance: string;
  name: string;
  parentGroup: string;
  rootLevel: string;
  duplicate: string;
  delete: string;
  hide: string;
  show: string;
  lock: string;
  unlock: string;
  moveMode: string;
  rotateMode: string;
  scaleMode: string;
  focusSelected: string;
  resetCamera: string;
  orbitCameraMode: string;
  freeCameraMode: string;
  freeMoveForward: string;
  freeMoveBackward: string;
  freeMoveLeft: string;
  freeMoveRight: string;
  freeMoveUp: string;
  freeMoveDown: string;
  cameraPerspective: string;
  cameraTop: string;
  cameraFront: string;
  cameraSide: string;
  engineRealtime: string;
  enginePathTracing: string;
  ptModeInteractive: string;
  ptModeConverging: string;
  ptModeIdle: string;
  ptSamplesLabel: string;
  projectManagerTitle: string;
  newProjectName: string;
  createProject: string;
  templateShowcase: string;
  templateStarter: string;
  templateEmpty: string;
  savedProjects: string;
  open: string;
  active: string;
  renameProject: string;
  nodesCount: string;
  settingsTitle: string;
  renderEngineLabel: string;
  showGrid: string;
  showAxes: string;
  snapToGrid: string;
  cameraFov: string;
  language: string;
  close: string;
  cancel: string;
  confirm: string;
  nodeTypes: Record<NodeType, string>;
  exportModal: {
    title: string;
    subtitle: string;
    engineLabel: string;
    aspectSectionTitle: string;
    aspectSquare: string;
    aspectLandscape: string;
    aspectPortrait: string;
    aspectStandard: string;
    aspectPhoto: string;
    aspectCustom: string;
    ratioWidthLabel: string;
    ratioHeightLabel: string;
    resolutionSectionTitle: string;
    resolutionCustom: string;
    customWidthLabel: string;
    customHeightLabel: string;
    samplesLabel: string;
    outputSummaryLabel: string;
    pixelsLabel: string;
    estMemoryLabel: string;
    tileModeLabel: string;
    tileGridLabel: string;
    startRender: string;
    pauseRender: string;
    resumeRender: string;
    cancelRender: string;
    rendering: string;
    pausedLabel: string;
    completedLabel: string;
    cancelledLabel: string;
    idleLabel: string;
    downloadPng: string;
    previewEmpty: string;
    elapsedLabel: string;
    speedLabel: string;
    tilesLabel: string;
    showTileOverlayLabel: string;
  };
  renderPanel: {
    title: string;
    subtitle: string;
    resetDefaults: string;
    presetsLabel: string;
    presetPerformance: string;
    presetBalanced: string;
    presetCinematic: string;
    groupImageQuality: string;
    groupLightingVisual: string;
    groupPerformance: string;
    resolution: string;
    resolutionDesc: string;
    resolutionNative: string;
    renderScale: string;
    renderScaleDesc: string;
    pixelRatio: string;
    pixelRatioDesc: string;
    antiAliasing: string;
    antiAliasingDesc: string;
    aaNone: string;
    shadowQuality: string;
    shadowQualityDesc: string;
    ambientOcclusion: string;
    ambientOcclusionDesc: string;
    exposure: string;
    exposureDesc: string;
    gamma: string;
    gammaDesc: string;
    contrast: string;
    contrastDesc: string;
    bloom: string;
    bloomDesc: string;
    bloomIntensity: string;
    dof: string;
    dofDesc: string;
    dofFocusDistance: string;
    dofAperture: string;
    motionBlur: string;
    motionBlurDesc: string;
    motionBlurAmount: string;
    previewQuality: string;
    previewQualityDesc: string;
    renderQuality: string;
    renderQualityDesc: string;
    textureQuality: string;
    textureQualityDesc: string;
    shadowResolution: string;
    shadowResolutionDesc: string;
    performanceMode: string;
    performanceModeDesc: string;
    levelOff: string;
    levelLow: string;
    levelMedium: string;
    levelHigh: string;
    levelDraft: string;
    levelStandard: string;
  };
}

const AR_STRINGS: TranslationStrings = {
  appName: 'DimensiX',
  projects: 'المشاريع',
  save: 'حفظ',
  saved: 'محفوظ',
  unsaved: 'تغييرات غير محفوظة',
  undo: 'تراجع',
  redo: 'إعادة',
  settings: 'الإعدادات',
  renderSettings: 'إعدادات التصيير',
  renderButtonShort: 'التصيير',
  exportImage: 'تصيير وتصدير صورة',
  exportShort: 'تصدير',
  hierarchy: 'الهيكلة',
  inspector: 'الخصائص',
  addElements: 'إضافة عناصر',
  lightsMenu: 'إضاءة',
  importModel: 'استيراد مجسم',
  importing: 'جاري الاستيراد...',
  viewport: 'المشهد',
  emptySceneHint: 'المشهد فارغ. أضف عنصراً من شريط الأدوات للبدء.',
  noSelectionTitle: 'لا يوجد عنصر محدد',
  noSelectionHint: 'اختر عنصراً من المشهد ثلاثي الأبعاد أو من قائمة الهيكلة لعرض وتعديل خصائصه.',
  transform: 'التحويل الهندسي',
  position: 'الموقع',
  rotation: 'الدوران',
  scale: 'الحجم',
  resetTransform: 'إعادة ضبط التحويل',
  material: 'الخامة الفيزيائية',
  materialPresets: 'نماذج خامات',
  presetMatte: 'مطفي',
  presetChrome: 'معدن عاكس',
  presetGlass: 'زجاج منكسر',
  transmission: 'الشفافية والانكسار',
  ior: 'معامل الانكسار (IOR)',
  light: 'خصائص الإضاءة',
  lightAngle: 'زاوية المخروط',
  lightPenumbra: 'نعومة الحواف',
  lightWidth: 'عرض الإضاءة',
  lightHeight: 'ارتفاع الإضاءة',
  castShadow: 'إلقاء الظلال',
  modelInfo: 'بيانات المجسم المستورد',
  modelFormat: 'الصيغة',
  modelMeshes: 'الأجزاء',
  modelTriangles: 'المثلثات',
  cameraNodeTitle: 'خصائص الكاميرا',
  cameraNear: 'الحد القريب (Near)',
  cameraFar: 'الحد البعيد (Far)',
  alignViewToCamera: 'معاينة المشهد من هذه الكاميرا',
  color: 'اللون',
  roughness: 'الخشونة',
  metalness: 'المعدنية',
  wireframe: 'شبكة سلكية',
  intensity: 'الشدة',
  distance: 'المدى',
  name: 'الاسم',
  parentGroup: 'المجموعة الأب',
  rootLevel: 'الجذر الرئيسي',
  duplicate: 'نسخ',
  delete: 'حذف',
  hide: 'إخفاء',
  show: 'إظهار',
  lock: 'قفل',
  unlock: 'فتح القفل',
  moveMode: 'تحريك',
  rotateMode: 'تدوير',
  scaleMode: 'تحجيم',
  focusSelected: 'تركيز على المحدد',
  resetCamera: 'إعادة الكاميرا',
  orbitCameraMode: 'مدار',
  freeCameraMode: 'حرة',
  freeMoveForward: 'تحريك للأمام',
  freeMoveBackward: 'تحريك للخلف',
  freeMoveLeft: 'تحريك لليسار',
  freeMoveRight: 'تحريك لليمين',
  freeMoveUp: 'صعود للأعلى',
  freeMoveDown: 'نزول للأسفل',
  cameraPerspective: 'منظور',
  cameraTop: 'علوي',
  cameraFront: 'أمامي',
  cameraSide: 'جانبي',
  engineRealtime: 'Real-Time',
  enginePathTracing: 'Path Tracing',
  ptModeInteractive: 'حركة (5 عينات)',
  ptModeConverging: 'تراكم',
  ptModeIdle: 'مكتمل',
  ptSamplesLabel: 'عينات',
  projectManagerTitle: 'إدارة المشاريع والمشاهد',
  newProjectName: 'اسم المشروع الجديد',
  createProject: 'إنشاء مشروع',
  templateShowcase: 'مشهد عرض فيزيائي (GLB + إضاءات)',
  templateStarter: 'مشهد استوديو أولي',
  templateEmpty: 'مشهد فارغ',
  savedProjects: 'المشاريع المحفوظة محلياً',
  open: 'فتح',
  active: 'نشط',
  renameProject: 'تعديل الاسم',
  nodesCount: 'عنصر',
  settingsTitle: 'إعدادات المحرر والرندر',
  renderEngineLabel: 'محرك الرندر النشط',
  showGrid: 'إظهار الشبكة الأرضية',
  showAxes: 'إظهار محاور الإحداثيات',
  snapToGrid: 'التقاط للشبكة (Snap)',
  cameraFov: 'زاوية الكاميرا (FOV)',
  language: 'لغة الواجهة',
  close: 'إغلاق',
  cancel: 'إلغاء',
  confirm: 'تأكيد',
  nodeTypes: {
    box: 'مكعب',
    sphere: 'كرة',
    cylinder: 'أسطوانة',
    cone: 'مخروط',
    torus: 'حلقة',
    plane: 'مستوى',
    group: 'مجموعة',
    pointLight: 'إضاءة نقطية',
    directionalLight: 'إضاءة شمسية',
    spotLight: 'إضاءة موجهة',
    areaLight: 'إضاءة مساحية',
    camera: 'كاميرا',
    model: 'مجسم مستورد',
  },
  exportModal: {
    title: 'استوديو تصيير وتصدير الصور',
    subtitle: 'ضبط نسبة الإطار ودقة الإخراج وعينات Path Tracing حتى 1024 SPP مع البناء التدريجي المباشر',
    engineLabel: 'محرك التصيير',
    aspectSectionTitle: 'أ. نسبة الإطار (Aspect Ratio)',
    aspectSquare: 'مربع',
    aspectLandscape: 'عريض',
    aspectPortrait: 'طولي',
    aspectStandard: 'قياسي',
    aspectPhoto: 'تصوير',
    aspectCustom: 'نسبة مخصصة',
    ratioWidthLabel: 'عرض النسبة',
    ratioHeightLabel: 'ارتفاع النسبة',
    resolutionSectionTitle: 'ب. دقة الإخراج (Output Resolution)',
    resolutionCustom: 'مخصصة',
    customWidthLabel: 'العرض (px)',
    customHeightLabel: 'الارتفاع (px)',
    samplesLabel: 'عينات Path Tracing (حتى 1024)',
    outputSummaryLabel: 'أبعاد الإخراج النهائية',
    pixelsLabel: 'إجمالي البكسلات',
    estMemoryLabel: 'الذاكرة المتوقعة',
    tileModeLabel: 'نظام المعالجة',
    tileGridLabel: 'عرض شبكة المربعات',
    startRender: 'بدء التصيير',
    pauseRender: 'إيقاف مؤقت',
    resumeRender: 'استئناف',
    cancelRender: 'إلغاء',
    rendering: 'جاري التتبع الفيزيائي...',
    pausedLabel: 'متوقف مؤقتاً',
    completedLabel: 'اكتمل التصيير بنجاح',
    cancelledLabel: 'تم إيقاف التصيير',
    idleLabel: 'جاهز للتصيير',
    downloadPng: 'حفظ الصورة (PNG)',
    previewEmpty: 'اضغط "بدء التصيير" لبدء البناء التدريجي للمشهد أمامك لحظة بلحظة.',
    elapsedLabel: 'الوقت',
    speedLabel: 'السرعة',
    tilesLabel: 'المربعات',
    showTileOverlayLabel: 'حدود المربعات',
  },
  renderPanel: {
    title: 'إعدادات التصيير وجودة المشهد',
    subtitle: 'ضبط الدقة والإضاءة والمعالجة البصرية والأداء الفوري',
    resetDefaults: 'إعادة الافتراضي',
    presetsLabel: 'أوضاع جاهزة',
    presetPerformance: 'أداء سريع',
    presetBalanced: 'متوازن',
    presetCinematic: 'سينمائي',
    groupImageQuality: 'جودة الصورة',
    groupLightingVisual: 'الإضاءة والجودة البصرية',
    groupPerformance: 'الأداء',
    resolution: 'دقة الصورة (Resolution)',
    resolutionDesc: 'تحديد أبعاد الإخراج القصوى للعرض والتصيير النهائي.',
    resolutionNative: 'دقة الشاشة الأصلية',
    renderScale: 'نسبة التصيير الداخلي (Render Scale)',
    renderScaleDesc: 'مضاعف دقة التصيير الداخلية قبل العرض على الشاشة.',
    pixelRatio: 'كثافة البكسلات (Pixel Ratio)',
    pixelRatioDesc: 'عدد البكسلات المستخدمة لكل نقطة عرض لزيادة الحدة.',
    antiAliasing: 'منع التعرج (Anti-Aliasing)',
    antiAliasingDesc: 'تنعيم الحواف المتعرجة للأجسام ثلاثية الأبعاد.',
    aaNone: 'إيقاف',
    shadowQuality: 'جودة الظلال (Shadow Quality)',
    shadowQualityDesc: 'تحديد نعومة ودقة ترشيح الظلال الساقطة.',
    ambientOcclusion: 'ظلال التلامس (Ambient Occlusion)',
    ambientOcclusionDesc: 'إضافة تظليل دقيق في الزوايا ونقاط التلامس لإبراز العمق.',
    exposure: 'التعرض الضوئي (Exposure)',
    exposureDesc: 'التحكم بالسطوع الكلي للإضاءة داخل المشهد.',
    gamma: 'استجابة السطوع (Gamma)',
    gammaDesc: 'ضبط منحنى استجابة الدرجات اللونية بين الظلال والإضاءة.',
    contrast: 'التباين (Contrast)',
    contrastDesc: 'زيادة أو تقليل الفارق بين المناطق الداكنة والمضيئة.',
    bloom: 'التوهج الضوئي (Bloom)',
    bloomDesc: 'إضافة هالة توهج ناعمة حول الأسطح والمصادر شديدة السطوع.',
    bloomIntensity: 'شدة التوهج',
    dof: 'عمق المجال (Depth of Field)',
    dofDesc: 'محاكاة تركيز العدسة وعزل الخلفية عن المسافة البؤرية.',
    dofFocusDistance: 'مسافة التركيز',
    dofAperture: 'فتحة العدسة',
    motionBlur: 'ضبابية الحركة (Motion Blur)',
    motionBlurDesc: 'إضافة أثر حركة سلس أثناء تحريك الكاميرا بسرعة.',
    motionBlurAmount: 'قوة الضبابية',
    previewQuality: 'جودة المعاينة (Preview Quality)',
    previewQualityDesc: 'مستوى دقة العرض التفاعلي أثناء العمل والتحرير.',
    renderQuality: 'جودة التصيير النهائي (Render Quality)',
    renderQualityDesc: 'نمط معالجة الألوان وتدرجات الإضاءة للمشهد.',
    textureQuality: 'جودة الخامات والإضاءة المحيطية',
    textureQualityDesc: 'دقة تفاصيل السطوح والانعكاسات البيئية.',
    shadowResolution: 'دقة خرائط الظلال (Shadow Resolution)',
    shadowResolutionDesc: 'حجم خريطة الظل بالبكسل؛ القيم الأعلى تعطي حواف أدق.',
    performanceMode: 'وضع الأداء العالي (Performance Mode)',
    performanceModeDesc: 'تقليل المؤثرات الثقيلة للحفاظ على سلاسة الإطارات على الهواتف.',
    levelOff: 'إيقاف',
    levelLow: 'منخفضة',
    levelMedium: 'متوسطة',
    levelHigh: 'عالية',
    levelDraft: 'مسودة',
    levelStandard: 'قياسية',
  },
};

const EN_STRINGS: TranslationStrings = {
  appName: 'DimensiX',
  projects: 'Projects',
  save: 'Save',
  saved: 'Saved',
  unsaved: 'Unsaved changes',
  undo: 'Undo',
  redo: 'Redo',
  settings: 'Settings',
  renderSettings: 'Render Settings',
  renderButtonShort: 'Settings',
  exportImage: 'Render / Export Image',
  exportShort: 'Export',
  hierarchy: 'Hierarchy',
  inspector: 'Inspector',
  addElements: 'Add Objects',
  lightsMenu: 'Lights',
  importModel: 'Import Model',
  importing: 'Importing...',
  viewport: 'Viewport',
  emptySceneHint: 'Scene is empty. Add an element from the toolbar to begin.',
  noSelectionTitle: 'No Object Selected',
  noSelectionHint: 'Tap an object in the 3D viewport or Hierarchy panel to inspect and edit its properties.',
  transform: 'Transform',
  position: 'Position',
  rotation: 'Rotation',
  scale: 'Scale',
  resetTransform: 'Reset Transform',
  material: 'PBR Material',
  materialPresets: 'Surface Presets',
  presetMatte: 'Matte',
  presetChrome: 'Chrome',
  presetGlass: 'Glass',
  transmission: 'Transmission',
  ior: 'Refractive Index (IOR)',
  light: 'Light Properties',
  lightAngle: 'Cone Angle',
  lightPenumbra: 'Penumbra',
  lightWidth: 'Light Width',
  lightHeight: 'Light Height',
  castShadow: 'Cast Shadow',
  modelInfo: 'Imported Model',
  modelFormat: 'Format',
  modelMeshes: 'Meshes',
  modelTriangles: 'Triangles',
  cameraNodeTitle: 'Camera Properties',
  cameraNear: 'Near Clip',
  cameraFar: 'Far Clip',
  alignViewToCamera: 'View From This Camera',
  color: 'Color',
  roughness: 'Roughness',
  metalness: 'Metalness',
  wireframe: 'Wireframe',
  intensity: 'Intensity',
  distance: 'Distance',
  name: 'Name',
  parentGroup: 'Parent',
  rootLevel: 'Scene Root',
  duplicate: 'Duplicate',
  delete: 'Delete',
  hide: 'Hide',
  show: 'Show',
  lock: 'Lock',
  unlock: 'Unlock',
  moveMode: 'Move',
  rotateMode: 'Rotate',
  scaleMode: 'Scale',
  focusSelected: 'Focus Selected',
  resetCamera: 'Reset Camera',
  orbitCameraMode: 'Orbit',
  freeCameraMode: 'Free',
  freeMoveForward: 'Move Forward',
  freeMoveBackward: 'Move Backward',
  freeMoveLeft: 'Move Left',
  freeMoveRight: 'Move Right',
  freeMoveUp: 'Move Up',
  freeMoveDown: 'Move Down',
  cameraPerspective: 'Persp',
  cameraTop: 'Top',
  cameraFront: 'Front',
  cameraSide: 'Side',
  engineRealtime: 'Real-Time',
  enginePathTracing: 'Path Tracing',
  ptModeInteractive: 'Interactive (5)',
  ptModeConverging: 'Sampling',
  ptModeIdle: 'Converged',
  ptSamplesLabel: 'spp',
  projectManagerTitle: 'Projects & Scenes',
  newProjectName: 'New project name',
  createProject: 'Create Project',
  templateShowcase: 'Physical Showcase (GLB + 4 Lights)',
  templateStarter: 'Studio Starter',
  templateEmpty: 'Empty Scene',
  savedProjects: 'Locally Saved Projects',
  open: 'Open',
  active: 'Active',
  renameProject: 'Rename',
  nodesCount: 'nodes',
  settingsTitle: 'Editor & Engine Settings',
  renderEngineLabel: 'Active Render Engine',
  showGrid: 'Show Ground Grid',
  showAxes: 'Show World Axes',
  snapToGrid: 'Grid Snap',
  cameraFov: 'Camera FOV',
  language: 'Interface Language',
  close: 'Close',
  cancel: 'Cancel',
  confirm: 'Confirm',
  nodeTypes: {
    box: 'Cube',
    sphere: 'Sphere',
    cylinder: 'Cylinder',
    cone: 'Cone',
    torus: 'Torus',
    plane: 'Plane',
    group: 'Group',
    pointLight: 'Point Light',
    directionalLight: 'Sun Light',
    spotLight: 'Spot Light',
    areaLight: 'Area Light',
    camera: 'Camera',
    model: '3D Model',
  },
  exportModal: {
    title: 'Render & Export Studio',
    subtitle: 'Independent Aspect Ratio, Output Resolution, and progressive Path Tracing up to 1024 SPP',
    engineLabel: 'Render Engine',
    aspectSectionTitle: 'A. Image Aspect Ratio',
    aspectSquare: 'Square',
    aspectLandscape: 'Landscape',
    aspectPortrait: 'Portrait',
    aspectStandard: 'Standard',
    aspectPhoto: 'Photo',
    aspectCustom: 'Custom',
    ratioWidthLabel: 'Ratio W',
    ratioHeightLabel: 'Ratio H',
    resolutionSectionTitle: 'B. Output Resolution',
    resolutionCustom: 'Custom',
    customWidthLabel: 'Width (px)',
    customHeightLabel: 'Height (px)',
    samplesLabel: 'Path Tracing Samples (up to 1024)',
    outputSummaryLabel: 'Target Output',
    pixelsLabel: 'Total Pixels',
    estMemoryLabel: 'Est. Peak RAM',
    tileModeLabel: 'Execution Mode',
    tileGridLabel: 'Tile Grid',
    startRender: 'Start Render',
    pauseRender: 'Pause',
    resumeRender: 'Resume',
    cancelRender: 'Cancel',
    rendering: 'Path Tracing Tiles...',
    pausedLabel: 'Paused',
    completedLabel: 'Render Complete',
    cancelledLabel: 'Render Cancelled',
    idleLabel: 'Ready',
    downloadPng: 'Save Image (PNG)',
    previewEmpty: 'Press "Start Render" to watch the frame build tile by tile and sample by sample.',
    elapsedLabel: 'Elapsed',
    speedLabel: 'Throughput',
    tilesLabel: 'Tiles',
    showTileOverlayLabel: 'Tile Overlay',
  },
  renderPanel: {
    title: 'Render & Visual Settings',
    subtitle: 'Configure output quality, lighting response, post-effects, and performance',
    resetDefaults: 'Reset Defaults',
    presetsLabel: 'Quick Presets',
    presetPerformance: 'Performance',
    presetBalanced: 'Balanced',
    presetCinematic: 'Cinematic',
    groupImageQuality: 'Image Quality',
    groupLightingVisual: 'Lighting & Visual Quality',
    groupPerformance: 'Performance',
    resolution: 'Resolution',
    resolutionDesc: 'Sets the target output resolution cap for viewport and final render.',
    resolutionNative: 'Native Screen',
    renderScale: 'Render Scale',
    renderScaleDesc: 'Internal rendering scale multiplier relative to viewport dimensions.',
    pixelRatio: 'Pixel Ratio',
    pixelRatioDesc: 'Maximum device pixels sampled per logical CSS point.',
    antiAliasing: 'Anti-Aliasing',
    antiAliasingDesc: 'Smooths jagged polygon edges across 3D geometry.',
    aaNone: 'Off',
    shadowQuality: 'Shadow Quality',
    shadowQualityDesc: 'Controls shadow filtering softness and edge precision.',
    ambientOcclusion: 'Ambient Occlusion',
    ambientOcclusionDesc: 'Adds subtle contact darkening in crevices to emphasize depth.',
    exposure: 'Exposure',
    exposureDesc: 'Adjusts overall scene brightness and light energy balance.',
    gamma: 'Gamma',
    gammaDesc: 'Controls midtone brightness response curve.',
    contrast: 'Contrast',
    contrastDesc: 'Adjusts separation between dark shadows and bright highlights.',
    bloom: 'Bloom',
    bloomDesc: 'Adds a soft luminous glow around bright highlights and lights.',
    bloomIntensity: 'Bloom Intensity',
    dof: 'Depth of Field',
    dofDesc: 'Simulates camera lens focus and optical background blur.',
    dofFocusDistance: 'Focus Distance',
    dofAperture: 'Aperture',
    motionBlur: 'Motion Blur',
    motionBlurDesc: 'Applies directional frame persistence during rapid camera motion.',
    motionBlurAmount: 'Blur Amount',
    previewQuality: 'Preview Quality',
    previewQualityDesc: 'Interactive viewport detail level while editing the scene.',
    renderQuality: 'Render Quality',
    renderQualityDesc: 'Tone mapping and final shading fidelity level.',
    textureQuality: 'Texture Quality',
    textureQualityDesc: 'Surface detail and environment reflection intensity.',
    shadowResolution: 'Shadow Resolution',
    shadowResolutionDesc: 'Shadow map texture size in pixels; higher yields sharper edges.',
    performanceMode: 'Performance Mode',
    performanceModeDesc: 'Prioritizes smooth frame rates on mobile by bypassing heavy passes.',
    levelOff: 'Off',
    levelLow: 'Low',
    levelMedium: 'Medium',
    levelHigh: 'High',
    levelDraft: 'Draft',
    levelStandard: 'Standard',
  },
};

export function getTranslations(lang: EditorLanguage): TranslationStrings {
  return lang === 'en' ? EN_STRINGS : AR_STRINGS;
}
