import type { IRenderEngine, RenderEngineDescriptor } from './IRenderEngine';

export type RenderEngineFactory = () => IRenderEngine;

interface RegisteredEngine {
  descriptor: RenderEngineDescriptor;
  factory: RenderEngineFactory;
}

export class RenderEngineRegistry {
  private engines = new Map<string, RegisteredEngine>();

  register(descriptor: RenderEngineDescriptor, factory: RenderEngineFactory): void {
    this.engines.set(descriptor.id, { descriptor, factory });
  }

  unregister(id: string): void {
    this.engines.delete(id);
  }

  listDescriptors(): RenderEngineDescriptor[] {
    return Array.from(this.engines.values()).map((entry) => entry.descriptor);
  }

  has(id: string): boolean {
    return this.engines.has(id);
  }

  create(id: string): IRenderEngine {
    const entry = this.engines.get(id);
    if (!entry) {
      throw new Error(`Render engine "${id}" is not registered.`);
    }
    return entry.factory();
  }
}
