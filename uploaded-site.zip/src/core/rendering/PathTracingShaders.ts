export const FULLSCREEN_VERTEX_SHADER = `
out vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}
`;

export const PATH_TRACER_FRAGMENT_SHADER = `
precision highp float;
precision highp sampler2D;

in vec2 vUv;
out vec4 fragColor;

uniform sampler2D uPrevAccumTex;
uniform sampler2D uBvhNodesTex;
uniform sampler2D uTriTex;
uniform sampler2D uInstanceTex;
uniform sampler2D uMaterialTex;
uniform sampler2D uLightTex;
uniform sampler2D uAtlasTex;

uniform int uBvhNodesWidth;
uniform int uTriWidth;
uniform int uInstanceWidth;
uniform int uMaterialWidth;
uniform int uInstanceCount;
uniform int uLightCount;

uniform vec2 uResolution;
uniform vec2 uTileOrigin;
uniform int uSampleIndex;
uniform int uAccumReset;
uniform int uOutputSumMode;
uniform int uMaxBounces;
uniform vec3 uCamPos;
uniform vec3 uCamForward;
uniform vec3 uCamRight;
uniform vec3 uCamUp;
uniform float uTanHalfFov;
uniform float uAspect;
uniform float uDofEnabled;
uniform float uDofFocus;
uniform float uDofAperture;
uniform float uEnvIntensity;

const float PI = 3.14159265359;
const float INV_PI = 0.31830988618;
const float INF_DIST = 1e20;
const float EPS = 1e-4;

// --- PCG Hash RNG ---
uint pcgHash(inout uint state) {
  state = state * 747796405u + 2891336453u;
  uint word = ((state >> ((state >> 28u) + 4u)) ^ state) * 277803737u;
  return (word >> 22u) ^ word;
}

float rand01(inout uint state) {
  return float(pcgHash(state)) / 4294967296.0;
}

vec2 rand2(inout uint state) {
  return vec2(rand01(state), rand01(state));
}

// --- Texel Fetch Helpers ---
vec4 fetch1D(sampler2D tex, int texelIdx, int texWidth) {
  int y = texelIdx / texWidth;
  int x = texelIdx - y * texWidth;
  return texelFetch(tex, ivec2(x, y), 0);
}

mat4 fetchMat4(int baseTexel) {
  vec4 c0 = fetch1D(uInstanceTex, baseTexel + 0, uInstanceWidth);
  vec4 c1 = fetch1D(uInstanceTex, baseTexel + 1, uInstanceWidth);
  vec4 c2 = fetch1D(uInstanceTex, baseTexel + 2, uInstanceWidth);
  vec4 c3 = fetch1D(uInstanceTex, baseTexel + 3, uInstanceWidth);
  return mat4(c0, c1, c2, c3);
}

mat3 fetchNormalMat3(int baseTexel) {
  vec3 c0 = fetch1D(uInstanceTex, baseTexel + 8, uInstanceWidth).xyz;
  vec3 c1 = fetch1D(uInstanceTex, baseTexel + 9, uInstanceWidth).xyz;
  vec3 c2 = fetch1D(uInstanceTex, baseTexel + 10, uInstanceWidth).xyz;
  return mat3(c0, c1, c2);
}

struct HitRecord {
  float t;
  vec3 pos;
  vec3 normal;
  vec3 geomNormal;
  vec2 uv;
  int materialIdx;
  bool frontFace;
  bool isEmissiveLight;
  vec3 lightEmission;
  float lightArea;
};

struct Material {
  vec3 albedo;
  float roughness;
  float metalness;
  float transmission;
  float ior;
  vec3 emissive;
  float textureSlot;
  bool doubleSided;
};

Material loadMaterial(int idx, vec2 uv) {
  int base = idx * 3;
  vec4 m0 = fetch1D(uMaterialTex, base + 0, uMaterialWidth);
  vec4 m1 = fetch1D(uMaterialTex, base + 1, uMaterialWidth);
  vec4 m2 = fetch1D(uMaterialTex, base + 2, uMaterialWidth);

  Material mat;
  mat.albedo = m0.rgb;
  mat.roughness = clamp(m0.a, 0.03, 1.0);
  mat.metalness = clamp(m1.r, 0.0, 1.0);
  mat.transmission = clamp(m1.g, 0.0, 1.0);
  mat.ior = clamp(m1.b, 1.0, 2.5);
  mat.textureSlot = m1.a;
  mat.emissive = m2.rgb;
  mat.doubleSided = m2.a > 0.5;

  if (mat.textureSlot >= -0.25) {
    float slot = floor(mat.textureSlot + 0.5);
    float col = mod(slot, 4.0);
    float row = floor(slot / 4.0);
    vec2 tileUv = fract(uv);
    vec2 atlasUv = (vec2(col, row) + tileUv * 0.98 + 0.01) * 0.25;
    vec3 texRgb = texture(uAtlasTex, atlasUv).rgb;
    mat.albedo *= pow(max(texRgb, vec3(0.001)), vec3(2.2));
  }
  return mat;
}

vec3 safeInvDir(vec3 d) {
  return vec3(
    1.0 / (abs(d.x) > 1e-8 ? d.x : (d.x >= 0.0 ? 1e-8 : -1e-8)),
    1.0 / (abs(d.y) > 1e-8 ? d.y : (d.y >= 0.0 ? 1e-8 : -1e-8)),
    1.0 / (abs(d.z) > 1e-8 ? d.z : (d.z >= 0.0 ? 1e-8 : -1e-8))
  );
}

float intersectAABB(vec3 ro, vec3 invDir, vec3 bMin, vec3 bMax, float tMin, float tMax) {
  vec3 t0s = (bMin - ro) * invDir;
  vec3 t1s = (bMax - ro) * invDir;
  vec3 tSm = min(t0s, t1s);
  vec3 tBg = max(t0s, t1s);
  float tNear = max(tMin, max(tSm.x, max(tSm.y, tSm.z)));
  float tFar = min(tMax, min(tBg.x, min(tBg.y, tBg.z)));
  return (tNear <= tFar) ? tNear : INF_DIST;
}

bool intersectTri(
  vec3 ro,
  vec3 rd,
  int triIdx,
  float tMin,
  float tMax,
  out float outT,
  out float outU,
  out float outV
) {
  int base = triIdx * 7;
  vec4 t0 = fetch1D(uTriTex, base + 0, uTriWidth);
  vec4 t1 = fetch1D(uTriTex, base + 1, uTriWidth);
  vec4 t2 = fetch1D(uTriTex, base + 2, uTriWidth);

  vec3 p0 = t0.xyz;
  vec3 e1 = t1.xyz - p0;
  vec3 e2 = t2.xyz - p0;

  vec3 pvec = cross(rd, e2);
  float det = dot(e1, pvec);
  if (abs(det) < 1e-7) return false;
  float invDet = 1.0 / det;

  vec3 tvec = ro - p0;
  float u = dot(tvec, pvec) * invDet;
  if (u < 0.0 || u > 1.0) return false;

  vec3 qvec = cross(tvec, e1);
  float v = dot(rd, qvec) * invDet;
  if (v < 0.0 || u + v > 1.0) return false;

  float t = dot(e2, qvec) * invDet;
  if (t < tMin || t >= tMax) return false;

  outT = t;
  outU = u;
  outV = v;
  return true;
}

bool intersectScene(vec3 ro, vec3 rd, float tMaxIn, bool includeLights, out HitRecord hit) {
  hit.t = tMaxIn;
  hit.materialIdx = -1;
  hit.isEmissiveLight = false;
  hit.lightEmission = vec3(0.0);
  hit.lightArea = 1.0;
  bool found = false;

  // 1. Studio Ground Disc at y = -0.005 (radius 42m)
  if (abs(rd.y) > 1e-5) {
    float tGround = (-0.005 - ro.y) / rd.y;
    if (tGround > EPS && tGround < hit.t) {
      vec3 gPos = ro + rd * tGround;
      if (dot(gPos.xz, gPos.xz) <= 42.0 * 42.0) {
        hit.t = tGround;
        hit.pos = gPos;
        hit.normal = rd.y < 0.0 ? vec3(0.0, 1.0, 0.0) : vec3(0.0, -1.0, 0.0);
        hit.geomNormal = hit.normal;
        hit.uv = gPos.xz * 0.25;
        hit.materialIdx = -2;
        hit.frontFace = rd.y < 0.0;
        found = true;
      }
    }
  }

  // 2. Visible Area Lights (direct camera rays + glossy BSDF MIS)
  if (includeLights) {
    for (int li = 0; li < 16; li++) {
      if (li >= uLightCount) break;
      int lb = li * 6;
      vec4 l0 = texelFetch(uLightTex, ivec2(lb + 0, 0), 0);
      if (abs(l0.w - 3.0) > 0.2) continue;
      vec4 l1 = texelFetch(uLightTex, ivec2(lb + 1, 0), 0);
      vec4 l2 = texelFetch(uLightTex, ivec2(lb + 2, 0), 0);
      vec4 l3 = texelFetch(uLightTex, ivec2(lb + 3, 0), 0);
      vec3 tanU = texelFetch(uLightTex, ivec2(lb + 4, 0), 0).xyz;
      vec3 tanV = texelFetch(uLightTex, ivec2(lb + 5, 0), 0).xyz;

      vec3 lPos = l0.xyz;
      vec3 lDir = normalize(l1.xyz);
      float denom = dot(rd, lDir);
      if (abs(denom) > 1e-5) {
        float tl = dot(lPos - ro, lDir) / denom;
        if (tl > EPS && tl < hit.t) {
          vec3 p = ro + rd * tl;
          vec3 d = p - lPos;
          float uProj = dot(d, tanU);
          float vProj = dot(d, tanV);
          if (abs(uProj) <= l3.x * 0.5 && abs(vProj) <= l3.y * 0.5) {
            hit.t = tl;
            hit.pos = p;
            hit.normal = denom < 0.0 ? -lDir : lDir;
            hit.geomNormal = hit.normal;
            hit.uv = vec2(uProj / max(l3.x, 0.01) + 0.5, vProj / max(l3.y, 0.01) + 0.5);
            hit.materialIdx = -3;
            hit.frontFace = denom < 0.0;
            hit.isEmissiveLight = true;
            hit.lightEmission = l2.rgb * max(l1.w * 0.65, 0.2);
            hit.lightArea = max(l3.x, 0.1) * max(l3.y, 0.1);
            found = true;
          }
        }
      }
    }
  }

  if (uInstanceCount <= 0) {
    return found;
  }

  // 3. Two-level BVH (TLAS + BLAS) traversal with expanded stack for complex imported models
  vec3 invRd = safeInvDir(rd);
  int tlasStack[28];
  int tlasSp = 0;
  tlasStack[tlasSp++] = 0;

  int hitTriIdx = -1;
  float hitU = 0.0;
  float hitV = 0.0;
  int hitInstBase = 0;

  for (int iter = 0; iter < 256; iter++) {
    if (tlasSp <= 0) break;
    int nodeIdx = tlasStack[--tlasSp];
    vec4 n0 = fetch1D(uBvhNodesTex, nodeIdx * 2 + 0, uBvhNodesWidth);
    vec4 n1 = fetch1D(uBvhNodesTex, nodeIdx * 2 + 1, uBvhNodesWidth);
    if (intersectAABB(ro, invRd, n0.xyz, n1.xyz, EPS, hit.t) >= hit.t) {
      continue;
    }

    if (n1.w > 0.0) {
      int firstInst = int(n0.w + 0.5);
      int instCount = int(n1.w + 0.5);
      for (int ii = 0; ii < 4; ii++) {
        if (ii >= instCount) break;
        int instIdx = firstInst + ii;
        int instBase = instIdx * 12;
        mat4 invM = fetchMat4(instBase);
        vec3 lRo = (invM * vec4(ro, 1.0)).xyz;
        vec3 lRd = (invM * vec4(rd, 0.0)).xyz;
        vec3 lInvRd = safeInvDir(lRd);

        vec4 iMeta = fetch1D(uInstanceTex, instBase + 11, uInstanceWidth);
        int blasRoot = int(iMeta.x + 0.5);

        int blasStack[40];
        int blasSp = 0;
        blasStack[blasSp++] = blasRoot;

        for (int bIter = 0; bIter < 512; bIter++) {
          if (blasSp <= 0) break;
          int bIdx = blasStack[--blasSp];
          vec4 bn0 = fetch1D(uBvhNodesTex, bIdx * 2 + 0, uBvhNodesWidth);
          vec4 bn1 = fetch1D(uBvhNodesTex, bIdx * 2 + 1, uBvhNodesWidth);
          if (intersectAABB(lRo, lInvRd, bn0.xyz, bn1.xyz, EPS, hit.t) >= hit.t) {
            continue;
          }

          if (bn1.w > 0.0) {
            int firstTri = int(bn0.w + 0.5);
            int triCount = int(bn1.w + 0.5);
            for (int ti = 0; ti < 8; ti++) {
              if (ti >= triCount) break;
              float tt, uu, vv;
              if (intersectTri(lRo, lRd, firstTri + ti, EPS, hit.t, tt, uu, vv)) {
                hit.t = tt;
                hitTriIdx = firstTri + ti;
                hitU = uu;
                hitV = vv;
                hitInstBase = instBase;
                found = true;
              }
            }
          } else {
            int leftIdx = int(bn0.w + 0.5);
            int rightIdx = int(-bn1.w - 1.0 + 0.5);
            if (blasSp < 38) {
              blasStack[blasSp++] = rightIdx;
              blasStack[blasSp++] = leftIdx;
            }
          }
        }
      }
    } else {
      int leftIdx = int(n0.w + 0.5);
      int rightIdx = int(-n1.w - 1.0 + 0.5);
      if (tlasSp < 26) {
        tlasStack[tlasSp++] = rightIdx;
        tlasStack[tlasSp++] = leftIdx;
      }
    }
  }

  if (hitTriIdx >= 0) {
    int tb = hitTriIdx * 7;
    vec4 t0 = fetch1D(uTriTex, tb + 0, uTriWidth);
    vec4 t1 = fetch1D(uTriTex, tb + 1, uTriWidth);
    vec4 t2 = fetch1D(uTriTex, tb + 2, uTriWidth);
    vec4 t3 = fetch1D(uTriTex, tb + 3, uTriWidth);
    vec4 t4 = fetch1D(uTriTex, tb + 4, uTriWidth);
    vec4 t5 = fetch1D(uTriTex, tb + 5, uTriWidth);
    vec4 t6 = fetch1D(uTriTex, tb + 6, uTriWidth);

    float w = 1.0 - hitU - hitV;
    vec3 localNormal = normalize(t3.xyz * w + t4.xyz * hitU + t5.xyz * hitV);
    vec2 uv = vec2(t0.w, t1.w) * w + vec2(t2.w, t3.w) * hitU + vec2(t4.w, t5.w) * hitV;

    mat3 normM = fetchNormalMat3(hitInstBase);
    vec3 worldN = normalize(normM * localNormal);

    vec3 faceLocal = cross(t1.xyz - t0.xyz, t2.xyz - t0.xyz);
    vec3 worldGeomN = normalize(normM * faceLocal);

    vec4 iMeta = fetch1D(uInstanceTex, hitInstBase + 11, uInstanceWidth);
    int matBase = int(iMeta.y + 0.5);
    int localMat = int(t6.x + 0.5);

    hit.pos = ro + rd * hit.t;
    hit.uv = uv;
    hit.materialIdx = matBase + localMat;
    hit.isEmissiveLight = false;
    hit.frontFace = dot(rd, worldGeomN) < 0.0;
    hit.geomNormal = hit.frontFace ? worldGeomN : -worldGeomN;
    hit.normal = dot(worldN, hit.geomNormal) >= 0.0 ? worldN : -worldN;
  }

  return found;
}

bool isOccluded(vec3 ro, vec3 rd, float maxDist) {
  HitRecord shadowHit;
  return intersectScene(ro, rd, maxDist - EPS * 2.0, false, shadowHit);
}

// --- Studio HDR Sky Dome ---
vec3 evalEnvironment(vec3 rd) {
  float y = clamp(rd.y, -1.0, 1.0);
  vec3 horizon = vec3(0.06, 0.09, 0.16);
  vec3 zenith = vec3(0.14, 0.21, 0.38);
  vec3 nadir = vec3(0.025, 0.03, 0.055);
  vec3 sky = y >= 0.0 ? mix(horizon, zenith, pow(y, 0.55)) : mix(horizon, nadir, pow(-y, 0.7));

  vec3 keyDir = normalize(vec3(0.55, 0.72, 0.42));
  vec3 rimDir = normalize(vec3(-0.65, 0.42, -0.58));
  float keyLobe = pow(max(dot(rd, keyDir), 0.0), 18.0);
  float rimLobe = pow(max(dot(rd, rimDir), 0.0), 12.0);
  sky += vec3(1.15, 1.05, 0.92) * keyLobe * 0.55;
  sky += vec3(0.24, 0.68, 1.0) * rimLobe * 0.35;

  return sky * uEnvIntensity;
}

// --- Orthonormal Basis & GGX Microfacet Math ---
void buildONB(vec3 n, out vec3 t, out vec3 b) {
  vec3 up = abs(n.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
  t = normalize(cross(up, n));
  b = cross(n, t);
}

vec3 sampleCosineHemisphere(vec2 u, vec3 n) {
  float phi = 2.0 * PI * u.x;
  float cosTheta = sqrt(max(0.0, 1.0 - u.y));
  float sinTheta = sqrt(max(0.0, u.y));
  vec3 t, b;
  buildONB(n, t, b);
  return normalize(t * (cos(phi) * sinTheta) + b * (sin(phi) * sinTheta) + n * cosTheta);
}

vec3 sampleGGXHalfVec(vec2 u, vec3 n, float alpha) {
  float a2 = alpha * alpha;
  float phi = 2.0 * PI * u.x;
  float cosTheta = sqrt(max(0.0, (1.0 - u.y) / (1.0 + (a2 - 1.0) * u.y)));
  float sinTheta = sqrt(max(0.0, 1.0 - cosTheta * cosTheta));
  vec3 t, b;
  buildONB(n, t, b);
  return normalize(t * (cos(phi) * sinTheta) + b * (sin(phi) * sinTheta) + n * cosTheta);
}

float distributionGGX(float NdotH, float alpha) {
  float a2 = alpha * alpha;
  float d = NdotH * NdotH * (a2 - 1.0) + 1.0;
  return a2 / max(PI * d * d, 1e-6);
}

float smithG1(float NdotX, float k) {
  return NdotX / max(NdotX * (1.0 - k) + k, 1e-6);
}

float geometrySmith(float NdotV, float NdotL, float roughness) {
  float r = roughness + 1.0;
  float k = (r * r) / 8.0;
  return smithG1(NdotV, k) * smithG1(NdotL, k);
}

vec3 fresnelSchlick(float cosTheta, vec3 F0) {
  return F0 + (1.0 - F0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);
}

float fresnelDielectric(float cosI, float etaI, float etaT) {
  float r0 = (etaI - etaT) / (etaI + etaT);
  r0 = r0 * r0;
  return r0 + (1.0 - r0) * pow(clamp(1.0 - abs(cosI), 0.0, 1.0), 5.0);
}

vec3 evalPBRBsdf(vec3 N, vec3 V, vec3 L, Material mat, out float outPdf) {
  float NdotL = max(dot(N, L), 0.0);
  float NdotV = max(dot(N, V), 0.0);
  if (NdotL <= 0.0 || NdotV <= 0.0) {
    outPdf = 0.0;
    return vec3(0.0);
  }

  vec3 H = normalize(V + L);
  float NdotH = max(dot(N, H), 0.0);
  float VdotH = max(dot(V, H), 0.0);

  vec3 F0 = mix(vec3(0.04), mat.albedo, mat.metalness);
  vec3 F = fresnelSchlick(VdotH, F0);

  float alpha = mat.roughness * mat.roughness;
  float D = distributionGGX(NdotH, alpha);
  float G = geometrySmith(NdotV, NdotL, mat.roughness);

  vec3 spec = (D * G * F) / max(4.0 * NdotV * NdotL, 1e-5);
  vec3 kD = (1.0 - F) * (1.0 - mat.metalness) * (1.0 - mat.transmission);
  vec3 diff = kD * mat.albedo * INV_PI;

  float specProb = clamp(mix(0.25, 0.9, mat.metalness + (1.0 - mat.roughness) * 0.4), 0.1, 0.95);
  float diffPdf = NdotL * INV_PI;
  float specPdf = (D * NdotH) / max(4.0 * VdotH, 1e-5);
  outPdf = mix(diffPdf, specPdf, specProb);

  return diff + spec;
}

// --- Direct Light NEE + MIS ---
vec3 sampleDirectLight(HitRecord hit, vec3 V, Material mat, inout uint rng) {
  if (uLightCount <= 0) return vec3(0.0);

  int lightIdx = min(uLightCount - 1, int(rand01(rng) * float(uLightCount)));
  float lightPickPdf = 1.0 / float(uLightCount);

  int lb = lightIdx * 6;
  vec4 l0 = texelFetch(uLightTex, ivec2(lb + 0, 0), 0);
  vec4 l1 = texelFetch(uLightTex, ivec2(lb + 1, 0), 0);
  vec4 l2 = texelFetch(uLightTex, ivec2(lb + 2, 0), 0);
  vec4 l3 = texelFetch(uLightTex, ivec2(lb + 3, 0), 0);

  float lType = l0.w;
  vec3 lColor = l2.rgb;
  float lIntensity = l1.w;
  float lRange = max(l2.w, 1.0);
  float softness = max(l3.z, 0.01);
  bool castShadow = l3.w > 0.5;

  vec3 origin = hit.pos + hit.geomNormal * EPS * 2.0;
  vec3 L;
  float dist = 1000.0;
  vec3 radiance = vec3(0.0);
  float lightPdf = 1.0;

  if (lType < 0.5) {
    vec2 u = rand2(rng);
    float z = 1.0 - 2.0 * u.x;
    float r = sqrt(max(0.0, 1.0 - z * z));
    float phi = 2.0 * PI * u.y;
    vec3 jitter = vec3(r * cos(phi), r * sin(phi), z) * softness;
    vec3 targetPos = l0.xyz + jitter;
    vec3 toL = targetPos - origin;
    dist = length(toL);
    if (dist > lRange) return vec3(0.0);
    L = toL / max(dist, 1e-5);
    float atten = 1.0 / max(dist * dist + 0.15, 0.25);
    float rangeFade = clamp(1.0 - pow(dist / lRange, 4.0), 0.0, 1.0);
    radiance = lColor * lIntensity * 0.45 * atten * rangeFade;
    lightPdf = lightPickPdf;
  } else if (lType < 1.5) {
    vec3 sunDir = normalize(-l1.xyz);
    vec3 t, b;
    buildONB(sunDir, t, b);
    vec2 u = rand2(rng);
    float rad = softness * sqrt(u.x);
    float ang = 2.0 * PI * u.y;
    L = normalize(sunDir + t * (rad * cos(ang)) + b * (rad * sin(ang)));
    dist = 150.0;
    radiance = lColor * lIntensity * 1.15;
    lightPdf = lightPickPdf;
  } else if (lType < 2.5) {
    vec3 spotForward = normalize(l1.xyz);
    vec2 u = rand2(rng);
    float ang = 2.0 * PI * u.x;
    float rad = softness * sqrt(u.y);
    vec3 st, sb;
    buildONB(spotForward, st, sb);
    vec3 lightSample = l0.xyz + st * (rad * cos(ang)) + sb * (rad * sin(ang));
    vec3 toL = lightSample - origin;
    dist = length(toL);
    if (dist > lRange) return vec3(0.0);
    L = toL / max(dist, 1e-5);

    float cosAngle = dot(-L, spotForward);
    float cosOuter = l3.x;
    float penumbra = clamp(l3.y, 0.02, 1.0);
    float cosInner = mix(cosOuter, 1.0, penumbra * 0.75);
    float spotFactor = smoothstep(cosOuter, cosInner, cosAngle);
    if (spotFactor <= 0.001) return vec3(0.0);

    float atten = 1.0 / max(dist * dist + 0.15, 0.25);
    float rangeFade = clamp(1.0 - pow(dist / lRange, 4.0), 0.0, 1.0);
    radiance = lColor * lIntensity * 0.65 * atten * rangeFade * spotFactor;
    lightPdf = lightPickPdf;
  } else {
    vec3 tanU = texelFetch(uLightTex, ivec2(lb + 4, 0), 0).xyz;
    vec3 tanV = texelFetch(uLightTex, ivec2(lb + 5, 0), 0).xyz;
    float w = max(l3.x, 0.1);
    float h = max(l3.y, 0.1);
    float area = w * h;

    vec2 u = rand2(rng) - 0.5;
    vec3 samplePt = l0.xyz + tanU * (u.x * w) + tanV * (u.y * h);
    vec3 toL = samplePt - origin;
    dist = length(toL);
    L = toL / max(dist, 1e-5);

    vec3 lightNormal = normalize(l1.xyz);
    float cosLight = abs(dot(lightNormal, -L));
    if (cosLight <= 1e-4) return vec3(0.0);

    float areaPdf = (dist * dist) / max(area * cosLight, 1e-5);
    lightPdf = lightPickPdf * areaPdf;
    radiance = lColor * lIntensity * 0.85;
  }

  float NdotL = max(dot(hit.normal, L), 0.0);
  if (NdotL <= 0.0) return vec3(0.0);

  if (castShadow && isOccluded(origin, L, dist)) {
    return vec3(0.0);
  }

  float bsdfPdf = 0.0;
  vec3 f = evalPBRBsdf(hit.normal, V, L, mat, bsdfPdf);

  float misWeight = (lType > 2.5)
    ? (lightPdf * lightPdf) / max(lightPdf * lightPdf + bsdfPdf * bsdfPdf, 1e-6)
    : 1.0;

  return f * radiance * NdotL * misWeight / max(lightPdf, 1e-5);
}

void main() {
  ivec2 localPx = ivec2(gl_FragCoord.xy);
  vec2 fullPx = uTileOrigin + gl_FragCoord.xy;
  ivec2 seedPx = ivec2(fullPx);
  uint rng = uint(seedPx.x) * 1973u + uint(seedPx.y) * 9277u + uint(uSampleIndex + 1) * 26699u;
  pcgHash(rng);

  vec2 jitter = rand2(rng) - 0.5;
  vec2 ndc = ((fullPx + jitter) / uResolution) * 2.0 - 1.0;

  vec3 rd = normalize(
    uCamForward +
    uCamRight * (ndc.x * uAspect * uTanHalfFov) +
    uCamUp * (ndc.y * uTanHalfFov)
  );
  vec3 ro = uCamPos;

  if (uDofEnabled > 0.5) {
    vec2 lensUv = rand2(rng);
    float r = uDofAperture * sqrt(lensUv.x);
    float theta = 2.0 * PI * lensUv.y;
    vec3 lensOffset = (uCamRight * cos(theta) + uCamUp * sin(theta)) * r;
    vec3 focalPt = ro + rd * uDofFocus;
    ro += lensOffset;
    rd = normalize(focalPt - ro);
  }

  vec3 throughput = vec3(1.0);
  vec3 radiance = vec3(0.0);
  float prevBsdfPdf = 1.0;
  bool prevSpecularBounce = true;

  for (int bounce = 0; bounce < 5; bounce++) {
    if (bounce >= uMaxBounces) break;

    HitRecord hit;
    bool hitSomething = intersectScene(ro, rd, INF_DIST, true, hit);
    if (!hitSomething) {
      radiance += throughput * evalEnvironment(rd);
      break;
    }

    if (hit.isEmissiveLight) {
      float misW = 1.0;
      if (bounce > 0 && !prevSpecularBounce && uLightCount > 0) {
        float cosL = max(abs(dot(hit.geomNormal, -rd)), 1e-4);
        float lightPickPdf = 1.0 / float(uLightCount);
        float areaPdf = lightPickPdf * (hit.t * hit.t) / max(hit.lightArea * cosL, 1e-5);
        misW = (prevBsdfPdf * prevBsdfPdf) / max(prevBsdfPdf * prevBsdfPdf + areaPdf * areaPdf, 1e-6);
      }
      radiance += throughput * hit.lightEmission * misW;
      break;
    }

    Material mat;
    if (hit.materialIdx == -2) {
      float checker = mod(floor(hit.pos.x) + floor(hit.pos.z), 2.0);
      mat.albedo = mix(vec3(0.022, 0.028, 0.048), vec3(0.028, 0.036, 0.06), checker * 0.35);
      mat.roughness = 0.78;
      mat.metalness = 0.06;
      mat.transmission = 0.0;
      mat.ior = 1.5;
      mat.emissive = vec3(0.0);
      mat.textureSlot = -1.0;
      mat.doubleSided = true;
    } else {
      mat = loadMaterial(hit.materialIdx, hit.uv);
    }

    radiance += throughput * mat.emissive;

    vec3 V = -rd;
    vec3 N = hit.normal;

    if (mat.transmission > 0.05 && rand01(rng) < mat.transmission) {
      float etaI = hit.frontFace ? 1.0 : mat.ior;
      float etaT = hit.frontFace ? mat.ior : 1.0;
      float eta = etaI / etaT;
      float cosI = clamp(dot(V, N), 0.0, 1.0);
      float F = fresnelDielectric(cosI, etaI, etaT);

      vec3 scatterDir;
      vec3 refractDir = refract(rd, N, eta);
      if (length(refractDir) < 1e-4 || rand01(rng) < F) {
        vec3 H = sampleGGXHalfVec(rand2(rng), N, mat.roughness * mat.roughness);
        scatterDir = reflect(rd, H);
        ro = hit.pos + hit.geomNormal * EPS * 2.0;
      } else {
        vec3 H = sampleGGXHalfVec(rand2(rng), N, mat.roughness * mat.roughness);
        vec3 microRefract = refract(rd, H, eta);
        scatterDir = length(microRefract) > 1e-4 ? normalize(microRefract) : normalize(refractDir);
        ro = hit.pos - hit.geomNormal * EPS * 2.5;
        throughput *= mix(vec3(1.0), max(mat.albedo, vec3(0.15)), 0.45);
      }
      rd = normalize(scatterDir);
      prevSpecularBounce = true;
      prevBsdfPdf = 1.0;
      continue;
    }

    radiance += throughput * sampleDirectLight(hit, V, mat, rng);

    if (uLightCount == 0 && bounce == 0) {
      radiance += throughput * mat.albedo * evalEnvironment(N) * 0.35;
    }

    float specProb = clamp(mix(0.25, 0.9, mat.metalness + (1.0 - mat.roughness) * 0.4), 0.1, 0.95);
    vec3 nextDir;
    if (rand01(rng) < specProb) {
      float alpha = mat.roughness * mat.roughness;
      vec3 H = sampleGGXHalfVec(rand2(rng), N, alpha);
      nextDir = reflect(-V, H);
      if (dot(nextDir, N) <= 0.0) break;

      float NdotL = max(dot(N, nextDir), 0.0);
      float NdotV = max(dot(N, V), 1e-4);
      float NdotH = max(dot(N, H), 1e-4);
      float VdotH = max(dot(V, H), 1e-4);
      vec3 F0 = mix(vec3(0.04), mat.albedo, mat.metalness);
      vec3 F = fresnelSchlick(VdotH, F0);
      float G = geometrySmith(NdotV, NdotL, mat.roughness);
      throughput *= (F * G * VdotH) / max(NdotV * NdotH * specProb, 1e-5);
      prevSpecularBounce = mat.roughness < 0.08;
      prevBsdfPdf = (distributionGGX(NdotH, alpha) * NdotH) / max(4.0 * VdotH, 1e-5);
    } else {
      nextDir = sampleCosineHemisphere(rand2(rng), N);
      vec3 F0 = mix(vec3(0.04), mat.albedo, mat.metalness);
      vec3 F = fresnelSchlick(max(dot(N, V), 0.0), F0);
      vec3 kD = (1.0 - F) * (1.0 - mat.metalness);
      throughput *= (kD * mat.albedo) / max(1.0 - specProb, 1e-5);
      prevSpecularBounce = false;
      prevBsdfPdf = max(dot(N, nextDir), 0.0) * INV_PI;
    }

    throughput = min(throughput, vec3(8.0));

    if (bounce >= 1) {
      float survive = clamp(max(throughput.r, max(throughput.g, throughput.b)), 0.12, 0.95);
      if (rand01(rng) > survive) break;
      throughput /= survive;
    }

    ro = hit.pos + hit.geomNormal * EPS * 2.0;
    rd = normalize(nextDir);
  }

  vec3 sanitized = clamp(radiance, vec3(0.0), vec3(64.0));
  if (uOutputSumMode == 1) {
    vec3 prevSum = uAccumReset == 1 ? vec3(0.0) : texelFetch(uPrevAccumTex, localPx, 0).rgb;
    fragColor = vec4(prevSum + sanitized, 1.0);
  } else {
    vec3 prev = uSampleIndex > 0 && uAccumReset == 0 ? texelFetch(uPrevAccumTex, localPx, 0).rgb : vec3(0.0);
    float blend = 1.0 / float(uSampleIndex + 1);
    fragColor = vec4(mix(prev, sanitized, blend), 1.0);
  }
}
`;

export const DENOISE_DISPLAY_FRAGMENT_SHADER = `
precision highp float;

in vec2 vUv;
out vec4 fragColor;

uniform sampler2D uAccumTex;
uniform vec2 uTexelSize;
uniform int uSampleCount;
uniform float uDenoiseStrength;
uniform float uExposure;
uniform float uContrast;
uniform float uGamma;
uniform int uToneMappingMode; // 0 = linear, 1 = reinhard, 2 = aces

vec3 acesToneMap(vec3 x) {
  float a = 2.51;
  float b = 0.03;
  float c = 2.43;
  float d = 0.59;
  float e = 0.14;
  return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

void main() {
  vec3 center = texture(uAccumTex, vUv).rgb;
  float centerLum = dot(center, vec3(0.2126, 0.7152, 0.0722));

  float adaptiveWeight = uDenoiseStrength * clamp(1.0 - float(uSampleCount) / 96.0, 0.0, 1.0);
  vec3 filtered = center;

  if (adaptiveWeight > 0.01) {
    vec3 sum = vec3(0.0);
    float totalW = 0.0;
    float sigmaColor = mix(0.14, 0.35, adaptiveWeight);

    for (int dy = -2; dy <= 2; dy++) {
      for (int dx = -2; dx <= 2; dx++) {
        vec2 offset = vec2(float(dx), float(dy)) * uTexelSize;
        vec3 sampleRgb = texture(uAccumTex, clamp(vUv + offset, vec2(0.0), vec2(1.0))).rgb;
        float sampleLum = dot(sampleRgb, vec3(0.2126, 0.7152, 0.0722));

        float spatialDist2 = float(dx * dx + dy * dy);
        float wSpatial = exp(-spatialDist2 / 4.5);
        float lumDiff = abs(sampleLum - centerLum) / max(centerLum + 0.15, 0.15);
        float wRange = exp(-(lumDiff * lumDiff) / (2.0 * sigmaColor * sigmaColor));
        float w = wSpatial * wRange;

        sum += sampleRgb * w;
        totalW += w;
      }
    }
    vec3 denoised = sum / max(totalW, 1e-5);
    filtered = mix(center, denoised, adaptiveWeight);
  }

  vec3 hdr = filtered * uExposure;
  vec3 mapped;
  if (uToneMappingMode == 0) {
    mapped = clamp(hdr, 0.0, 1.0);
  } else if (uToneMappingMode == 1) {
    mapped = hdr / (1.0 + hdr);
  } else {
    mapped = acesToneMap(hdr);
  }

  mapped = max((mapped - 0.5) * uContrast + 0.5, vec3(0.0));
  mapped = pow(mapped, vec3(1.0 / max(uGamma, 0.1)));

  fragColor = vec4(mapped, 1.0);
}
`;
