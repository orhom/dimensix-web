import {
  resolveTileToRgba8,
  TileAccumulationStore,
  type TilePostProcessParams,
} from '../TileAccumulationCore';

export interface WorkerAccumulateRequest {
  type: 'accumulateTile';
  requestId: number;
  jobId: string;
  tileKey: string;
  tx: number;
  tyTop: number;
  tw: number;
  th: number;
  batchSamples: number;
  incomingIsSum: boolean;
  flipY: boolean;
  incomingRgba: Float32Array;
  params: TilePostProcessParams;
}

export interface WorkerReleaseTileRequest {
  type: 'releaseTile';
  jobId: string;
  tileKey: string;
}

export interface WorkerDisposeJobRequest {
  type: 'disposeJob';
  jobId: string;
}

export type TileWorkerRequest =
  | WorkerAccumulateRequest
  | WorkerReleaseTileRequest
  | WorkerDisposeJobRequest;

export interface WorkerTileResultResponse {
  type: 'tileResult';
  requestId: number;
  jobId: string;
  tileKey: string;
  tx: number;
  tyTop: number;
  tw: number;
  th: number;
  tileSampleCount: number;
  rgba8: Uint8ClampedArray;
}

const jobStores = new Map<string, TileAccumulationStore>();

function getStore(jobId: string): TileAccumulationStore {
  let store = jobStores.get(jobId);
  if (!store) {
    store = new TileAccumulationStore();
    jobStores.set(jobId, store);
  }
  return store;
}

self.onmessage = (event: MessageEvent<TileWorkerRequest>) => {
  const msg = event.data;
  if (msg.type === 'disposeJob') {
    const store = jobStores.get(msg.jobId);
    store?.clear();
    jobStores.delete(msg.jobId);
    return;
  }

  if (msg.type === 'releaseTile') {
    jobStores.get(msg.jobId)?.releaseTile(msg.tileKey);
    return;
  }

  if (msg.type === 'accumulateTile') {
    const store = getStore(msg.jobId);
    const slot = store.accumulateTileBatch(
      msg.tileKey,
      msg.tw,
      msg.th,
      msg.batchSamples,
      msg.incomingRgba,
      msg.incomingIsSum,
      msg.flipY,
    );
    const rgba8 = resolveTileToRgba8(slot, msg.params);

    const response: WorkerTileResultResponse = {
      type: 'tileResult',
      requestId: msg.requestId,
      jobId: msg.jobId,
      tileKey: msg.tileKey,
      tx: msg.tx,
      tyTop: msg.tyTop,
      tw: msg.tw,
      th: msg.th,
      tileSampleCount: slot.sampleCount,
      rgba8,
    };

    (self as unknown as Worker).postMessage(response, [rgba8.buffer]);
  }
};
