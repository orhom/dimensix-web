interface CpuScenePayload {
  bvhNodesData: Float32Array;
  triData: Float32Array;
  instanceData: Float32Array;
  materialsData: Float32Array;
  lightsData: Float32Array;
  atlasData: Uint8Array;
  atlasWidth: number;
  atlasHeight: number;
  instanceCount: number;
  lightCount: number;
}

export interface CpuTraceTileRequest {
  type: 'initScene' | 'traceTile';
  jobId: string;
  scene?: CpuScenePayload;
  requestId?: number;
  tx?: number;
  tyTop?: number;
  tw?: number;
  th?: number;
  exportW?: number;
  exportH?: number;
  startSample?: number;
  batchSamples?: number;
  maxBounces?: number;
  camPos?: [number, number, number];
  camForward?: [number, number, number];
  camRight?: [number, number, number];
  camUp?: [number, number, number];
  tanHalfFov?: number;
  aspect?: number;
  dofEnabled?: boolean;
  dofFocus?: number;
  dofAperture?: number;
  envIntensity?: number;
}

export interface CpuTraceTileResponse {
  type: 'tracedTile';
  requestId: number;
  jobId: string;
  sumRgba: Float32Array;
}

const scenes = new Map<string, CpuScenePayload>();

const PI = Math.PI;
const INV_PI = 1 / Math.PI;
const EPS = 1e-4;
const INF_DIST = 1e20;

function pcgHash(stateArr: Uint32Array): number {
  let s = (Math.imul(stateArr[0], 747796405) + 2891336453) >>> 0;
  stateArr[0] = s;
  const shift = ((s >>> 28) + 4) >>> 0;
  const word = Math.imul((s >>> shift) ^ s, 277803737) >>> 0;
  return ((word >>> 22) ^ word) >>> 0;
}

function rand01(rng: Uint32Array): number {
  return pcgHash(rng) / 4294967296;
}

function safeInv(v: number): number {
  return Math.abs(v) > 1e-8 ? 1 / v : v >= 0 ? 1e8 : -1e8;
}

function intersectAABB(
  rox: number,
  roy: number,
  roz: number,
  idx: number,
  idy: number,
  idz: number,
  bMinX: number,
  bMinY: number,
  bMinZ: number,
  bMaxX: number,
  bMaxY: number,
  bMaxZ: number,
  tMax: number,
): number {
  const t0x = (bMinX - rox) * idx;
  const t1x = (bMaxX - rox) * idx;
  const t0y = (bMinY - roy) * idy;
  const t1y = (bMaxY - roy) * idy;
  const t0z = (bMinZ - roz) * idz;
  const t1z = (bMaxZ - roz) * idz;

  const tSmX = t0x < t1x ? t0x : t1x;
  const tBgX = t0x > t1x ? t0x : t1x;
  const tSmY = t0y < t1y ? t0y : t1y;
  const tBgY = t0y > t1y ? t0y : t1y;
  const tSmZ = t0z < t1z ? t0z : t1z;
  const tBgZ = t0z > t1z ? t0z : t1z;

  const tNear = Math.max(EPS, tSmX, tSmY, tSmZ);
  const tFar = Math.min(tMax, tBgX, tBgY, tBgZ);
  return tNear <= tFar ? tNear : INF_DIST;
}

interface CpuHit {
  t: number;
  px: number;
  py: number;
  pz: number;
  nx: number;
  ny: number;
  nz: number;
  gnx: number;
  gny: number;
  gnz: number;
  u: number;
  v: number;
  matIdx: number;
  frontFace: boolean;
  isLight: boolean;
  lightR: number;
  lightG: number;
  lightB: number;
  lightArea: number;
}

function intersectSceneCpu(
  sc: CpuScenePayload,
  rox: number,
  roy: number,
  roz: number,
  rdx: number,
  rdy: number,
  rdz: number,
  tMaxIn: number,
  includeLights: boolean,
  hit: CpuHit,
): boolean {
  hit.t = tMaxIn;
  hit.matIdx = -1;
  hit.isLight = false;
  let found = false;

  // Ground disc y = -0.005
  if (Math.abs(rdy) > 1e-5) {
    const tg = (-0.005 - roy) / rdy;
    if (tg > EPS && tg < hit.t) {
      const gx = rox + rdx * tg;
      const gz = roz + rdz * tg;
      if (gx * gx + gz * gz <= 42 * 42) {
        hit.t = tg;
        hit.px = gx;
        hit.py = -0.005;
        hit.pz = gz;
        hit.nx = 0;
        hit.ny = rdy < 0 ? 1 : -1;
        hit.nz = 0;
        hit.gnx = 0;
        hit.gny = hit.ny;
        hit.gnz = 0;
        hit.u = gx * 0.25;
        hit.v = gz * 0.25;
        hit.matIdx = -2;
        hit.frontFace = rdy < 0;
        found = true;
      }
    }
  }

  // Area lights
  if (includeLights) {
    const ld = sc.lightsData;
    for (let li = 0; li < sc.lightCount; li++) {
      const lb = li * 24;
      if (Math.abs(ld[lb + 3] - 3) > 0.2) continue;
      const dx = ld[lb + 4];
      const dy = ld[lb + 5];
      const dz = ld[lb + 6];
      const dLen = Math.hypot(dx, dy, dz) || 1;
      const ldx = dx / dLen;
      const ldy = dy / dLen;
      const ldz = dz / dLen;
      const denom = rdx * ldx + rdy * ldy + rdz * ldz;
      if (Math.abs(denom) <= 1e-5) continue;
      const tl =
        ((ld[lb + 0] - rox) * ldx + (ld[lb + 1] - roy) * ldy + (ld[lb + 2] - roz) * ldz) / denom;
      if (tl > EPS && tl < hit.t) {
        const px = rox + rdx * tl;
        const py = roy + rdy * tl;
        const pz = roz + rdz * tl;
        const vx = px - ld[lb + 0];
        const vy = py - ld[lb + 1];
        const vz = pz - ld[lb + 2];
        const uProj = vx * ld[lb + 16] + vy * ld[lb + 17] + vz * ld[lb + 18];
        const vProj = vx * ld[lb + 20] + vy * ld[lb + 21] + vz * ld[lb + 22];
        const w = Math.max(ld[lb + 12], 0.1);
        const h = Math.max(ld[lb + 13], 0.1);
        if (Math.abs(uProj) <= w * 0.5 && Math.abs(vProj) <= h * 0.5) {
          hit.t = tl;
          hit.px = px;
          hit.py = py;
          hit.pz = pz;
          hit.nx = denom < 0 ? -ldx : ldx;
          hit.ny = denom < 0 ? -ldy : ldy;
          hit.nz = denom < 0 ? -ldz : ldz;
          hit.gnx = hit.nx;
          hit.gny = hit.ny;
          hit.gnz = hit.nz;
          hit.matIdx = -3;
          hit.frontFace = denom < 0;
          hit.isLight = true;
          const mult = Math.max(ld[lb + 7] * 0.65, 0.2);
          hit.lightR = ld[lb + 8] * mult;
          hit.lightG = ld[lb + 9] * mult;
          hit.lightB = ld[lb + 10] * mult;
          hit.lightArea = w * h;
          found = true;
        }
      }
    }
  }

  if (sc.instanceCount <= 0) return found;

  const bvh = sc.bvhNodesData;
  const tris = sc.triData;
  const inst = sc.instanceData;

  const irdx = safeInv(rdx);
  const irdy = safeInv(rdy);
  const irdz = safeInv(rdz);

  const tlasStack = new Int32Array(32);
  let tlasSp = 0;
  tlasStack[tlasSp++] = 0;

  const blasStack = new Int32Array(48);

  let hitTriIdx = -1;
  let hitU = 0;
  let hitV = 0;
  let hitInstBase = 0;

  while (tlasSp > 0) {
    const nIdx = tlasStack[--tlasSp];
    const nb = nIdx * 8;
    if (
      intersectAABB(
        rox,
        roy,
        roz,
        irdx,
        irdy,
        irdz,
        bvh[nb + 0],
        bvh[nb + 1],
        bvh[nb + 2],
        bvh[nb + 4],
        bvh[nb + 5],
        bvh[nb + 6],
        hit.t,
      ) >= hit.t
    ) {
      continue;
    }

    const primCount = bvh[nb + 7];
    if (primCount > 0) {
      const firstInst = Math.round(bvh[nb + 3]);
      const instCount = Math.round(primCount);
      for (let ii = 0; ii < instCount; ii++) {
        const iBase = (firstInst + ii) * 48;
        const lRox =
          inst[iBase + 0] * rox + inst[iBase + 4] * roy + inst[iBase + 8] * roz + inst[iBase + 12];
        const lRoy =
          inst[iBase + 1] * rox + inst[iBase + 5] * roy + inst[iBase + 9] * roz + inst[iBase + 13];
        const lRoz =
          inst[iBase + 2] * rox + inst[iBase + 6] * roy + inst[iBase + 10] * roz + inst[iBase + 14];
        const lRdx = inst[iBase + 0] * rdx + inst[iBase + 4] * rdy + inst[iBase + 8] * rdz;
        const lRdy = inst[iBase + 1] * rdx + inst[iBase + 5] * rdy + inst[iBase + 9] * rdz;
        const lRdz = inst[iBase + 2] * rdx + inst[iBase + 6] * rdy + inst[iBase + 10] * rdz;
        const lIrdx = safeInv(lRdx);
        const lIrdy = safeInv(lRdy);
        const lIrdz = safeInv(lRdz);

        let blasSp = 0;
        blasStack[blasSp++] = Math.round(inst[iBase + 44]);

        while (blasSp > 0) {
          const bIdx = blasStack[--blasSp];
          const bb = bIdx * 8;
          if (
            intersectAABB(
              lRox,
              lRoy,
              lRoz,
              lIrdx,
              lIrdy,
              lIrdz,
              bvh[bb + 0],
              bvh[bb + 1],
              bvh[bb + 2],
              bvh[bb + 4],
              bvh[bb + 5],
              bvh[bb + 6],
              hit.t,
            ) >= hit.t
          ) {
            continue;
          }

          const bCount = bvh[bb + 7];
          if (bCount > 0) {
            const firstTri = Math.round(bvh[bb + 3]);
            const tCount = Math.round(bCount);
            for (let ti = 0; ti < tCount; ti++) {
              const tIdx = firstTri + ti;
              const tb = tIdx * 28;
              const p0x = tris[tb + 0];
              const p0y = tris[tb + 1];
              const p0z = tris[tb + 2];
              const e1x = tris[tb + 4] - p0x;
              const e1y = tris[tb + 5] - p0y;
              const e1z = tris[tb + 6] - p0z;
              const e2x = tris[tb + 8] - p0x;
              const e2y = tris[tb + 9] - p0y;
              const e2z = tris[tb + 10] - p0z;

              const px = lRdy * e2z - lRdz * e2y;
              const py = lRdz * e2x - lRdx * e2z;
              const pz = lRdx * e2y - lRdy * e2x;
              const det = e1x * px + e1y * py + e1z * pz;
              if (Math.abs(det) < 1e-7) continue;
              const invDet = 1 / det;

              const tx = lRox - p0x;
              const ty = lRoy - p0y;
              const tz = lRoz - p0z;
              const u = (tx * px + ty * py + tz * pz) * invDet;
              if (u < 0 || u > 1) continue;

              const qx = ty * e1z - tz * e1y;
              const qy = tz * e1x - tx * e1z;
              const qz = tx * e1y - ty * e1x;
              const v = (lRdx * qx + lRdy * qy + lRdz * qz) * invDet;
              if (v < 0 || u + v > 1) continue;

              const tt = (e2x * qx + e2y * qy + e2z * qz) * invDet;
              if (tt >= EPS && tt < hit.t) {
                hit.t = tt;
                hitTriIdx = tIdx;
                hitU = u;
                hitV = v;
                hitInstBase = iBase;
                found = true;
              }
            }
          } else if (blasSp < 46) {
            blasStack[blasSp++] = Math.round(-bvh[bb + 7] - 1);
            blasStack[blasSp++] = Math.round(bvh[bb + 3]);
          }
        }
      }
    } else if (tlasSp < 30) {
      tlasStack[tlasSp++] = Math.round(-bvh[nb + 7] - 1);
      tlasStack[tlasSp++] = Math.round(bvh[nb + 3]);
    }
  }

  if (hitTriIdx >= 0) {
    const tb = hitTriIdx * 28;
    const w = 1 - hitU - hitV;
    const lnx = tris[tb + 12] * w + tris[tb + 16] * hitU + tris[tb + 20] * hitV;
    const lny = tris[tb + 13] * w + tris[tb + 17] * hitU + tris[tb + 21] * hitV;
    const lnz = tris[tb + 14] * w + tris[tb + 18] * hitU + tris[tb + 22] * hitV;

    const e1x = tris[tb + 4] - tris[tb + 0];
    const e1y = tris[tb + 5] - tris[tb + 1];
    const e1z = tris[tb + 6] - tris[tb + 2];
    const e2x = tris[tb + 8] - tris[tb + 0];
    const e2y = tris[tb + 9] - tris[tb + 1];
    const e2z = tris[tb + 10] - tris[tb + 2];
    const flx = e1y * e2z - e1z * e2y;
    const fly = e1z * e2x - e1x * e2z;
    const flz = e1x * e2y - e1y * e2x;

    const ib = hitInstBase;
    let wnx = inst[ib + 32] * lnx + inst[ib + 36] * lny + inst[ib + 40] * lnz;
    let wny = inst[ib + 33] * lnx + inst[ib + 37] * lny + inst[ib + 41] * lnz;
    let wnz = inst[ib + 34] * lnx + inst[ib + 38] * lny + inst[ib + 42] * lnz;
    const wnLen = Math.hypot(wnx, wny, wnz) || 1;
    wnx /= wnLen;
    wny /= wnLen;
    wnz /= wnLen;

    let gnx = inst[ib + 32] * flx + inst[ib + 36] * fly + inst[ib + 40] * flz;
    let gny = inst[ib + 33] * flx + inst[ib + 37] * fly + inst[ib + 41] * flz;
    let gnz = inst[ib + 34] * flx + inst[ib + 38] * fly + inst[ib + 42] * flz;
    const gnLen = Math.hypot(gnx, gny, gnz) || 1;
    gnx /= gnLen;
    gny /= gnLen;
    gnz /= gnLen;

    hit.px = rox + rdx * hit.t;
    hit.py = roy + rdy * hit.t;
    hit.pz = roz + rdz * hit.t;
    hit.u = tris[tb + 3] * w + tris[tb + 11] * hitU + tris[tb + 19] * hitV;
    hit.v = tris[tb + 7] * w + tris[tb + 15] * hitU + tris[tb + 23] * hitV;
    hit.matIdx = Math.round(inst[ib + 45]) + Math.round(tris[tb + 24]);
    hit.frontFace = rdx * gnx + rdy * gny + rdz * gnz < 0;
    if (!hit.frontFace) {
      gnx = -gnx;
      gny = -gny;
      gnz = -gnz;
    }
    if (wnx * gnx + wny * gny + wnz * gnz < 0) {
      wnx = -wnx;
      wny = -wny;
      wnz = -wnz;
    }
    hit.gnx = gnx;
    hit.gny = gny;
    hit.gnz = gnz;
    hit.nx = wnx;
    hit.ny = wny;
    hit.nz = wnz;
  }

  return found;
}

function evalSky(rdx: number, rdy: number, rdz: number, envIntensity: number): [number, number, number] {
  const y = Math.max(-1, Math.min(1, rdy));
  const t = y >= 0 ? Math.pow(y, 0.55) : Math.pow(-y, 0.7);
  let r = y >= 0 ? 0.06 + (0.14 - 0.06) * t : 0.06 + (0.025 - 0.06) * t;
  let g = y >= 0 ? 0.09 + (0.21 - 0.09) * t : 0.09 + (0.03 - 0.09) * t;
  let b = y >= 0 ? 0.16 + (0.38 - 0.16) * t : 0.16 + (0.055 - 0.16) * t;

  const keyDot = Math.max(0, rdx * 0.553 + rdy * 0.724 + rdz * 0.422);
  const rimDot = Math.max(0, rdx * -0.671 + rdy * 0.433 + rdz * -0.599);
  const keyLobe = Math.pow(keyDot, 18) * 0.55;
  const rimLobe = Math.pow(rimDot, 12) * 0.35;
  r += 1.15 * keyLobe + 0.24 * rimLobe;
  g += 1.05 * keyLobe + 0.68 * rimLobe;
  b += 0.92 * keyLobe + 1.0 * rimLobe;
  return [r * envIntensity, g * envIntensity, b * envIntensity];
}

function buildOnb(nx: number, ny: number, nz: number): [number, number, number, number, number, number] {
  const ux = Math.abs(nz) < 0.999 ? 0 : 1;
  const uy = 0;
  const uz = Math.abs(nz) < 0.999 ? 1 : 0;
  let tx = uy * nz - uz * ny;
  let ty = uz * nx - ux * nz;
  let tz = ux * ny - uy * nx;
  const tl = Math.hypot(tx, ty, tz) || 1;
  tx /= tl;
  ty /= tl;
  tz /= tl;
  const bx = ny * tz - nz * ty;
  const by = nz * tx - nx * tz;
  const bz = nx * ty - ny * tx;
  return [tx, ty, tz, bx, by, bz];
}

function traceTileBatchCpu(sc: CpuScenePayload, req: CpuTraceTileRequest): Float32Array {
  const tx = req.tx ?? 0;
  const tyTop = req.tyTop ?? 0;
  const tw = req.tw ?? 64;
  const th = req.th ?? 64;
  const exportW = req.exportW ?? tw;
  const exportH = req.exportH ?? th;
  const startSample = req.startSample ?? 0;
  const batchSamples = req.batchSamples ?? 1;
  const maxBounces = req.maxBounces ?? 4;
  const camPos = req.camPos ?? [0, 2, 5];
  const camFwd = req.camForward ?? [0, 0, -1];
  const camRight = req.camRight ?? [1, 0, 0];
  const camUp = req.camUp ?? [0, 1, 0];
  const tanHalfFov = req.tanHalfFov ?? 0.46;
  const aspect = req.aspect ?? exportW / exportH;
  const envIntensity = req.envIntensity ?? 1.0;

  const out = new Float32Array(tw * th * 4);
  const rng = new Uint32Array(1);
  const hit: CpuHit = {
    t: 0,
    px: 0,
    py: 0,
    pz: 0,
    nx: 0,
    ny: 0,
    nz: 0,
    gnx: 0,
    gny: 0,
    gnz: 0,
    u: 0,
    v: 0,
    matIdx: -1,
    frontFace: true,
    isLight: false,
    lightR: 0,
    lightG: 0,
    lightB: 0,
    lightArea: 1,
  };
  const shadowHit: CpuHit = { ...hit };

  for (let localY = 0; localY < th; localY++) {
    const glPy = exportH - 1 - (tyTop + localY) + 0.5;
    for (let localX = 0; localX < tw; localX++) {
      const glPx = tx + localX + 0.5;
      let sumR = 0;
      let sumG = 0;
      let sumB = 0;

      for (let s = 0; s < batchSamples; s++) {
        const sampleIdx = startSample + s;
        rng[0] =
          (Math.imul(Math.floor(glPx), 1973) +
            Math.imul(Math.floor(glPy), 9277) +
            Math.imul(sampleIdx + 1, 26699)) >>>
          0;
        pcgHash(rng);

        const jx = rand01(rng) - 0.5;
        const jy = rand01(rng) - 0.5;
        const ndcX = ((glPx + jx) / exportW) * 2 - 1;
        const ndcY = ((glPy + jy) / exportH) * 2 - 1;

        let rox = camPos[0];
        let roy = camPos[1];
        let roz = camPos[2];
        let rdx = camFwd[0] + camRight[0] * (ndcX * aspect * tanHalfFov) + camUp[0] * (ndcY * tanHalfFov);
        let rdy = camFwd[1] + camRight[1] * (ndcX * aspect * tanHalfFov) + camUp[1] * (ndcY * tanHalfFov);
        let rdz = camFwd[2] + camRight[2] * (ndcX * aspect * tanHalfFov) + camUp[2] * (ndcY * tanHalfFov);
        const rdLen = Math.hypot(rdx, rdy, rdz) || 1;
        rdx /= rdLen;
        rdy /= rdLen;
        rdz /= rdLen;

        let thrR = 1;
        let thrG = 1;
        let thrB = 1;
        let radR = 0;
        let radG = 0;
        let radB = 0;

        for (let bounce = 0; bounce < maxBounces; bounce++) {
          if (!intersectSceneCpu(sc, rox, roy, roz, rdx, rdy, rdz, INF_DIST, true, hit)) {
            const [skyR, skyG, skyB] = evalSky(rdx, rdy, rdz, envIntensity);
            radR += thrR * skyR;
            radG += thrG * skyG;
            radB += thrB * skyB;
            break;
          }

          if (hit.isLight) {
            radR += thrR * hit.lightR;
            radG += thrG * hit.lightG;
            radB += thrB * hit.lightB;
            break;
          }

          let albR = 0.7;
          let albG = 0.7;
          let albB = 0.7;
          let rough = 0.45;
          let metal = 0.1;
          let trans = 0;
          let ior = 1.5;
          let emR = 0;
          let emG = 0;
          let emB = 0;

          if (hit.matIdx === -2) {
            const chk = ((Math.floor(hit.px) + Math.floor(hit.pz)) & 1) !== 0 ? 0.35 : 0;
            albR = 0.022 + (0.028 - 0.022) * chk;
            albG = 0.028 + (0.036 - 0.028) * chk;
            albB = 0.048 + (0.06 - 0.048) * chk;
            rough = 0.78;
            metal = 0.06;
          } else if (hit.matIdx >= 0) {
            const mb = hit.matIdx * 12;
            albR = sc.materialsData[mb + 0];
            albG = sc.materialsData[mb + 1];
            albB = sc.materialsData[mb + 2];
            rough = Math.max(0.03, Math.min(1, sc.materialsData[mb + 3]));
            metal = Math.max(0, Math.min(1, sc.materialsData[mb + 4]));
            trans = Math.max(0, Math.min(1, sc.materialsData[mb + 5]));
            ior = Math.max(1, Math.min(2.5, sc.materialsData[mb + 6]));
            emR = sc.materialsData[mb + 8];
            emG = sc.materialsData[mb + 9];
            emB = sc.materialsData[mb + 10];
          }

          radR += thrR * emR;
          radG += thrG * emG;
          radB += thrB * emB;

          const vx = -rdx;
          const vy = -rdy;
          const vz = -rdz;

          if (trans > 0.05 && rand01(rng) < trans) {
            const eta = hit.frontFace ? 1 / ior : ior;
            const nDotI = rdx * hit.nx + rdy * hit.ny + rdz * hit.nz;
            const k = 1 - eta * eta * (1 - nDotI * nDotI);
            const cosI = Math.min(1, Math.max(0, Math.abs(nDotI)));
            const r0 = Math.pow((1 - ior) / (1 + ior), 2);
            const fresnel = r0 + (1 - r0) * Math.pow(1 - cosI, 5);
            if (k < 0 || rand01(rng) < fresnel) {
              rdx = rdx - 2 * nDotI * hit.nx;
              rdy = rdy - 2 * nDotI * hit.ny;
              rdz = rdz - 2 * nDotI * hit.nz;
              rox = hit.px + hit.gnx * EPS * 2;
              roy = hit.py + hit.gny * EPS * 2;
              roz = hit.pz + hit.gnz * EPS * 2;
            } else {
              const sqK = Math.sqrt(k);
              rdx = eta * rdx - (eta * nDotI + sqK) * hit.nx;
              rdy = eta * rdy - (eta * nDotI + sqK) * hit.ny;
              rdz = eta * rdz - (eta * nDotI + sqK) * hit.nz;
              rox = hit.px - hit.gnx * EPS * 2.5;
              roy = hit.py - hit.gny * EPS * 2.5;
              roz = hit.pz - hit.gnz * EPS * 2.5;
              thrR *= 0.55 + 0.45 * Math.max(albR, 0.15);
              thrG *= 0.55 + 0.45 * Math.max(albG, 0.15);
              thrB *= 0.55 + 0.45 * Math.max(albB, 0.15);
            }
            const l = Math.hypot(rdx, rdy, rdz) || 1;
            rdx /= l;
            rdy /= l;
            rdz /= l;
            continue;
          }

          // Direct lighting NEE
          if (sc.lightCount > 0) {
            const li = Math.min(sc.lightCount - 1, Math.floor(rand01(rng) * sc.lightCount));
            const lb = li * 24;
            const lType = sc.lightsData[lb + 3];
            const ox = hit.px + hit.gnx * EPS * 2;
            const oy = hit.py + hit.gny * EPS * 2;
            const oz = hit.pz + hit.gnz * EPS * 2;
            let lx = 0;
            let ly = 1;
            let lz = 0;
            let dist = 100;
            let lr = 0;
            let lg = 0;
            let lbC = 0;
            let lPdf = 1 / sc.lightCount;
            let validL = true;

            if (lType < 0.5) {
              const toX = sc.lightsData[lb + 0] - ox;
              const toY = sc.lightsData[lb + 1] - oy;
              const toZ = sc.lightsData[lb + 2] - oz;
              dist = Math.hypot(toX, toY, toZ);
              const lRange = Math.max(sc.lightsData[lb + 11], 1);
              if (dist > lRange) validL = false;
              lx = toX / (dist || 1);
              ly = toY / (dist || 1);
              lz = toZ / (dist || 1);
              const att = 1 / Math.max(dist * dist + 0.15, 0.25);
              const fade = Math.max(0, 1 - Math.pow(dist / lRange, 4));
              const e = sc.lightsData[lb + 7] * 0.45 * att * fade;
              lr = sc.lightsData[lb + 8] * e;
              lg = sc.lightsData[lb + 9] * e;
              lbC = sc.lightsData[lb + 10] * e;
            } else if (lType < 1.5) {
              const sLen =
                Math.hypot(sc.lightsData[lb + 4], sc.lightsData[lb + 5], sc.lightsData[lb + 6]) || 1;
              lx = -sc.lightsData[lb + 4] / sLen;
              ly = -sc.lightsData[lb + 5] / sLen;
              lz = -sc.lightsData[lb + 6] / sLen;
              dist = 150;
              const e = sc.lightsData[lb + 7] * 1.15;
              lr = sc.lightsData[lb + 8] * e;
              lg = sc.lightsData[lb + 9] * e;
              lbC = sc.lightsData[lb + 10] * e;
            } else if (lType < 2.5) {
              const toX = sc.lightsData[lb + 0] - ox;
              const toY = sc.lightsData[lb + 1] - oy;
              const toZ = sc.lightsData[lb + 2] - oz;
              dist = Math.hypot(toX, toY, toZ);
              const lRange = Math.max(sc.lightsData[lb + 11], 1);
              if (dist > lRange) validL = false;
              lx = toX / (dist || 1);
              ly = toY / (dist || 1);
              lz = toZ / (dist || 1);
              const spotF = -(
                lx * sc.lightsData[lb + 4] +
                ly * sc.lightsData[lb + 5] +
                lz * sc.lightsData[lb + 6]
              );
              const cosOuter = sc.lightsData[lb + 12];
              if (spotF <= cosOuter) validL = false;
              const att = 1 / Math.max(dist * dist + 0.15, 0.25);
              const e = sc.lightsData[lb + 7] * 0.65 * att;
              lr = sc.lightsData[lb + 8] * e;
              lg = sc.lightsData[lb + 9] * e;
              lbC = sc.lightsData[lb + 10] * e;
            } else {
              const aw = Math.max(sc.lightsData[lb + 12], 0.1);
              const ah = Math.max(sc.lightsData[lb + 13], 0.1);
              const u = rand01(rng) - 0.5;
              const v = rand01(rng) - 0.5;
              const sx = sc.lightsData[lb + 0] + sc.lightsData[lb + 16] * (u * aw) + sc.lightsData[lb + 20] * (v * ah);
              const sy = sc.lightsData[lb + 1] + sc.lightsData[lb + 17] * (u * aw) + sc.lightsData[lb + 21] * (v * ah);
              const sz = sc.lightsData[lb + 2] + sc.lightsData[lb + 18] * (u * aw) + sc.lightsData[lb + 22] * (v * ah);
              const toX = sx - ox;
              const toY = sy - oy;
              const toZ = sz - oz;
              dist = Math.hypot(toX, toY, toZ);
              lx = toX / (dist || 1);
              ly = toY / (dist || 1);
              lz = toZ / (dist || 1);
              const cosL = Math.abs(
                -(lx * sc.lightsData[lb + 4] + ly * sc.lightsData[lb + 5] + lz * sc.lightsData[lb + 6]),
              );
              if (cosL <= 1e-4) validL = false;
              lPdf *= (dist * dist) / Math.max(aw * ah * cosL, 1e-5);
              const e = sc.lightsData[lb + 7] * 0.85;
              lr = sc.lightsData[lb + 8] * e;
              lg = sc.lightsData[lb + 9] * e;
              lbC = sc.lightsData[lb + 10] * e;
            }

            const nDotL = Math.max(0, hit.nx * lx + hit.ny * ly + hit.nz * lz);
            if (validL && nDotL > 0) {
              const occluded =
                sc.lightsData[lb + 15] > 0.5 &&
                intersectSceneCpu(sc, ox, oy, oz, lx, ly, lz, dist - EPS * 2, false, shadowHit);
              if (!occluded) {
                const fDiffuse = (1 - metal) * (1 - trans) * INV_PI;
                const scale = (nDotL / Math.max(lPdf, 1e-5)) * fDiffuse;
                radR += thrR * albR * lr * scale;
                radG += thrG * albG * lg * scale;
                radB += thrB * albB * lbC * scale;
              }
            }
          }

          // Indirect bounce
          const specProb = Math.min(0.95, Math.max(0.1, 0.25 + (metal + (1 - rough) * 0.4) * 0.65));
          if (rand01(rng) < specProb) {
            const rx = -vx - 2 * (-vx * hit.nx - vy * hit.ny - vz * hit.nz) * hit.nx;
            const ry = -vy - 2 * (-vx * hit.nx - vy * hit.ny - vz * hit.nz) * hit.ny;
            const rz = -vz - 2 * (-vx * hit.nx - vy * hit.ny - vz * hit.nz) * hit.nz;
            const [txv, tyv, tzv, bxv, byv, bzv] = buildOnb(rx, ry, rz);
            const a = rand01(rng) * 2 * PI;
            const spread = rough * rough * 0.45 * Math.sqrt(rand01(rng));
            rdx = rx + txv * Math.cos(a) * spread + bxv * Math.sin(a) * spread;
            rdy = ry + tyv * Math.cos(a) * spread + byv * Math.sin(a) * spread;
            rdz = rz + tzv * Math.cos(a) * spread + bzv * Math.sin(a) * spread;
            const rl = Math.hypot(rdx, rdy, rdz) || 1;
            rdx /= rl;
            rdy /= rl;
            rdz /= rl;
            if (rdx * hit.nx + rdy * hit.ny + rdz * hit.nz <= 0) break;
            const f0R = 0.04 + (albR - 0.04) * metal;
            const f0G = 0.04 + (albG - 0.04) * metal;
            const f0B = 0.04 + (albB - 0.04) * metal;
            thrR *= f0R / specProb;
            thrG *= f0G / specProb;
            thrB *= f0B / specProb;
          } else {
            const [txv, tyv, tzv, bxv, byv, bzv] = buildOnb(hit.nx, hit.ny, hit.nz);
            const u1 = rand01(rng);
            const u2 = rand01(rng);
            const phi = 2 * PI * u1;
            const cosT = Math.sqrt(1 - u2);
            const sinT = Math.sqrt(u2);
            rdx = txv * Math.cos(phi) * sinT + bxv * Math.sin(phi) * sinT + hit.nx * cosT;
            rdy = tyv * Math.cos(phi) * sinT + byv * Math.sin(phi) * sinT + hit.ny * cosT;
            rdz = tzv * Math.cos(phi) * sinT + bzv * Math.sin(phi) * sinT + hit.nz * cosT;
            const rl = Math.hypot(rdx, rdy, rdz) || 1;
            rdx /= rl;
            rdy /= rl;
            rdz /= rl;
            const invDiff = (1 - metal) / Math.max(1 - specProb, 1e-5);
            thrR *= albR * invDiff;
            thrG *= albG * invDiff;
            thrB *= albB * invDiff;
          }

          rox = hit.px + hit.gnx * EPS * 2;
          roy = hit.py + hit.gny * EPS * 2;
          roz = hit.pz + hit.gnz * EPS * 2;
        }

        sumR += Math.min(64, Math.max(0, radR));
        sumG += Math.min(64, Math.max(0, radG));
        sumB += Math.min(64, Math.max(0, radB));
      }

      const oIdx = (localY * tw + localX) * 4;
      out[oIdx] = sumR;
      out[oIdx + 1] = sumG;
      out[oIdx + 2] = sumB;
      out[oIdx + 3] = 1;
    }
  }

  return out;
}

self.onmessage = (event: MessageEvent<CpuTraceTileRequest>) => {
  const msg = event.data;
  if (msg.type === 'initScene' && msg.scene) {
    scenes.set(msg.jobId, msg.scene);
    return;
  }
  if (msg.type === 'traceTile' && msg.requestId !== undefined) {
    const sc = scenes.get(msg.jobId);
    if (!sc) return;
    const sumRgba = traceTileBatchCpu(sc, msg);
    const res: CpuTraceTileResponse = {
      type: 'tracedTile',
      requestId: msg.requestId,
      jobId: msg.jobId,
      sumRgba,
    };
    (self as unknown as Worker).postMessage(res, [sumRgba.buffer]);
  }
};
