import test from 'node:test';
import assert from 'node:assert/strict';
import {
  clampSampleCount,
  computeExportDimensions,
  deriveHeightFromWidth,
  MAX_SAMPLES_LIMIT,
} from './AspectAndResolution';

test('1920 width with 16:9 aspect ratio yields exact 1920x1080', () => {
  const dims = computeExportDimensions({
    aspectPreset: '16:9',
    customAspectW: 16,
    customAspectH: 9,
    resolutionPreset: '1920',
    customWidth: 1920,
    customHeight: 1080,
  });
  assert.equal(dims.width, 1920);
  assert.equal(dims.height, 1080);
  assert.equal(dims.aspectLabel, '16:9');
  assert.equal(dims.totalPixels, 2_073_600);
});

test('3840 width with 16:9 yields exact 3840x2160 (4K UHD)', () => {
  const dims = computeExportDimensions({
    aspectPreset: '16:9',
    customAspectW: 16,
    customAspectH: 9,
    resolutionPreset: '3840',
    customWidth: 3840,
    customHeight: 2160,
  });
  assert.equal(dims.width, 3840);
  assert.equal(dims.height, 2160);
});

test('Aspect ratios stay strictly independent from resolution width', () => {
  const square = computeExportDimensions({
    aspectPreset: '1:1',
    customAspectW: 1,
    customAspectH: 1,
    resolutionPreset: '1024',
    customWidth: 1024,
    customHeight: 1024,
  });
  assert.equal(square.width, 1024);
  assert.equal(square.height, 1024);

  const portrait = computeExportDimensions({
    aspectPreset: '9:16',
    customAspectW: 9,
    customAspectH: 16,
    resolutionPreset: '512',
    customWidth: 512,
    customHeight: 910,
  });
  assert.equal(portrait.width, 512);
  assert.equal(portrait.height, 910);

  const photo = computeExportDimensions({
    aspectPreset: '3:2',
    customAspectW: 3,
    customAspectH: 2,
    resolutionPreset: '1920',
    customWidth: 1920,
    customHeight: 1280,
  });
  assert.equal(photo.width, 1920);
  assert.equal(photo.height, 1280);
});

test('Custom aspect ratio and custom resolution clamp safely', () => {
  const customRatio = computeExportDimensions({
    aspectPreset: 'custom',
    customAspectW: 21,
    customAspectH: 9,
    resolutionPreset: '2560',
    customWidth: 2560,
    customHeight: 1097,
  });
  assert.equal(customRatio.width, 2560);
  assert.equal(customRatio.height, 1097);
  assert.equal(customRatio.aspectLabel, '21:9');

  const customRes = computeExportDimensions({
    aspectPreset: '4:3',
    customAspectW: 4,
    customAspectH: 3,
    resolutionPreset: 'custom',
    customWidth: 1600,
    customHeight: 1200,
  });
  assert.equal(customRes.width, 1600);
  assert.equal(customRes.height, 1200);
  assert.equal(deriveHeightFromWidth(1024, '4:3', 4, 3), 768);
});

test('Sample count allows up to 1024 SPP and clamps outliers', () => {
  assert.equal(clampSampleCount(1024), MAX_SAMPLES_LIMIT);
  assert.equal(clampSampleCount(4096), 1024);
  assert.equal(clampSampleCount(0), 1);
  assert.equal(clampSampleCount(256), 256);
});
