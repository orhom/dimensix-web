import * as THREE from 'three';
import type { ModelAssetRegistry } from '../assets/ModelAssetRegistry';
import type { ImportedMaterialDescriptor, ImportedTextureData } from '../assets/ModelAssetTypes';
import {
  buildTwoLevelBVH,
  packBVHForGPU,
  type BVHGeometrySource,
  type BVHInstanceDescriptor,
  type PackedGPUBVH,
  type TwoLevelBVH,
} from '../bvh/BVHBuilder';
import {
  isLightNodeType,
  type NodeType,
  type SceneNode,
  type SceneSnapshot,
} from '../scene/SceneNode';

export interface PackedMaterialEntry {
  color: [number, number, number];
  roughness: number;
  metalness: number;
  transmission: number;
  ior: number;
  emissive: [number, number, number];
  textureSlot: number; // -1 if none
  doubleSided: boolean;
}

export interface SceneLightDescriptor {
  id: string;
  type: 'pointLight' | 'directionalLight' | 'spotLight' | 'areaLight';
  position: [number, number, number];
  direction: [number, number, number];
  tangentU: [number, number, number];
  tangentV: [number, number, number];
  color: [number, number, number];
  intensity: number;
  distance: number;
  angleRad: number;
  penumbra: number;
  width: number;
  height: number;
  softness: number;
  castShadow: boolean;
}

export interface PackedSceneForPathTracer {
  bvh: TwoLevelBVH;
  gpuBvh: PackedGPUBVH;
  materialsData: Float32Array;
  materialsWidth: number;
  materialsHeight: number;
  materialCount: number;
  lightsData: Float32Array;
  lightCount: number;
  lights: SceneLightDescriptor[];
  atlasData: Uint8Array;
  atlasWidth: number;
  atlasHeight: number;
  textureCount: number;
  totalMemoryBytes: number;
}

const MAX_ATLAS_SLOTS = 16; // 4x4 grid of 128x128 tiles => 512x512 RGBA8
const TILE_SIZE = 128;
const ATLAS_COLS = 4;
const ATLAS_DIM = TILE_SIZE * ATLAS_COLS;

export function createPrimitiveGeometry(
  type: Exclude<NodeType, 'group' | 'camera' | 'model' | 'pointLight' | 'directionalLight' | 'spotLight' | 'areaLight'>,
): THREE.BufferGeometry {
  switch (type) {
    case 'box':
      return new THREE.BoxGeometry(1, 1, 1);
    case 'sphere':
      return new THREE.SphereGeometry(0.55, 24, 16);
    case 'cylinder':
      return new THREE.CylinderGeometry(0.5, 0.5, 1, 24);
    case 'cone':
      return new THREE.ConeGeometry(0.55, 1.1, 24);
    case 'torus':
      return new THREE.TorusGeometry(0.5, 0.18, 14, 28);
    case 'plane':
      return new THREE.PlaneGeometry(1, 1);
  }
}

export function computeNodeWorldMatrices(nodes: SceneNode[]): Map<string, THREE.Matrix4> {
  const byId = new Map<string, SceneNode>();
  for (const n of nodes) byId.set(n.id, n);

  const localMats = new Map<string, THREE.Matrix4>();
  const euler = new THREE.Euler();
  const pos = new THREE.Vector3();
  const quat = new THREE.Quaternion();
  const scale = new THREE.Vector3();

  for (const n of nodes) {
    pos.set(n.transform.position.x, n.transform.position.y, n.transform.position.z);
    euler.set(
      THREE.MathUtils.degToRad(n.transform.rotation.x),
      THREE.MathUtils.degToRad(n.transform.rotation.y),
      THREE.MathUtils.degToRad(n.transform.rotation.z),
      'XYZ',
    );
    quat.setFromEuler(euler);
    scale.set(
      Math.abs(n.transform.scale.x) < 1e-4 ? 1e-4 : n.transform.scale.x,
      Math.abs(n.transform.scale.y) < 1e-4 ? 1e-4 : n.transform.scale.y,
      Math.abs(n.transform.scale.z) < 1e-4 ? 1e-4 : n.transform.scale.z,
    );
    const m = new THREE.Matrix4().compose(pos, quat, scale);
    localMats.set(n.id, m);
  }

  const worldMats = new Map<string, THREE.Matrix4>();
  const resolving = new Set<string>();

  const resolve = (id: string): THREE.Matrix4 => {
    const existing = worldMats.get(id);
    if (existing) return existing;

    const node = byId.get(id);
    if (!node) return new THREE.Matrix4();

    const local = localMats.get(id) ?? new THREE.Matrix4();
    if (!node.parentId || !byId.has(node.parentId) || resolving.has(id)) {
      const m = local.clone();
      worldMats.set(id, m);
      return m;
    }

    resolving.add(id);
    const parentWorld = resolve(node.parentId);
    resolving.delete(id);

    const m = new THREE.Matrix4().multiplyMatrices(parentWorld, local);
    worldMats.set(id, m);
    return m;
  };

  for (const n of nodes) {
    resolve(n.id);
  }
  return worldMats;
}

export function isNodeEffectivelyVisible(
  node: SceneNode,
  byId: Map<string, SceneNode>,
): boolean {
  let curr: SceneNode | undefined = node;
  let guard = 0;
  while (curr && guard++ < 64) {
    if (!curr.visible) return false;
    curr = curr.parentId ? byId.get(curr.parentId) : undefined;
  }
  return true;
}

export class PrimitiveGeometryCache {
  private map = new Map<string, THREE.BufferGeometry>();

  get(key: 'box' | 'sphere' | 'cylinder' | 'cone' | 'torus' | 'plane'): THREE.BufferGeometry {
    let geo = this.map.get(key);
    if (!geo) {
      geo = createPrimitiveGeometry(key);
      this.map.set(key, geo);
    }
    return geo;
  }

  dispose(): void {
    for (const geo of this.map.values()) {
      geo.dispose();
    }
    this.map.clear();
  }
}

export function buildPackedSceneForPathTracer(
  snapshot: SceneSnapshot,
  assetRegistry: ModelAssetRegistry | null,
  primitiveCache: PrimitiveGeometryCache,
): PackedSceneForPathTracer {
  const byId = new Map<string, SceneNode>();
  for (const n of snapshot.nodes) byId.set(n.id, n);

  const worldMatrices = computeNodeWorldMatrices(snapshot.nodes);
  const sourcesMap = new Map<string, BVHGeometrySource>();
  const instances: BVHInstanceDescriptor[] = [];
  const materials: PackedMaterialEntry[] = [];
  const lights: SceneLightDescriptor[] = [];

  // Texture atlas packing across all referenced ModelAssets
  const atlasData = new Uint8Array(ATLAS_DIM * ATLAS_DIM * 4);
  const textureSlotByKey = new Map<string, number>();
  let nextTextureSlot = 0;

  const registerTexture = (assetId: string, tex: ImportedTextureData): number => {
    const key = `${assetId}:${tex.id}`;
    const existing = textureSlotByKey.get(key);
    if (existing !== undefined) return existing;
    if (nextTextureSlot >= MAX_ATLAS_SLOTS) return -1;

    const slot = nextTextureSlot++;
    textureSlotByKey.set(key, slot);

    const tileCol = slot % ATLAS_COLS;
    const tileRow = Math.floor(slot / ATLAS_COLS);
    const destX0 = tileCol * TILE_SIZE;
    const destY0 = tileRow * TILE_SIZE;

    for (let y = 0; y < TILE_SIZE; y++) {
      const sy = Math.min(tex.height - 1, Math.floor((y / TILE_SIZE) * tex.height));
      for (let x = 0; x < TILE_SIZE; x++) {
        const sx = Math.min(tex.width - 1, Math.floor((x / TILE_SIZE) * tex.width));
        const sIdx = (sy * tex.width + sx) * 4;
        const dIdx = ((destY0 + y) * ATLAS_DIM + (destX0 + x)) * 4;
        atlasData[dIdx + 0] = tex.rgba[sIdx + 0];
        atlasData[dIdx + 1] = tex.rgba[sIdx + 1];
        atlasData[dIdx + 2] = tex.rgba[sIdx + 2];
        atlasData[dIdx + 3] = tex.rgba[sIdx + 3];
      }
    }

    return slot;
  };

  const colorTmp = new THREE.Color();
  const emissiveTmp = new THREE.Color();
  const posTmp = new THREE.Vector3();
  const quatTmp = new THREE.Quaternion();
  const scaleTmp = new THREE.Vector3();

  for (const node of snapshot.nodes) {
    if (!isNodeEffectivelyVisible(node, byId)) continue;
    const worldMat = worldMatrices.get(node.id) ?? new THREE.Matrix4();

    if (isLightNodeType(node.type) && node.light) {
      worldMat.decompose(posTmp, quatTmp, scaleTmp);
      const dir = new THREE.Vector3(0, 0, -1).applyQuaternion(quatTmp).normalize();
      const tangentU = new THREE.Vector3(1, 0, 0).applyQuaternion(quatTmp).normalize();
      const tangentV = new THREE.Vector3(0, 1, 0).applyQuaternion(quatTmp).normalize();
      colorTmp.set(node.light.color);

      lights.push({
        id: node.id,
        type: node.type as SceneLightDescriptor['type'],
        position: [posTmp.x, posTmp.y, posTmp.z],
        direction: [dir.x, dir.y, dir.z],
        tangentU: [tangentU.x, tangentU.y, tangentU.z],
        tangentV: [tangentV.x, tangentV.y, tangentV.z],
        color: [colorTmp.r, colorTmp.g, colorTmp.b],
        intensity: node.light.intensity,
        distance: node.light.distance,
        angleRad: THREE.MathUtils.degToRad(node.light.angle ?? 32),
        penumbra: node.light.penumbra ?? 0.45,
        width: (node.light.width ?? 2.4) * Math.max(0.25, Math.abs(scaleTmp.x)),
        height: (node.light.height ?? 1.6) * Math.max(0.25, Math.abs(scaleTmp.y)),
        softness: node.light.softness ?? (node.type === 'directionalLight' ? 0.04 : 0.16),
        castShadow: node.light.castShadow ?? true,
      });
      continue;
    }

    if (node.type === 'group' || node.type === 'camera') continue;

    if (node.type === 'model' && node.modelAsset && assetRegistry) {
      const asset = assetRegistry.get(node.modelAsset.assetId);
      if (!asset) continue;

      for (const tex of asset.textures) {
        registerTexture(asset.assetId, tex);
      }

      for (const part of asset.parts) {
        if (!sourcesMap.has(part.geometryKey)) {
          sourcesMap.set(part.geometryKey, {
            geometryKey: part.geometryKey,
            geometry: part.geometry,
            submeshes: part.submeshes,
          });
        }

        const partLocal = new THREE.Matrix4().fromArray(part.localMatrix);
        const partWorld = new THREE.Matrix4().multiplyMatrices(worldMat, partLocal);

        const materialBase = materials.length;
        const partMatIndices: number[] = [];
        for (const desc of part.materials) {
          const matIdx = materials.length;
          materials.push(descriptorToPackedMaterial(desc, asset.assetId, textureSlotByKey));
          partMatIndices.push(matIdx);
        }
        if (partMatIndices.length === 0) {
          materials.push({
            color: [0.8, 0.84, 0.9],
            roughness: 0.45,
            metalness: 0.2,
            transmission: 0,
            ior: 1.5,
            emissive: [0, 0, 0],
            textureSlot: -1,
            doubleSided: false,
          });
          partMatIndices.push(materialBase);
        }

        instances.push({
          instanceIndex: instances.length,
          nodeId: node.id,
          geometryKey: part.geometryKey,
          worldMatrix: partWorld,
          materialIndices: partMatIndices,
        });
      }
      continue;
    }

    if (
      node.type === 'box' ||
      node.type === 'sphere' ||
      node.type === 'cylinder' ||
      node.type === 'cone' ||
      node.type === 'torus' ||
      node.type === 'plane'
    ) {
      const geoKey = `prim:${node.type}`;
      if (!sourcesMap.has(geoKey)) {
        sourcesMap.set(geoKey, {
          geometryKey: geoKey,
          geometry: primitiveCache.get(node.type),
        });
      }

      const matData = node.material;
      colorTmp.set(matData?.color ?? '#8B5CF6');
      emissiveTmp.set(matData?.emissive ?? '#000000');
      const emIntensity = matData?.emissiveIntensity ?? 0;

      const matIdx = materials.length;
      materials.push({
        color: [colorTmp.r, colorTmp.g, colorTmp.b],
        roughness: Math.max(0.03, matData?.roughness ?? 0.38),
        metalness: matData?.metalness ?? 0.22,
        transmission: matData?.transmission ?? 0,
        ior: matData?.ior ?? 1.5,
        emissive: [
          emissiveTmp.r * emIntensity,
          emissiveTmp.g * emIntensity,
          emissiveTmp.b * emIntensity,
        ],
        textureSlot: -1,
        doubleSided: node.type === 'plane',
      });

      instances.push({
        instanceIndex: instances.length,
        nodeId: node.id,
        geometryKey: geoKey,
        worldMatrix: worldMat.clone(),
        materialIndices: [matIdx],
      });
    }
  }

  // Build 2-level BVH & GPU texture arrays
  const bvh = buildTwoLevelBVH(Array.from(sourcesMap.values()), instances);
  const gpuBvh = packBVHForGPU(bvh);

  // Pack materials: 3 RGBA32F texels per material
  // M0: color.rgb, roughness
  // M1: metalness, transmission, ior, textureSlot
  // M2: emissive.rgb, doubleSided (1.0 or 0.0)
  const matCount = Math.max(1, materials.length);
  const materialsWidth = 256;
  const materialsHeight = Math.max(1, Math.ceil((matCount * 3) / materialsWidth));
  const materialsData = new Float32Array(materialsWidth * materialsHeight * 4);
  for (let i = 0; i < materials.length; i++) {
    const m = materials[i];
    const base = i * 3 * 4;
    materialsData[base + 0] = m.color[0];
    materialsData[base + 1] = m.color[1];
    materialsData[base + 2] = m.color[2];
    materialsData[base + 3] = m.roughness;

    materialsData[base + 4] = m.metalness;
    materialsData[base + 5] = m.transmission;
    materialsData[base + 6] = m.ior;
    materialsData[base + 7] = m.textureSlot;

    materialsData[base + 8] = m.emissive[0];
    materialsData[base + 9] = m.emissive[1];
    materialsData[base + 10] = m.emissive[2];
    materialsData[base + 11] = m.doubleSided ? 1 : 0;
  }

  // Pack up to 16 lights: 6 RGBA32F texels per light
  // L0: position.xyz, type (0=point,1=dir,2=spot,3=area)
  // L1: direction.xyz, intensity
  // L2: color.rgb, distance
  // L3: angleCosOrWidth, penumbraOrHeight, softness, castShadow
  // L4: tangentU.xyz, 0
  // L5: tangentV.xyz, 0
  const MAX_LIGHTS = 16;
  const clampedLightCount = Math.min(lights.length, MAX_LIGHTS);
  const lightsData = new Float32Array(MAX_LIGHTS * 6 * 4);
  for (let i = 0; i < clampedLightCount; i++) {
    const l = lights[i];
    const base = i * 24;
    const typeId =
      l.type === 'pointLight'
        ? 0
        : l.type === 'directionalLight'
          ? 1
          : l.type === 'spotLight'
            ? 2
            : 3;
    lightsData[base + 0] = l.position[0];
    lightsData[base + 1] = l.position[1];
    lightsData[base + 2] = l.position[2];
    lightsData[base + 3] = typeId;

    lightsData[base + 4] = l.direction[0];
    lightsData[base + 5] = l.direction[1];
    lightsData[base + 6] = l.direction[2];
    lightsData[base + 7] = l.intensity;

    lightsData[base + 8] = l.color[0];
    lightsData[base + 9] = l.color[1];
    lightsData[base + 10] = l.color[2];
    lightsData[base + 11] = l.distance;

    lightsData[base + 12] = l.type === 'areaLight' ? l.width : Math.cos(l.angleRad);
    lightsData[base + 13] = l.type === 'areaLight' ? l.height : l.penumbra;
    lightsData[base + 14] = l.softness;
    lightsData[base + 15] = l.castShadow ? 1 : 0;

    lightsData[base + 16] = l.tangentU[0];
    lightsData[base + 17] = l.tangentU[1];
    lightsData[base + 18] = l.tangentU[2];
    lightsData[base + 19] = 0;

    lightsData[base + 20] = l.tangentV[0];
    lightsData[base + 21] = l.tangentV[1];
    lightsData[base + 22] = l.tangentV[2];
    lightsData[base + 23] = 0;
  }

  const totalMemoryBytes =
    gpuBvh.estimatedGpuBytes + materialsData.byteLength + atlasData.byteLength;

  return {
    bvh,
    gpuBvh,
    materialsData,
    materialsWidth,
    materialsHeight,
    materialCount: materials.length,
    lightsData,
    lightCount: clampedLightCount,
    lights: lights.slice(0, clampedLightCount),
    atlasData,
    atlasWidth: ATLAS_DIM,
    atlasHeight: ATLAS_DIM,
    textureCount: nextTextureSlot,
    totalMemoryBytes,
  };
}

function descriptorToPackedMaterial(
  desc: ImportedMaterialDescriptor,
  assetId: string,
  textureSlotByKey: Map<string, number>,
): PackedMaterialEntry {
  const slot =
    desc.textureId !== null
      ? (textureSlotByKey.get(`${assetId}:${desc.textureId}`) ?? -1)
      : -1;
  return {
    color: desc.color,
    roughness: Math.max(0.03, desc.roughness),
    metalness: desc.metalness,
    transmission: desc.transmission,
    ior: desc.ior,
    emissive: desc.emissive,
    textureSlot: slot,
    doubleSided: desc.doubleSided,
  };
}
