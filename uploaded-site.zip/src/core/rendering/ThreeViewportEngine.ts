import * as THREE from 'three';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { RectAreaLightUniformsLib } from 'three/addons/lights/RectAreaLightUniformsLib.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { BokehPass } from 'three/addons/postprocessing/BokehPass.js';
import { SSAOPass } from 'three/addons/postprocessing/SSAOPass.js';
import { AfterimagePass } from 'three/addons/postprocessing/AfterimagePass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { FXAAShader } from 'three/addons/shaders/FXAAShader.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

import type { ModelAssetRegistry } from '../assets/ModelAssetRegistry';
import { CameraController, type CameraMode } from '../camera/CameraController';
import type {
  CameraPoseState,
  CameraPreset,
  EngineMemoryStats,
  ExportImageOptions,
  IRenderEngine,
  RenderEngineDescriptor,
  TransformMode,
  ViewportCallbacks,
  ViewportSettings,
} from './IRenderEngine';
import {
  planExportMemoryBudget,
  probeDeviceGraphicsCapabilities,
} from './MemoryBudget';
import { DEFAULT_RENDER_SETTINGS, type RenderSettings } from './RenderSettings';
import {
  isLightNodeType,
  type NodeType,
  type SceneNode,
  type SceneSnapshot,
  type TransformData,
} from '../scene/SceneNode';

export const THREE_FOUNDATION_DESCRIPTOR: RenderEngineDescriptor = {
  id: 'three-webgl-foundation',
  name: 'Real-Time Renderer',
  version: '3.0.0',
  description:
    'Interactive PBR WebGL engine with real-time shadows, reflections, lights, and post-processing.',
  capabilities: {
    supportsShadows: true,
    supportsEnvironmentLighting: true,
    supportsTransformGizmo: true,
    supportsPostProcessing: true,
    supportsRayTracing: false,
    supportsSSGI: false,
  },
};

const ColorGradeShader = {
  uniforms: {
    tDiffuse: { value: null },
    uContrast: { value: 1.0 },
    uGamma: { value: 2.2 },
    uAoDarken: { value: 0.0 },
  },
  vertexShader: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform sampler2D tDiffuse;
    uniform float uContrast;
    uniform float uGamma;
    uniform float uAoDarken;
    varying vec2 vUv;
    void main() {
      vec4 tex = texture2D(tDiffuse, vUv);
      vec3 c = (tex.rgb - 0.5) * uContrast + 0.5;
      c = max(c, vec3(0.0));
      // Subtle screen-edge contact depth when AO is active in lightweight fallback
      float vignette = 1.0 - uAoDarken * smoothstep(0.35, 0.95, distance(vUv, vec2(0.5)));
      c *= vignette;
      c = pow(c, vec3(2.2 / max(uGamma, 0.1)));
      gl_FragColor = vec4(c, tex.a);
    }
  `,
};

function detectSoftwareWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) ?? '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export class ThreeViewportEngine implements IRenderEngine {
  readonly descriptor = THREE_FOUNDATION_DESCRIPTOR;

  private container: HTMLElement | null = null;
  private callbacks: ViewportCallbacks | null = null;

  private renderer: THREE.WebGLRenderer | null = null;
  private scene: THREE.Scene | null = null;
  private camera: THREE.PerspectiveCamera | null = null;
  private transformControls: TransformControls | null = null;
  private envTexture: THREE.Texture | null = null;
  private keyLight: THREE.DirectionalLight | null = null;
  private hemiLight: THREE.HemisphereLight | null = null;

  // Post-processing composer & passes (initialized lazily when needed)
  private composer: EffectComposer | null = null;
  private renderPass: RenderPass | null = null;
  private ssaoPass: SSAOPass | null = null;
  private bloomPass: UnrealBloomPass | null = null;
  private bokehPass: BokehPass | null = null;
  private afterimagePass: AfterimagePass | null = null;
  private colorGradePass: ShaderPass | null = null;
  private outputPass: OutputPass | null = null;
  private fxaaPass: ShaderPass | null = null;

  private readonly cameraController = new CameraController();
  private sceneRoot = new THREE.Group();
  private gridHelper: THREE.GridHelper | null = null;
  private axesHelper: THREE.AxesHelper | null = null;
  private selectionHelper: THREE.BoxHelper | null = null;
  private groundShadowDisc: THREE.Mesh | null = null;

  private objectMap = new Map<string, THREE.Object3D>();
  private assetRegistry: ModelAssetRegistry | null = null;
  private snapshot: SceneSnapshot = { nodes: [], selectedId: null };
  private renderSettings: RenderSettings = { ...DEFAULT_RENDER_SETTINGS };
  private viewportSettings: ViewportSettings = {
    showGrid: true,
    showAxes: true,
    snapToGrid: false,
    fov: 50,
  };
  private isSoftwareGl = false;
  private viewportSize = { width: 1, height: 1 };

  private renderBusy = false;
  private renderDirty = false;
  private paused = false;
  private frameId = 0;
  private lastTransitionTime = 0;
  private disposed = false;

  // Pointer & Multi-Touch state
  private activePointers = new Map<number, { x: number; y: number }>();
  private pointerDownPos = { x: 0, y: 0 };
  private pointerTravel = 0;
  private isDraggingGizmo = false;
  private prevPinchDist = 0;
  private prevPinchCenter = { x: 0, y: 0 };
  private raycaster = new THREE.Raycaster();
  private pointerVec = new THREE.Vector2();

  private cleanupListeners: Array<() => void> = [];

  mount(container: HTMLElement, callbacks: ViewportCallbacks): void {
    this.container = container;
    this.callbacks = callbacks;
    this.disposed = false;
    this.isSoftwareGl = detectSoftwareWebGL();

    const width = Math.max(container.clientWidth, 1);
    const height = Math.max(container.clientHeight, 1);
    this.viewportSize = { width, height };

    try {
      const renderer = new THREE.WebGLRenderer({
        antialias: !this.isSoftwareGl && this.renderSettings.antiAliasing === 'msaa',
        powerPreference: 'high-performance',
      });
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = this.renderSettings.exposure;
      renderer.shadowMap.enabled = !this.isSoftwareGl;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      renderer.domElement.style.display = 'block';
      renderer.domElement.style.width = '100%';
      renderer.domElement.style.height = '100%';
      renderer.domElement.style.touchAction = 'none';
      renderer.domElement.setAttribute('data-testid', 'dimensix-viewport-canvas');
      renderer.domElement.setAttribute('data-engine', this.descriptor.id);
      container.appendChild(renderer.domElement);
      this.renderer = renderer;

      RectAreaLightUniformsLib.init();

      const scene = new THREE.Scene();
      const bgHex = 0x0b0e17;
      scene.background = new THREE.Color(bgHex);
      scene.fog = new THREE.FogExp2(bgHex, 0.036);
      this.scene = scene;

      const pmremGenerator = new THREE.PMREMGenerator(renderer);
      const roomEnv = new RoomEnvironment();
      this.envTexture = pmremGenerator.fromScene(roomEnv, 0.04).texture;
      scene.environment = this.envTexture;
      roomEnv.dispose();
      pmremGenerator.dispose();

      const camera = new THREE.PerspectiveCamera(this.viewportSettings.fov, width / height, 0.1, 250);
      this.camera = camera;
      this.applyCameraPose();

      this.setupStudioLighting(scene);
      this.setupStudioFloor(scene);
      scene.add(this.sceneRoot);

      // TransformControls
      const gizmo = new TransformControls(camera, renderer.domElement);
      gizmo.setSize(0.85);
      scene.add(gizmo.getHelper());
      this.transformControls = gizmo;

      const onDraggingChanged = (event: { value: unknown }) => {
        this.isDraggingGizmo = Boolean(event.value);
        this.requestRender();
      };

      const onObjectChange = () => {
        const obj = gizmo.object;
        if (!obj || !obj.userData.nodeId) return;
        this.updateSelectionHelper();
        this.requestRender();
        const transform = this.extractTransform(obj);
        this.callbacks?.onNodeTransformPreview(String(obj.userData.nodeId), transform);
      };

      const onMouseUp = () => {
        const obj = gizmo.object;
        if (!obj || !obj.userData.nodeId) return;
        const transform = this.extractTransform(obj);
        this.callbacks?.onNodeTransformCommit(String(obj.userData.nodeId), transform);
      };

      gizmo.addEventListener('dragging-changed', onDraggingChanged);
      gizmo.addEventListener('objectChange', onObjectChange);
      gizmo.addEventListener('mouseUp', onMouseUp);

      // Unrestricted Camera Pointer & Multi-Touch Controls
      const dom = renderer.domElement;

      const onPointerDown = (e: PointerEvent) => {
        this.activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

        if (this.activePointers.size === 1) {
          this.pointerDownPos = { x: e.clientX, y: e.clientY };
          this.pointerTravel = 0;
        } else if (this.activePointers.size === 2) {
          const pts = Array.from(this.activePointers.values());
          this.prevPinchDist = Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y);
          this.prevPinchCenter = {
            x: (pts[0].x + pts[1].x) * 0.5,
            y: (pts[0].y + pts[1].y) * 0.5,
          };
        }
      };

      const onPointerMove = (e: PointerEvent) => {
        if (!this.activePointers.has(e.pointerId)) return;
        const prev = this.activePointers.get(e.pointerId)!;
        const dx = e.clientX - prev.x;
        const dy = e.clientY - prev.y;
        this.activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

        if (this.isDraggingGizmo || gizmo.dragging) return;

        if (this.activePointers.size === 1) {
          this.pointerTravel += Math.hypot(dx, dy);
          // Right click, middle click, or Shift+Drag pans; primary drag rotates freely with 0 pitch limits
          const isPanGesture = e.buttons === 2 || e.buttons === 4 || e.shiftKey;
          if (isPanGesture) {
            this.cameraController.pan(dx, dy);
          } else {
            this.cameraController.rotate(-dx * 0.0072, -dy * 0.0072);
          }
          this.applyCameraPose();
          this.requestRender();
        } else if (this.activePointers.size === 2) {
          const pts = Array.from(this.activePointers.values());
          const dist = Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y);
          const center = {
            x: (pts[0].x + pts[1].x) * 0.5,
            y: (pts[0].y + pts[1].y) * 0.5,
          };

          const panDx = center.x - this.prevPinchCenter.x;
          const panDy = center.y - this.prevPinchCenter.y;
          const pinchDelta = this.prevPinchDist - dist;

          this.cameraController.pan(panDx, panDy);
          if (Math.abs(pinchDelta) > 0.25) {
            this.cameraController.zoom(pinchDelta * 0.01);
          }

          this.prevPinchDist = dist;
          this.prevPinchCenter = center;
          this.applyCameraPose();
          this.requestRender();
        }
      };

      const onPointerUp = (e: PointerEvent) => {
        const wasSingle = this.activePointers.size === 1;
        this.activePointers.delete(e.pointerId);

        if (this.activePointers.size === 1) {
          const remaining = Array.from(this.activePointers.values())[0];
          this.pointerDownPos = { ...remaining };
          this.pointerTravel = 10; // Prevent accidental tap pick when lifting 2nd finger
        }

        if (
          wasSingle &&
          !this.isDraggingGizmo &&
          !gizmo.dragging &&
          e.button === 0 &&
          this.pointerTravel <= 6 &&
          Math.hypot(e.clientX - this.pointerDownPos.x, e.clientY - this.pointerDownPos.y) <= 6
        ) {
          this.pickAtPointer(e);
        }
      };

      const onWheel = (e: WheelEvent) => {
        e.preventDefault();
        this.cameraController.zoom(e.deltaY * 0.0012);
        this.applyCameraPose();
        this.requestRender();
      };

      const onContextMenu = (e: MouseEvent) => {
        e.preventDefault();
      };

      const onKeyDown = (e: KeyboardEvent) => {
        if (this.cameraController.getMode() !== 'free') return;
        const target = e.target as HTMLElement | null;
        if (
          target?.tagName === 'INPUT' ||
          target?.tagName === 'TEXTAREA' ||
          target?.tagName === 'SELECT'
        ) {
          return;
        }
        const step = 0.45;
        let moved = true;
        switch (e.key.toLowerCase()) {
          case 'w':
          case 'arrowup':
            this.cameraController.moveFree(step, 0, 0);
            break;
          case 's':
          case 'arrowdown':
            this.cameraController.moveFree(-step, 0, 0);
            break;
          case 'd':
          case 'arrowright':
            this.cameraController.moveFree(0, step, 0);
            break;
          case 'a':
          case 'arrowleft':
            this.cameraController.moveFree(0, -step, 0);
            break;
          case 'e':
            this.cameraController.moveFree(0, 0, step);
            break;
          case 'q':
            this.cameraController.moveFree(0, 0, -step);
            break;
          default:
            moved = false;
        }
        if (moved) {
          e.preventDefault();
          this.applyCameraPose();
          this.requestRender();
        }
      };

      const onContextLost = (e: Event) => {
        e.preventDefault();
        this.callbacks?.onEngineError?.('WebGL context lost. Attempting recovery.');
      };
      const onContextRestored = () => {
        this.requestRender();
      };

      dom.addEventListener('pointerdown', onPointerDown);
      window.addEventListener('pointermove', onPointerMove);
      window.addEventListener('pointerup', onPointerUp);
      window.addEventListener('pointercancel', onPointerUp);
      dom.addEventListener('wheel', onWheel, { passive: false });
      dom.addEventListener('contextmenu', onContextMenu);
      window.addEventListener('keydown', onKeyDown);
      dom.addEventListener('webglcontextlost', onContextLost);
      dom.addEventListener('webglcontextrestored', onContextRestored);

      this.cleanupListeners.push(() => {
        gizmo.removeEventListener('dragging-changed', onDraggingChanged);
        gizmo.removeEventListener('objectChange', onObjectChange);
        gizmo.removeEventListener('mouseUp', onMouseUp);
        dom.removeEventListener('pointerdown', onPointerDown);
        window.removeEventListener('pointermove', onPointerMove);
        window.removeEventListener('pointerup', onPointerUp);
        window.removeEventListener('pointercancel', onPointerUp);
        dom.removeEventListener('wheel', onWheel);
        dom.removeEventListener('contextmenu', onContextMenu);
        window.removeEventListener('keydown', onKeyDown);
        dom.removeEventListener('webglcontextlost', onContextLost);
        dom.removeEventListener('webglcontextrestored', onContextRestored);
      });

      this.applyRenderPipelineSettings();
      if (!this.isSoftwareGl) {
        renderer.compile(scene, camera);
      }

      this.syncScene(this.snapshot);
      this.requestRender();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to initialize WebGL viewport';
      this.callbacks?.onEngineError?.(message);
    }
  }

  unmount(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    window.clearTimeout(this.frameId);

    for (const cleanup of this.cleanupListeners) {
      cleanup();
    }
    this.cleanupListeners = [];
    this.activePointers.clear();

    this.transformControls?.detach();
    this.transformControls?.dispose();

    this.disposeComposer();
    this.disposeSceneObjects();

    if (this.selectionHelper) {
      this.selectionHelper.geometry.dispose();
      (this.selectionHelper.material as THREE.Material).dispose();
      this.selectionHelper = null;
    }

    if (this.groundShadowDisc) {
      this.groundShadowDisc.geometry.dispose();
      (this.groundShadowDisc.material as THREE.Material).dispose();
      this.groundShadowDisc = null;
    }

    this.envTexture?.dispose();
    this.envTexture = null;

    if (this.renderer) {
      this.renderer.domElement.remove();
      this.renderer.dispose();
      this.renderer = null;
    }

    this.scene = null;
    this.camera = null;
    this.transformControls = null;
    this.container = null;
    this.callbacks = null;
  }

  setAssetRegistry(registry: ModelAssetRegistry): void {
    this.assetRegistry = registry;
  }

  syncScene(snapshot: SceneSnapshot): void {
    this.snapshot = snapshot;
    if (!this.scene) return;

    const incomingIds = new Set(snapshot.nodes.map((n) => n.id));

    for (const [id, obj] of this.objectMap.entries()) {
      if (!incomingIds.has(id)) {
        if (this.transformControls?.object === obj) {
          this.transformControls.detach();
        }
        obj.parent?.remove(obj);
        this.disposeObjectResources(obj);
        this.objectMap.delete(id);
      }
    }

    for (const node of snapshot.nodes) {
      let obj = this.objectMap.get(node.id);
      const assetMismatch =
        node.type === 'model' && obj?.userData.assetId !== node.modelAsset?.assetId;
      if (!obj || obj.userData.nodeType !== node.type || assetMismatch) {
        if (obj) {
          obj.parent?.remove(obj);
          this.disposeObjectResources(obj);
        }
        obj = this.createObjectForNode(node);
        this.objectMap.set(node.id, obj);
      }
      this.applyNodeProps(obj, node);
    }

    for (const node of snapshot.nodes) {
      const obj = this.objectMap.get(node.id);
      if (!obj) continue;
      const targetParent: THREE.Object3D =
        node.parentId && this.objectMap.has(node.parentId)
          ? this.objectMap.get(node.parentId)!
          : this.sceneRoot;
      if (obj.parent !== targetParent) {
        targetParent.add(obj);
      }
    }

    this.balanceStudioFillLights(snapshot.nodes);
    this.setSelection(snapshot.selectedId);
    this.requestRender();
  }

  updateNode(node: SceneNode): void {
    const obj = this.objectMap.get(node.id);
    if (!obj) return;
    this.applyNodeProps(obj, node);
    const targetParent: THREE.Object3D =
      node.parentId && this.objectMap.has(node.parentId)
        ? this.objectMap.get(node.parentId)!
        : this.sceneRoot;
    if (obj.parent !== targetParent) {
      targetParent.add(obj);
    }
    this.updateSelectionHelper();
    this.requestRender();
  }

  setSelection(nodeId: string | null): void {
    if (!this.scene || !this.transformControls) return;

    if (!nodeId || !this.objectMap.has(nodeId)) {
      this.transformControls.detach();
      if (this.selectionHelper) {
        this.selectionHelper.visible = false;
      }
      this.requestRender();
      return;
    }

    const obj = this.objectMap.get(nodeId)!;
    if (obj.visible) {
      this.transformControls.attach(obj);
    } else {
      this.transformControls.detach();
    }

    if (!this.selectionHelper) {
      this.selectionHelper = new THREE.BoxHelper(obj, 0x22d3ee);
      (this.selectionHelper.material as THREE.LineBasicMaterial).depthTest = true;
      this.scene.add(this.selectionHelper);
    } else {
      this.selectionHelper.setFromObject(obj);
    }
    this.selectionHelper.visible = obj.visible;
    this.requestRender();
  }

  setTransformMode(mode: TransformMode): void {
    if (!this.transformControls) return;
    this.transformControls.setMode(mode);
    this.requestRender();
  }

  setViewportSettings(settings: ViewportSettings): void {
    this.viewportSettings = { ...settings };
    if (this.gridHelper) {
      this.gridHelper.visible = settings.showGrid;
    }
    if (this.axesHelper) {
      this.axesHelper.visible = settings.showAxes;
    }
    if (this.transformControls) {
      this.transformControls.translationSnap = settings.snapToGrid ? 0.25 : null;
      this.transformControls.rotationSnap = settings.snapToGrid
        ? THREE.MathUtils.degToRad(15)
        : null;
      this.transformControls.scaleSnap = settings.snapToGrid ? 0.1 : null;
    }
    if (this.camera && Math.abs(this.camera.fov - settings.fov) > 0.1) {
      this.camera.fov = settings.fov;
      this.camera.updateProjectionMatrix();
    }
    this.requestRender();
  }

  setRenderSettings(settings: RenderSettings): void {
    this.renderSettings = { ...settings };
    this.applyRenderPipelineSettings();
    this.requestRender();
  }

  setCameraMode(mode: CameraMode): void {
    this.cameraController.setMode(mode);
    this.applyCameraPose();
    this.requestRender();
  }

  setCameraPreset(preset: CameraPreset): void {
    this.cameraController.setPreset(preset, this.isSoftwareGl);
    this.lastTransitionTime = performance.now();
    this.applyCameraPose();
    this.requestRender();
  }

  moveCameraFree(forward: number, right: number, up: number): void {
    this.cameraController.moveFree(forward, right, up);
    this.applyCameraPose();
    this.requestRender();
  }

  resetCamera(): void {
    this.cameraController.reset(this.isSoftwareGl);
    this.lastTransitionTime = performance.now();
    this.applyCameraPose();
    this.requestRender();
  }

  focusSelected(): void {
    const targetObj = this.snapshot.selectedId
      ? this.objectMap.get(this.snapshot.selectedId)
      : null;

    const center = new THREE.Vector3(0, 0.5, 0);
    let radius = 1.6;
    if (targetObj) {
      targetObj.getWorldPosition(center);
      const box = new THREE.Box3().setFromObject(targetObj);
      const sphere = new THREE.Sphere();
      box.getBoundingSphere(sphere);
      if (Number.isFinite(sphere.radius) && sphere.radius > 0.1) {
        radius = sphere.radius;
      }
    }

    this.cameraController.focusOn(
      { x: center.x, y: center.y, z: center.z },
      radius,
      this.isSoftwareGl,
    );
    this.lastTransitionTime = performance.now();
    this.applyCameraPose();
    this.requestRender();
  }

  alignViewToNode(nodeId: string): void {
    const node = this.snapshot.nodes.find((n) => n.id === nodeId);
    const obj = this.objectMap.get(nodeId);
    if (!node || !obj) return;
    const worldPos = new THREE.Vector3();
    obj.getWorldPosition(worldPos);
    this.cameraController.alignToPose(
      { x: worldPos.x, y: worldPos.y, z: worldPos.z },
      node.transform.rotation,
    );
    if (node.camera && this.camera) {
      this.camera.fov = node.camera.fov;
      this.camera.near = node.camera.near;
      this.camera.far = node.camera.far;
      this.camera.updateProjectionMatrix();
    }
    this.applyCameraPose();
    this.requestRender();
  }

  getCameraState(): CameraPoseState {
    return this.cameraController.getState();
  }

  setCameraState(state: CameraPoseState): void {
    this.cameraController.setState(state);
    this.applyCameraPose();
    this.requestRender();
  }

  getMemoryStats(): EngineMemoryStats {
    return {
      bvhBytes: 0,
      textureBytes: this.assetRegistry?.getEstimatedMemoryBytes() ?? 0,
      triangleCount: this.countTriangles(),
    };
  }

  setPaused(paused: boolean): void {
    this.paused = paused;
    if (!paused) {
      this.requestRender();
    }
  }

  async exportImage(options: ExportImageOptions): Promise<Blob> {
    if (!this.renderer || !this.scene || !this.camera) {
      throw new Error('Real-Time renderer is not mounted.');
    }
    if (options.signal?.aborted) {
      throw new Error('Export cancelled.');
    }

    const targetW = Math.max(64, Math.round(options.width));
    const targetH = Math.max(64, Math.round(options.height));
    const caps = probeDeviceGraphicsCapabilities();
    const budget = planExportMemoryBudget(targetW, targetH, 1, caps, 'realtime');
    if (!budget.valid) {
      throw new Error(budget.reason || 'Export dimensions exceed Real-Time GPU budget.');
    }

    options.onProgress?.(0.15, 0, 1);

    const prevGrid = this.gridHelper?.visible ?? false;
    const prevAxes = this.axesHelper?.visible ?? false;
    const prevSel = this.selectionHelper?.visible ?? false;
    const gizmoHelper = this.transformControls?.getHelper();
    const prevGizmo = gizmoHelper?.visible ?? false;

    const toggledProxies: THREE.Object3D[] = [];
    this.sceneRoot.traverse((child) => {
      if (child.userData.isProxy && child.visible) {
        child.visible = false;
        toggledProxies.push(child);
      }
    });

    if (this.gridHelper) this.gridHelper.visible = false;
    if (this.axesHelper) this.axesHelper.visible = false;
    if (this.selectionHelper) this.selectionHelper.visible = false;
    if (gizmoHelper) gizmoHelper.visible = false;

    const prevAspect = this.camera.aspect;
    const prevPixelRatio = this.renderer.getPixelRatio();
    const prevSize = new THREE.Vector2();
    this.renderer.getSize(prevSize);
    const prevExposure = this.renderer.toneMappingExposure;

    try {
      this.renderer.toneMappingExposure = options.renderSettings.exposure;
      this.renderer.setPixelRatio(1);
      this.renderer.setSize(targetW, targetH, false);
      this.camera.aspect = targetW / targetH;
      this.camera.updateProjectionMatrix();

      if (this.shouldUseComposer() && this.composer) {
        this.composer.setPixelRatio(1);
        this.composer.setSize(targetW, targetH);
        this.composer.render();
      } else {
        this.renderer.render(this.scene, this.camera);
      }

      if (options.targetCanvas) {
        if (options.targetCanvas.width !== targetW || options.targetCanvas.height !== targetH) {
          options.targetCanvas.width = targetW;
          options.targetCanvas.height = targetH;
        }
        const ctx = options.targetCanvas.getContext('2d');
        ctx?.drawImage(this.renderer.domElement, 0, 0, targetW, targetH);
      }

      options.onProgress?.(0.85, 1, 1);

      const blob = await new Promise<Blob>((resolve, reject) => {
        const srcCanvas = options.targetCanvas ?? this.renderer!.domElement;
        srcCanvas.toBlob(
          (b) => (b ? resolve(b) : reject(new Error('Failed to encode PNG image.'))),
          'image/png',
        );
      });

      options.onProgress?.(1, 1, 1);
      return blob;
    } finally {
      for (const p of toggledProxies) p.visible = true;
      if (this.gridHelper) this.gridHelper.visible = prevGrid;
      if (this.axesHelper) this.axesHelper.visible = prevAxes;
      if (this.selectionHelper) this.selectionHelper.visible = prevSel;
      if (gizmoHelper) gizmoHelper.visible = prevGizmo;

      this.renderer.toneMappingExposure = prevExposure;
      this.renderer.setPixelRatio(prevPixelRatio);
      this.renderer.setSize(prevSize.x, prevSize.y, false);
      this.renderer.domElement.style.width = '100%';
      this.renderer.domElement.style.height = '100%';
      this.camera.aspect = prevAspect;
      this.camera.updateProjectionMatrix();
      this.applyResolutionAndScale();
      this.requestRender();
    }
  }

  resize(width: number, height: number): void {
    this.viewportSize = { width: Math.max(width, 1), height: Math.max(height, 1) };
    if (!this.renderer || !this.camera) return;
    this.applyResolutionAndScale();
    this.requestRender();
  }

  requestRender(): void {
    if (this.disposed || this.paused || !this.renderer || !this.scene || !this.camera) return;
    if (this.renderBusy) {
      this.renderDirty = true;
      return;
    }
    this.renderBusy = true;

    this.frameId = requestAnimationFrame(() => {
      if (this.disposed || !this.renderer || !this.scene || !this.camera) {
        this.renderBusy = false;
        return;
      }

      this.renderDirty = false;
      const now = performance.now();
      const dt = Math.min((now - (this.lastTransitionTime || now)) / 1000, 0.05);
      this.lastTransitionTime = now;

      const transitioning = this.cameraController.stepTransition(dt, this.isSoftwareGl);
      if (this.cameraController.hasActiveTransition() || transitioning) {
        this.applyCameraPose();
      }

      if (this.shouldUseComposer() && this.composer) {
        this.composer.render();
      } else {
        this.renderer.render(this.scene, this.camera);
      }

      const done = () => {
        this.renderBusy = false;
        if (this.renderDirty || transitioning) {
          this.requestRender();
        }
      };

      if (this.isSoftwareGl) {
        this.afterDraw(done);
      } else {
        done();
      }
    });
  }

  private applyCameraPose(): void {
    if (!this.camera) return;
    const pose = this.cameraController.getPose();
    this.camera.position.set(pose.position.x, pose.position.y, pose.position.z);
    this.camera.quaternion.set(
      pose.orientation.x,
      pose.orientation.y,
      pose.orientation.z,
      pose.orientation.w,
    );
    this.camera.up.set(pose.up.x, pose.up.y, pose.up.z);
    this.camera.updateMatrixWorld();

    if (this.renderer) {
      const dom = this.renderer.domElement;
      dom.dataset.cameraMode = pose.mode;
      dom.dataset.cameraPitchDeg = String(Math.round((pose.pitch * 180) / Math.PI));
      dom.dataset.cameraYawDeg = String(Math.round((pose.yaw * 180) / Math.PI));
    }
  }

  private shouldUseComposer(): boolean {
    const s = this.renderSettings;
    const perf = s.performanceMode;
    return (
      s.antiAliasing === 'fxaa' ||
      Math.abs(s.gamma - 2.2) > 0.01 ||
      Math.abs(s.contrast - 1.0) > 0.01 ||
      (s.bloomEnabled && !perf) ||
      (s.dofEnabled && !perf) ||
      (s.motionBlurEnabled && !perf) ||
      (s.ambientOcclusion && !perf)
    );
  }

  private applyRenderPipelineSettings(): void {
    if (!this.renderer || !this.scene || !this.camera) return;
    const s = this.renderSettings;

    // 1. Resolution, Render Scale & Pixel Ratio
    this.applyResolutionAndScale();

    // 2. Tone Mapping, Exposure & Render Quality
    if (s.renderQuality === 'draft') {
      this.renderer.toneMapping = THREE.LinearToneMapping;
    } else if (s.renderQuality === 'standard') {
      this.renderer.toneMapping = THREE.ReinhardToneMapping;
    } else {
      this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    }
    this.renderer.toneMappingExposure = s.exposure;

    // 3. Shadow Quality & Shadow Resolution
    const shadowsActive = !this.isSoftwareGl && s.shadowQuality !== 'off' && !s.performanceMode;
    this.renderer.shadowMap.enabled = shadowsActive;
    if (s.shadowQuality === 'low') {
      this.renderer.shadowMap.type = THREE.BasicShadowMap;
    } else if (s.shadowQuality === 'medium') {
      this.renderer.shadowMap.type = THREE.PCFShadowMap;
    } else {
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    }

    if (this.keyLight) {
      this.keyLight.castShadow = shadowsActive;
      this.keyLight.shadow.radius =
        s.shadowQuality === 'high' ? 4 : s.shadowQuality === 'medium' ? 2 : 1;
      if (
        this.keyLight.shadow.mapSize.width !== s.shadowResolution ||
        this.keyLight.shadow.mapSize.height !== s.shadowResolution
      ) {
        this.keyLight.shadow.mapSize.set(s.shadowResolution, s.shadowResolution);
        this.keyLight.shadow.map?.dispose();
        this.keyLight.shadow.map = null;
      }
    }

    // 4. Texture Quality & Environment Intensity
    this.scene.environmentIntensity =
      s.textureQuality === 'low' ? 0.65 : s.textureQuality === 'medium' ? 0.85 : 1.0;

    // 5. Ambient Occlusion contrast grounding
    if (this.hemiLight) {
      this.hemiLight.intensity = s.ambientOcclusion ? 0.58 : 0.75;
    }

    // 6. Post-Processing Composer
    if (this.shouldUseComposer()) {
      this.ensureComposerPasses();
      if (this.ssaoPass) {
        this.ssaoPass.enabled = s.ambientOcclusion && !s.performanceMode && !this.isSoftwareGl;
      }
      if (this.bloomPass) {
        this.bloomPass.enabled = s.bloomEnabled && !s.performanceMode;
        this.bloomPass.strength = s.bloomIntensity;
      }
      if (this.bokehPass) {
        this.bokehPass.enabled = s.dofEnabled && !s.performanceMode;
        const uniforms = this.bokehPass.uniforms as Record<string, THREE.IUniform>;
        if (uniforms.focus) uniforms.focus.value = s.dofFocusDistance;
        if (uniforms.aperture) uniforms.aperture.value = s.dofAperture * 0.001;
      }
      if (this.afterimagePass) {
        this.afterimagePass.enabled = s.motionBlurEnabled && !s.performanceMode;
        this.afterimagePass.damp = s.motionBlurAmount;
      }
      if (this.colorGradePass) {
        this.colorGradePass.uniforms.uContrast.value = s.contrast;
        this.colorGradePass.uniforms.uGamma.value = s.gamma;
        this.colorGradePass.uniforms.uAoDarken.value =
          s.ambientOcclusion && (s.performanceMode || this.isSoftwareGl) ? 0.35 : 0.0;
      }
      if (this.fxaaPass) {
        this.fxaaPass.enabled = s.antiAliasing === 'fxaa';
      }
    }

    const dom = this.renderer.domElement;
    dom.dataset.renderScale = String(s.renderScale);
    dom.dataset.exposure = String(s.exposure);
    dom.dataset.gamma = String(s.gamma);
    dom.dataset.contrast = String(s.contrast);
    dom.dataset.bloom = String(s.bloomEnabled);
    dom.dataset.ao = String(s.ambientOcclusion);
    dom.dataset.shadowRes = String(s.shadowResolution);
    dom.dataset.perfMode = String(s.performanceMode);
  }

  private applyResolutionAndScale(): void {
    if (!this.renderer || !this.camera) return;
    const s = this.renderSettings;
    const { width, height } = this.viewportSize;
    const aspect = width / Math.max(height, 1);

    let targetW = width;
    let targetH = height;

    if (s.resolution !== 'native') {
      const capH = s.resolution === '720p' ? 720 : s.resolution === '1080p' ? 1080 : 1440;
      if (height > capH || width > capH * aspect) {
        targetH = capH;
        targetW = Math.round(capH * aspect);
      }
    }

    const previewFactor =
      s.previewQuality === 'low' ? 0.72 : s.previewQuality === 'medium' ? 0.88 : 1.0;
    const perfFactor = s.performanceMode ? 0.75 : 1.0;

    const baseRatio = this.isSoftwareGl
      ? 1.0
      : Math.min(window.devicePixelRatio || 1, s.pixelRatio);

    const effectiveRatio = THREE.MathUtils.clamp(
      baseRatio * s.renderScale * previewFactor * perfFactor,
      0.4,
      this.isSoftwareGl ? 1.25 : 2.5,
    );

    this.camera.aspect = aspect;
    this.camera.updateProjectionMatrix();

    this.renderer.setPixelRatio(effectiveRatio);
    this.renderer.setSize(targetW, targetH, false);
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';

    if (this.composer) {
      this.composer.setPixelRatio(effectiveRatio);
      this.composer.setSize(targetW, targetH);
      if (this.fxaaPass) {
        this.fxaaPass.material.uniforms.resolution.value.set(
          1 / Math.max(targetW * effectiveRatio, 1),
          1 / Math.max(targetH * effectiveRatio, 1),
        );
      }
      if (this.bloomPass) {
        this.bloomPass.resolution.set(targetW, targetH);
      }
    }
  }

  private ensureComposerPasses(): void {
    if (this.composer || !this.renderer || !this.scene || !this.camera) return;

    const { width, height } = this.viewportSize;
    const composer = new EffectComposer(this.renderer);

    const renderPass = new RenderPass(this.scene, this.camera);
    composer.addPass(renderPass);
    this.renderPass = renderPass;

    if (!this.isSoftwareGl) {
      const ssao = new SSAOPass(this.scene, this.camera, width, height);
      ssao.kernelRadius = 10;
      ssao.minDistance = 0.005;
      ssao.maxDistance = 0.12;
      ssao.enabled = false;
      composer.addPass(ssao);
      this.ssaoPass = ssao;
    }

    const bloom = new UnrealBloomPass(new THREE.Vector2(width, height), 0.55, 0.45, 0.72);
    bloom.enabled = false;
    composer.addPass(bloom);
    this.bloomPass = bloom;

    const bokeh = new BokehPass(this.scene, this.camera, {
      focus: 8.0,
      aperture: 0.00001,
      maxblur: 0.012,
    });
    bokeh.enabled = false;
    composer.addPass(bokeh);
    this.bokehPass = bokeh;

    const afterimage = new AfterimagePass(0.45);
    afterimage.enabled = false;
    composer.addPass(afterimage);
    this.afterimagePass = afterimage;

    const output = new OutputPass();
    composer.addPass(output);
    this.outputPass = output;

    const colorGrade = new ShaderPass(ColorGradeShader);
    composer.addPass(colorGrade);
    this.colorGradePass = colorGrade;

    const fxaa = new ShaderPass(FXAAShader);
    fxaa.enabled = false;
    composer.addPass(fxaa);
    this.fxaaPass = fxaa;

    this.composer = composer;
    this.applyResolutionAndScale();
  }

  private disposeComposer(): void {
    this.ssaoPass?.dipose?.();
    this.composer?.dispose();
    this.composer = null;
    this.renderPass = null;
    this.ssaoPass = null;
    this.bloomPass = null;
    this.bokehPass = null;
    this.afterimagePass = null;
    this.colorGradePass = null;
    this.outputPass = null;
    this.fxaaPass = null;
  }

  private afterDraw(cb: () => void): void {
    if (!this.renderer) {
      cb();
      return;
    }
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync ? gl.getSyncParameter(sync, gl.SYNC_STATUS) : gl.SIGNALED;
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private setupStudioLighting(scene: THREE.Scene): void {
    const hemi = new THREE.HemisphereLight(0xa5b4fc, 0x1e1b4b, 0.75);
    this.hemiLight = hemi;
    scene.add(hemi);

    const keyLight = new THREE.DirectionalLight(0xfff5e4, 1.6);
    keyLight.position.set(6, 9, 5);
    if (!this.isSoftwareGl) {
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.set(1024, 1024);
      keyLight.shadow.camera.left = -8;
      keyLight.shadow.camera.right = 8;
      keyLight.shadow.camera.top = 8;
      keyLight.shadow.camera.bottom = -8;
      keyLight.shadow.camera.near = 0.5;
      keyLight.shadow.camera.far = 30;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    this.keyLight = keyLight;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 0.65);
    rimLight.position.set(-6, 4, -6);
    scene.add(rimLight);
  }

  private setupStudioFloor(scene: THREE.Scene): void {
    const grid = new THREE.GridHelper(24, 24, 0x38bdf8, 0x1e293b);
    grid.position.y = 0.002;
    const gridMat = grid.material as THREE.Material | THREE.Material[];
    if (Array.isArray(gridMat)) {
      gridMat.forEach((m) => {
        m.transparent = true;
        m.opacity = 0.48;
      });
    } else {
      gridMat.transparent = true;
      gridMat.opacity = 0.48;
    }
    this.gridHelper = grid;
    scene.add(grid);

    const axes = new THREE.AxesHelper(1.5);
    axes.position.y = 0.01;
    this.axesHelper = axes;
    scene.add(axes);

    const discGeo = new THREE.CircleGeometry(42, 48);
    discGeo.rotateX(-Math.PI / 2);
    const discMat = new THREE.MeshStandardMaterial({
      color: 0x0f1422,
      roughness: 0.92,
      metalness: 0.05,
    });
    const disc = new THREE.Mesh(discGeo, discMat);
    disc.position.y = -0.005;
    disc.receiveShadow = !this.isSoftwareGl;
    this.groundShadowDisc = disc;
    scene.add(disc);
  }

  private balanceStudioFillLights(nodes: SceneNode[]): void {
    const hasUserLights = nodes.some((n) => n.visible && isLightNodeType(n.type));
    if (this.hemiLight) {
      const aoScale = this.renderSettings.ambientOcclusion ? 0.8 : 1.0;
      this.hemiLight.intensity = (hasUserLights ? 0.36 : 0.72) * aoScale;
    }
    if (this.keyLight) {
      this.keyLight.intensity = hasUserLights ? 0.45 : 1.55;
    }
  }

  private countTriangles(): number {
    let total = 0;
    this.sceneRoot.traverse((child) => {
      if ((child as THREE.Mesh).isMesh && !child.userData.isProxy) {
        const g = (child as THREE.Mesh).geometry;
        if (!g) return;
        const idx = g.getIndex();
        const pos = g.getAttribute('position');
        total += idx ? Math.floor(idx.count / 3) : pos ? Math.floor(pos.count / 3) : 0;
      }
    });
    return total;
  }

  private createObjectForNode(node: SceneNode): THREE.Object3D {
    let obj: THREE.Object3D;

    if (node.type === 'group') {
      obj = new THREE.Group();
    } else if (node.type === 'pointLight') {
      const group = new THREE.Group();
      const light = new THREE.PointLight(
        node.light?.color ?? '#FDE047',
        node.light?.intensity ?? 8,
        node.light?.distance ?? 18,
        2,
      );
      light.castShadow = !this.isSoftwareGl && (node.light?.castShadow ?? true);
      group.add(light);

      const bulb = new THREE.Mesh(
        new THREE.SphereGeometry(0.11, 14, 10),
        new THREE.MeshStandardMaterial({
          color: node.light?.color ?? '#FDE047',
          emissive: node.light?.color ?? '#FDE047',
          emissiveIntensity: 1.4,
          roughness: 0.2,
        }),
      );
      bulb.userData.nodeId = node.id;
      bulb.userData.isProxy = true;
      group.add(bulb);

      const cage = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.24, 0),
        new THREE.MeshBasicMaterial({
          color: node.light?.color ?? '#FDE047',
          wireframe: true,
          transparent: true,
          opacity: 0.65,
        }),
      );
      cage.userData.nodeId = node.id;
      cage.userData.isProxy = true;
      group.add(cage);

      obj = group;
    } else if (node.type === 'directionalLight') {
      const group = new THREE.Group();
      const light = new THREE.DirectionalLight(
        node.light?.color ?? '#FFF3C4',
        node.light?.intensity ?? 2.2,
      );
      light.castShadow = !this.isSoftwareGl && (node.light?.castShadow ?? true);
      light.shadow.mapSize.set(1024, 1024);
      light.shadow.camera.left = -8;
      light.shadow.camera.right = 8;
      light.shadow.camera.top = 8;
      light.shadow.camera.bottom = -8;
      light.shadow.bias = -0.0005;
      light.target.position.set(0, 0, -1);
      group.add(light);
      group.add(light.target);

      const sunCore = new THREE.Mesh(
        new THREE.SphereGeometry(0.16, 14, 10),
        new THREE.MeshBasicMaterial({ color: node.light?.color ?? '#FFF3C4' }),
      );
      sunCore.userData.nodeId = node.id;
      sunCore.userData.isProxy = true;
      group.add(sunCore);

      const rayPts = new Float32Array([0, 0, 0, 0, 0, -0.9]);
      const rayGeo = new THREE.BufferGeometry();
      rayGeo.setAttribute('position', new THREE.BufferAttribute(rayPts, 3));
      const rayLine = new THREE.LineSegments(
        rayGeo,
        new THREE.LineBasicMaterial({ color: node.light?.color ?? '#FFF3C4' }),
      );
      rayLine.userData.isProxy = true;
      group.add(rayLine);

      obj = group;
    } else if (node.type === 'spotLight') {
      const group = new THREE.Group();
      const light = new THREE.SpotLight(
        node.light?.color ?? '#38BDF8',
        node.light?.intensity ?? 14,
        node.light?.distance ?? 24,
        THREE.MathUtils.degToRad(node.light?.angle ?? 32),
        node.light?.penumbra ?? 0.45,
        2,
      );
      light.castShadow = !this.isSoftwareGl && (node.light?.castShadow ?? true);
      light.shadow.mapSize.set(1024, 1024);
      light.shadow.bias = -0.0004;
      light.target.position.set(0, 0, -1);
      group.add(light);
      group.add(light.target);

      const housing = new THREE.Mesh(
        new THREE.ConeGeometry(0.18, 0.34, 16),
        new THREE.MeshBasicMaterial({
          color: node.light?.color ?? '#38BDF8',
          wireframe: true,
        }),
      );
      housing.rotation.x = Math.PI / 2;
      housing.userData.nodeId = node.id;
      housing.userData.isProxy = true;
      group.add(housing);

      obj = group;
    } else if (node.type === 'areaLight') {
      const group = new THREE.Group();
      const w = node.light?.width ?? 2.4;
      const h = node.light?.height ?? 1.6;
      const light = new THREE.RectAreaLight(
        node.light?.color ?? '#F8FAFC',
        node.light?.intensity ?? 6.5,
        w,
        h,
      );
      group.add(light);

      const panelGeo = new THREE.PlaneGeometry(1, 1);
      const panel = new THREE.Mesh(
        panelGeo,
        new THREE.MeshBasicMaterial({
          color: node.light?.color ?? '#F8FAFC',
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.14,
          depthWrite: false,
        }),
      );
      panel.name = 'areaLightPanelProxy';
      panel.scale.set(w, h, 1);
      panel.userData.nodeId = node.id;
      panel.userData.isProxy = true;
      group.add(panel);

      const border = new THREE.LineSegments(
        new THREE.EdgesGeometry(panelGeo),
        new THREE.LineBasicMaterial({
          color: node.light?.color ?? '#F8FAFC',
          transparent: true,
          opacity: 0.72,
        }),
      );
      border.name = 'areaLightBorderProxy';
      border.scale.set(w, h, 1);
      group.add(border);

      obj = group;
    } else if (node.type === 'camera') {
      const group = new THREE.Group();

      const bodyMat = new THREE.MeshStandardMaterial({
        color: '#1E293B',
        roughness: 0.45,
        metalness: 0.55,
      });
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.26, 0.52), bodyMat);
      body.userData.nodeId = node.id;
      body.userData.isProxy = true;
      group.add(body);

      const lensMat = new THREE.MeshStandardMaterial({
        color: '#38BDF8',
        roughness: 0.2,
        metalness: 0.85,
      });
      const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.13, 0.22, 18), lensMat);
      lens.rotation.x = Math.PI / 2;
      lens.position.set(0, 0, -0.34);
      lens.userData.nodeId = node.id;
      lens.userData.isProxy = true;
      group.add(lens);

      const finder = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.1, 0.2), bodyMat);
      finder.position.set(0, 0.18, 0.04);
      finder.userData.nodeId = node.id;
      finder.userData.isProxy = true;
      group.add(finder);

      const frustumPts = new Float32Array([
        0, 0, -0.42, -0.32, 0.2, -0.95,
        0, 0, -0.42, 0.32, 0.2, -0.95,
        0, 0, -0.42, 0.32, -0.2, -0.95,
        0, 0, -0.42, -0.32, -0.2, -0.95,
        -0.32, 0.2, -0.95, 0.32, 0.2, -0.95,
        0.32, 0.2, -0.95, 0.32, -0.2, -0.95,
        0.32, -0.2, -0.95, -0.32, -0.2, -0.95,
        -0.32, -0.2, -0.95, -0.32, 0.2, -0.95,
      ]);
      const frustumGeo = new THREE.BufferGeometry();
      frustumGeo.setAttribute('position', new THREE.BufferAttribute(frustumPts, 3));
      const frustum = new THREE.LineSegments(
        frustumGeo,
        new THREE.LineBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.65 }),
      );
      frustum.userData.isProxy = true;
      group.add(frustum);

      obj = group;
    } else if (node.type === 'model') {
      const assetGroup =
        node.modelAsset && this.assetRegistry
          ? this.assetRegistry.instantiateThreeGroup(node.modelAsset.assetId)
          : null;
      if (assetGroup) {
        assetGroup.traverse((child) => {
          child.userData.nodeId = node.id;
          child.userData.sharedAssetResource = true;
          if ((child as THREE.Mesh).isMesh) {
            const m = child as THREE.Mesh;
            m.castShadow = !this.isSoftwareGl;
            m.receiveShadow = !this.isSoftwareGl;
          }
        });
        obj = assetGroup;
        obj.userData.assetId = node.modelAsset?.assetId;
      } else {
        obj = new THREE.Group();
      }
    } else {
      const geometry = this.createGeometry(node.type);
      const material = new THREE.MeshPhysicalMaterial({
        color: node.material?.color ?? '#8B5CF6',
        roughness: node.material?.roughness ?? 0.38,
        metalness: node.material?.metalness ?? 0.22,
        transmission: node.material?.transmission ?? 0,
        ior: node.material?.ior ?? 1.5,
        thickness: 0.5,
        emissive: node.material?.emissive ?? '#000000',
        emissiveIntensity: node.material?.emissiveIntensity ?? 0,
        wireframe: node.material?.wireframe ?? false,
        side: node.type === 'plane' ? THREE.DoubleSide : THREE.FrontSide,
      });
      const mesh = new THREE.Mesh(geometry, material);
      mesh.castShadow = !this.isSoftwareGl && node.type !== 'plane';
      mesh.receiveShadow = !this.isSoftwareGl;
      obj = mesh;
    }

    obj.userData.nodeId = node.id;
    obj.userData.nodeType = node.type;
    return obj;
  }

  private createGeometry(
    type: Exclude<
      NodeType,
      'group' | 'camera' | 'model' | 'pointLight' | 'directionalLight' | 'spotLight' | 'areaLight'
    >,
  ): THREE.BufferGeometry {
    switch (type) {
      case 'box':
        return new THREE.BoxGeometry(1, 1, 1);
      case 'sphere':
        return new THREE.SphereGeometry(0.55, 28, 20);
      case 'cylinder':
        return new THREE.CylinderGeometry(0.5, 0.5, 1, 28);
      case 'cone':
        return new THREE.ConeGeometry(0.55, 1.1, 28);
      case 'torus':
        return new THREE.TorusGeometry(0.5, 0.18, 16, 36);
      case 'plane':
        return new THREE.PlaneGeometry(1, 1);
    }
  }

  private applyNodeProps(obj: THREE.Object3D, node: SceneNode): void {
    obj.name = node.name;
    obj.visible = node.visible;
    obj.position.set(node.transform.position.x, node.transform.position.y, node.transform.position.z);
    obj.rotation.set(
      THREE.MathUtils.degToRad(node.transform.rotation.x),
      THREE.MathUtils.degToRad(node.transform.rotation.y),
      THREE.MathUtils.degToRad(node.transform.rotation.z),
    );
    obj.scale.set(node.transform.scale.x, node.transform.scale.y, node.transform.scale.z);

    if (isLightNodeType(node.type) && node.light) {
      for (const child of obj.children) {
        if ((child as THREE.PointLight).isPointLight) {
          const light = child as THREE.PointLight;
          light.color.set(node.light.color);
          light.intensity = node.light.intensity;
          light.distance = node.light.distance;
          light.castShadow = !this.isSoftwareGl && (node.light.castShadow ?? true);
        } else if ((child as THREE.DirectionalLight).isDirectionalLight) {
          const light = child as THREE.DirectionalLight;
          light.color.set(node.light.color);
          light.intensity = node.light.intensity;
          light.castShadow = !this.isSoftwareGl && (node.light.castShadow ?? true);
        } else if ((child as THREE.SpotLight).isSpotLight) {
          const light = child as THREE.SpotLight;
          light.color.set(node.light.color);
          light.intensity = node.light.intensity;
          light.distance = node.light.distance;
          light.angle = THREE.MathUtils.degToRad(node.light.angle ?? 32);
          light.penumbra = node.light.penumbra ?? 0.45;
          light.castShadow = !this.isSoftwareGl && (node.light.castShadow ?? true);
        } else if ((child as THREE.RectAreaLight).isRectAreaLight) {
          const light = child as THREE.RectAreaLight;
          light.color.set(node.light.color);
          light.intensity = node.light.intensity;
          light.width = node.light.width ?? 2.4;
          light.height = node.light.height ?? 1.6;
        } else if ((child as THREE.Mesh).isMesh) {
          const mesh = child as THREE.Mesh;
          if (mesh.name === 'areaLightPanelProxy') {
            mesh.scale.set(node.light.width ?? 2.4, node.light.height ?? 1.6, 1);
          }
          const mat = mesh.material;
          if (mat && !Array.isArray(mat)) {
            if ('color' in mat && mat.color instanceof THREE.Color) {
              mat.color.set(node.light.color);
            }
            if ('emissive' in mat && mat.emissive instanceof THREE.Color) {
              mat.emissive.set(node.light.color);
            }
          }
        } else if ((child as THREE.LineSegments).isLineSegments) {
          const lineSeg = child as THREE.LineSegments;
          if (lineSeg.name === 'areaLightBorderProxy') {
            lineSeg.scale.set(node.light.width ?? 2.4, node.light.height ?? 1.6, 1);
          }
          const mat = lineSeg.material;
          if (mat && !Array.isArray(mat) && 'color' in mat && mat.color instanceof THREE.Color) {
            mat.color.set(node.light.color);
          }
        }
      }
    } else if (node.material && (obj as THREE.Mesh).isMesh) {
      const mesh = obj as THREE.Mesh;
      const mat = mesh.material as THREE.MeshPhysicalMaterial;
      mat.color.set(node.material.color);
      mat.roughness = node.material.roughness;
      mat.metalness = node.material.metalness;
      mat.transmission = node.material.transmission ?? 0;
      mat.ior = node.material.ior ?? 1.5;
      if (mat.emissive instanceof THREE.Color) {
        mat.emissive.set(node.material.emissive ?? '#000000');
      }
      mat.emissiveIntensity = node.material.emissiveIntensity ?? 0;
      mat.wireframe = node.material.wireframe;
    }
  }

  private extractTransform(obj: THREE.Object3D): TransformData {
    return {
      position: {
        x: round3(obj.position.x),
        y: round3(obj.position.y),
        z: round3(obj.position.z),
      },
      rotation: {
        x: round3(THREE.MathUtils.radToDeg(obj.rotation.x)),
        y: round3(THREE.MathUtils.radToDeg(obj.rotation.y)),
        z: round3(THREE.MathUtils.radToDeg(obj.rotation.z)),
      },
      scale: {
        x: round3(obj.scale.x),
        y: round3(obj.scale.y),
        z: round3(obj.scale.z),
      },
    };
  }

  private pickAtPointer(event: PointerEvent): void {
    if (!this.renderer || !this.camera) return;
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointerVec.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.pointerVec.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.pointerVec, this.camera);
    const pickables: THREE.Object3D[] = [];
    for (const obj of this.objectMap.values()) {
      if (obj.visible) pickables.push(obj);
    }

    const hits = this.raycaster.intersectObjects(pickables, true);
    if (hits.length === 0) {
      this.callbacks?.onNodeSelected(null);
      return;
    }

    let current: THREE.Object3D | null = hits[0].object;
    while (current && !current.userData.nodeId) {
      current = current.parent;
    }

    const hitNodeId = current?.userData.nodeId ? String(current.userData.nodeId) : null;
    this.callbacks?.onNodeSelected(hitNodeId);
  }

  private updateSelectionHelper(): void {
    if (!this.selectionHelper) return;
    const selectedId = this.snapshot.selectedId;
    if (!selectedId || !this.objectMap.has(selectedId)) {
      this.selectionHelper.visible = false;
      return;
    }
    const obj = this.objectMap.get(selectedId)!;
    this.selectionHelper.setFromObject(obj);
    this.selectionHelper.visible = obj.visible;
  }

  private disposeSceneObjects(): void {
    for (const obj of this.objectMap.values()) {
      this.disposeObjectResources(obj);
    }
    this.objectMap.clear();
    this.sceneRoot.clear();
  }

  private disposeObjectResources(root: THREE.Object3D): void {
    root.traverse((child) => {
      if (child.userData.sharedAssetResource) return;
      if ((child as THREE.Mesh).isMesh || (child as THREE.LineSegments).isLineSegments) {
        const renderable = child as THREE.Mesh | THREE.LineSegments;
        renderable.geometry?.dispose();
        if (Array.isArray(renderable.material)) {
          renderable.material.forEach((m) => m.dispose());
        } else {
          renderable.material?.dispose();
        }
      }
    });
  }
}

function round3(value: number): number {
  return Math.round(value * 1000) / 1000;
}
