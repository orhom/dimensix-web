import type { ModelAssetRegistry } from '../assets/ModelAssetRegistry';
import type { CameraMode } from '../camera/CameraController';
import type { SceneNode, SceneSnapshot, TransformData } from '../scene/SceneNode';
import type { RenderSettings } from './RenderSettings';
import type {
  ExportPauseController,
  TiledExportProgressEvent,
  TileOutputUpdate,
} from './TiledPathTracingExportSession';

export type TransformMode = 'translate' | 'rotate' | 'scale';

export type CameraPreset = 'perspective' | 'top' | 'front' | 'side';

export interface CameraPoseState {
  mode: CameraMode;
  target: { x: number; y: number; z: number };
  yaw: number;
  pitch: number;
  distance: number;
}

export interface PathTracerStatus {
  mode: 'idle' | 'interactive' | 'converging' | 'exporting';
  samples: number;
  targetSamples: number;
  sampleCap: number;
  resolutionScale: number;
  triangleCount: number;
  bvhMemoryBytes: number;
}

export interface EngineMemoryStats {
  bvhBytes: number;
  textureBytes: number;
  triangleCount: number;
}

export interface ExportImageOptions {
  width: number;
  height: number;
  samples: number;
  renderSettings: RenderSettings;
  targetCanvas?: HTMLCanvasElement;
  onTileOutput?: (tile: TileOutputUpdate) => void;
  onTiledProgress?: (event: TiledExportProgressEvent) => void;
  onProgress?: (progress01: number, currentSample: number, totalSamples: number) => void;
  pauseController?: ExportPauseController;
  signal?: AbortSignal;
}

export interface RenderEngineCapabilities {
  supportsShadows: boolean;
  supportsEnvironmentLighting: boolean;
  supportsTransformGizmo: boolean;
  supportsPostProcessing: boolean;
  supportsRayTracing: boolean;
  supportsSSGI: boolean;
}

export interface RenderEngineDescriptor {
  id: string;
  name: string;
  version: string;
  description: string;
  capabilities: RenderEngineCapabilities;
}

export interface ViewportSettings {
  showGrid: boolean;
  showAxes: boolean;
  snapToGrid: boolean;
  fov: number;
}

export interface ViewportCallbacks {
  onNodeSelected: (nodeId: string | null) => void;
  onNodeTransformPreview: (nodeId: string, transform: TransformData) => void;
  onNodeTransformCommit: (nodeId: string, transform: TransformData) => void;
  onPathTracerStatus?: (status: PathTracerStatus) => void;
  onEngineError?: (message: string) => void;
}

/**
 * Abstraction layer for any 3D viewport rendering backend
 * (Real-Time Three.js WebGL and Progressive GLSL3 Path Tracing).
 */
export interface IRenderEngine {
  readonly descriptor: RenderEngineDescriptor;

  mount(container: HTMLElement, callbacks: ViewportCallbacks): void;
  unmount(): void;

  setAssetRegistry(registry: ModelAssetRegistry): void;
  syncScene(snapshot: SceneSnapshot): void;
  updateNode(node: SceneNode): void;
  setSelection(nodeId: string | null): void;

  setTransformMode(mode: TransformMode): void;
  setViewportSettings(settings: ViewportSettings): void;
  setRenderSettings(settings: RenderSettings): void;

  setCameraMode(mode: CameraMode): void;
  setCameraPreset(preset: CameraPreset): void;
  moveCameraFree(forward: number, right: number, up: number): void;
  resetCamera(): void;
  focusSelected(): void;
  alignViewToNode(nodeId: string): void;
  getCameraState(): CameraPoseState;
  setCameraState(state: CameraPoseState): void;

  resize(width: number, height: number): void;
  requestRender(): void;
  setPaused?(paused: boolean): void;
  getMemoryStats(): EngineMemoryStats;

  /**
   * Renders a clean, gizmo-free offscreen image at target resolution and returns a PNG Blob.
   */
  exportImage(options: ExportImageOptions): Promise<Blob>;
}
