import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildCenterFirstTiles,
  buildProgressiveSampleSchedule,
  planExportMemoryBudget,
  type DeviceGraphicsCapabilities,
} from './MemoryBudget';

const DESKTOP_CAPS: DeviceGraphicsCapabilities = {
  maxTextureSize: 16384,
  maxRenderbufferSize: 16384,
  supportsWebGL2: true,
  supportsColorBufferFloat: true,
  supportsColorBufferHalfFloat: true,
  isSoftwareGl: false,
  deviceMemoryGb: 8,
};

const MOBILE_CONSTRAINED_CAPS: DeviceGraphicsCapabilities = {
  maxTextureSize: 4096,
  maxRenderbufferSize: 4096,
  supportsWebGL2: true,
  supportsColorBufferFloat: true,
  supportsColorBufferHalfFloat: true,
  isSoftwareGl: true,
  deviceMemoryGb: 2,
};

test('512x512 and 1920x1080 use full-progressive with bounded tiny GPU tile VRAM', () => {
  const plan512 = planExportMemoryBudget(512, 512, 1024, DESKTOP_CAPS, 'pathtracer');
  assert.equal(plan512.valid, true);
  assert.equal(plan512.strategy, 'full-progressive');
  assert.ok(plan512.gpuTileVramBytes <= 1024 * 1024, 'GPU VRAM must stay <= 1MB per tile');
  assert.equal(
    plan512.sampleBatches.reduce((a, b) => a + b, 0),
    1024,
  );
  assert.equal(plan512.sampleBatches[0], 1);

  const plan1080 = planExportMemoryBudget(1920, 1080, 128, DESKTOP_CAPS, 'pathtracer');
  assert.equal(plan1080.valid, true);
  assert.equal(plan1080.strategy, 'full-progressive');
  assert.equal(
    plan1080.sampleBatches.reduce((a, b) => a + b, 0),
    128,
  );
});

test('3840x2160 on constrained mobile switches to tile-streaming with < 256KB HDR worker RAM', () => {
  const plan4k = planExportMemoryBudget(3840, 2160, 64, MOBILE_CONSTRAINED_CAPS, 'pathtracer');
  assert.equal(plan4k.valid, true);
  assert.equal(plan4k.strategy, 'tile-streaming');
  assert.ok(plan4k.workerHdrBytes <= 128 * 128 * 16);
  assert.ok(plan4k.gpuTileVramBytes <= 128 * 128 * 40);
});

test('CPU fallback triggers only when float color buffer or WebGL2 is unavailable', () => {
  const noFloatCaps: DeviceGraphicsCapabilities = {
    ...MOBILE_CONSTRAINED_CAPS,
    supportsColorBufferFloat: false,
  };
  const plan = planExportMemoryBudget(512, 512, 64, noFloatCaps, 'pathtracer');
  assert.equal(plan.valid, true);
  assert.equal(plan.useCpuFallback, true);
});

test('buildCenterFirstTiles covers entire W x H image with zero overlap and zero gaps', () => {
  const width = 512;
  const height = 384;
  const tiles = buildCenterFirstTiles(width, height, 96);
  const coveredPixels = tiles.reduce((sum, t) => sum + t.tw * t.th, 0);
  assert.equal(coveredPixels, width * height);

  // Center tile should execute before corner tile
  const first = tiles[0];
  const last = tiles[tiles.length - 1];
  const dFirst = Math.hypot(first.tx + first.tw / 2 - width / 2, first.tyTop + first.th / 2 - height / 2);
  const dLast = Math.hypot(last.tx + last.tw / 2 - width / 2, last.tyTop + last.th / 2 - height / 2);
  assert.ok(dFirst <= dLast);
});

test('Progressive sample schedule always starts at 1 SPP and sums to exact target', () => {
  for (const target of [1, 8, 32, 64, 256, 1024]) {
    const schedule = buildProgressiveSampleSchedule(target, 8, 8, false);
    assert.equal(schedule[0], 1);
    assert.equal(
      schedule.reduce((a, b) => a + b, 0),
      target,
    );
  }
});

test('Oversized unsafe export dimensions are cleanly rejected', () => {
  const bad = planExportMemoryBudget(9000, 9000, 32, DESKTOP_CAPS, 'pathtracer');
  assert.equal(bad.valid, false);
  assert.ok(bad.reason && bad.reason.length > 0);
});
