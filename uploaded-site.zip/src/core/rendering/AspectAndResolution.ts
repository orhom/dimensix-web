export type AspectRatioPresetId = '1:1' | '16:9' | '9:16' | '4:3' | '3:2' | 'custom';

export type ResolutionPresetId = '512' | '1024' | '1920' | '2560' | '3840' | 'custom';

export interface AspectRatioOption {
  id: AspectRatioPresetId;
  ratioW: number;
  ratioH: number;
}

export const ASPECT_RATIO_PRESETS: ReadonlyArray<AspectRatioOption> = [
  { id: '1:1', ratioW: 1, ratioH: 1 },
  { id: '16:9', ratioW: 16, ratioH: 9 },
  { id: '9:16', ratioW: 9, ratioH: 16 },
  { id: '4:3', ratioW: 4, ratioH: 3 },
  { id: '3:2', ratioW: 3, ratioH: 2 },
  { id: 'custom', ratioW: 16, ratioH: 10 },
];

export const RESOLUTION_BASE_PRESETS: ReadonlyArray<Exclude<ResolutionPresetId, 'custom'>> = [
  '512',
  '1024',
  '1920',
  '2560',
  '3840',
];

export const MAX_SAMPLES_LIMIT = 1024;
export const MIN_EXPORT_DIM = 64;
export const MAX_EXPORT_DIM = 8192;

export const SAMPLE_PRESETS: ReadonlyArray<number> = [16, 32, 64, 128, 256, 512, 1024];

export interface ExportDimensionConfig {
  aspectPreset: AspectRatioPresetId;
  customAspectW: number;
  customAspectH: number;
  resolutionPreset: ResolutionPresetId;
  customWidth: number;
  customHeight: number;
}

export interface ComputedExportDimensions {
  width: number;
  height: number;
  aspectRatio: number;
  aspectLabel: string;
  totalPixels: number;
  megapixels: number;
}

export function resolveAspectRatio(
  preset: AspectRatioPresetId,
  customW: number,
  customH: number,
): { ratio: number; ratioW: number; ratioH: number; label: string } {
  if (preset === 'custom') {
    const safeW = clampNumber(Number.isFinite(customW) ? customW : 16, 0.1, 1000);
    const safeH = clampNumber(Number.isFinite(customH) ? customH : 9, 0.1, 1000);
    return {
      ratio: safeW / safeH,
      ratioW: safeW,
      ratioH: safeH,
      label: `${formatRatioPart(safeW)}:${formatRatioPart(safeH)}`,
    };
  }
  const found = ASPECT_RATIO_PRESETS.find((item) => item.id === preset) ?? ASPECT_RATIO_PRESETS[1];
  return {
    ratio: found.ratioW / found.ratioH,
    ratioW: found.ratioW,
    ratioH: found.ratioH,
    label: found.id,
  };
}

/**
 * Decouples Aspect Ratio (frame proportions) from Output Resolution (pixel width / density).
 * When a standard base resolution width is chosen (512..3840), height is derived cleanly
 * from width / aspectRatio. In 'custom' resolution mode, explicit W x H are clamped safely.
 */
export function computeExportDimensions(config: ExportDimensionConfig): ComputedExportDimensions {
  const resolved = resolveAspectRatio(
    config.aspectPreset,
    config.customAspectW,
    config.customAspectH,
  );

  let width: number;
  let height: number;

  if (config.resolutionPreset === 'custom') {
    width = clampDim(config.customWidth);
    height = clampDim(config.customHeight);
  } else {
    const baseW = parseInt(config.resolutionPreset, 10);
    width = clampDim(Number.isFinite(baseW) ? baseW : 1024);
    height = clampDim(Math.round(width / resolved.ratio));
  }

  const totalPixels = width * height;
  return {
    width,
    height,
    aspectRatio: width / height,
    aspectLabel:
      config.resolutionPreset === 'custom'
        ? computeSimplifiedRatioLabel(width, height)
        : resolved.label,
    totalPixels,
    megapixels: Math.round((totalPixels / 1_000_000) * 100) / 100,
  };
}

export function deriveHeightFromWidth(
  width: number,
  aspectPreset: AspectRatioPresetId,
  customAspectW: number,
  customAspectH: number,
): number {
  const { ratio } = resolveAspectRatio(aspectPreset, customAspectW, customAspectH);
  return clampDim(Math.round(clampDim(width) / ratio));
}

export function clampSampleCount(samples: number): number {
  if (!Number.isFinite(samples)) return 32;
  return Math.max(1, Math.min(MAX_SAMPLES_LIMIT, Math.round(samples)));
}

function clampDim(value: number): number {
  if (!Number.isFinite(value)) return 1024;
  return Math.max(MIN_EXPORT_DIM, Math.min(MAX_EXPORT_DIM, Math.round(value)));
}

function clampNumber(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function formatRatioPart(value: number): string {
  return Number.isInteger(value) ? String(value) : String(Math.round(value * 10) / 10);
}

function gcd(a: number, b: number): number {
  let x = Math.abs(Math.round(a));
  let y = Math.abs(Math.round(b));
  while (y !== 0) {
    const t = y;
    y = x % y;
    x = t;
  }
  return Math.max(1, x);
}

function computeSimplifiedRatioLabel(w: number, h: number): string {
  const d = gcd(w, h);
  const sw = Math.round(w / d);
  const sh = Math.round(h / d);
  if (sw <= 32 && sh <= 32) {
    return `${sw}:${sh}`;
  }
  const ratio = Math.round((w / h) * 100) / 100;
  return `${ratio}:1`;
}
