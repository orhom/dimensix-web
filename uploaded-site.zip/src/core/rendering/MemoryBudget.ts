export type AccumulationStrategy = 'full-progressive' | 'tile-streaming';

export interface DeviceGraphicsCapabilities {
  maxTextureSize: number;
  maxRenderbufferSize: number;
  supportsWebGL2: boolean;
  supportsColorBufferFloat: boolean;
  supportsColorBufferHalfFloat: boolean;
  isSoftwareGl: boolean;
  deviceMemoryGb: number;
}

export interface TileRect {
  index: number;
  tx: number;
  tyTop: number; // Top-down canvas Y
  tw: number;
  th: number;
}

export interface ExportMemoryPlan {
  valid: boolean;
  reason?: string;
  width: number;
  height: number;
  totalPixels: number;
  tileSize: number;
  tileCols: number;
  tileRows: number;
  totalTiles: number;
  strategy: AccumulationStrategy;
  sampleBatches: number[];
  gpuTileVramBytes: number;
  workerHdrBytes: number;
  canvasRgbaBytes: number;
  estimatedPeakMb: number;
  useCpuFallback: boolean;
}

const MAX_HARD_PIXELS = 36_000_000; // e.g. 6000x6000 ceiling for browser Canvas2D stability

export function probeDeviceGraphicsCapabilities(): DeviceGraphicsCapabilities {
  if (typeof document === 'undefined') {
    return {
      maxTextureSize: 4096,
      maxRenderbufferSize: 4096,
      supportsWebGL2: true,
      supportsColorBufferFloat: true,
      supportsColorBufferHalfFloat: true,
      isSoftwareGl: false,
      deviceMemoryGb: 8,
    };
  }

  const nav = typeof navigator !== 'undefined' ? (navigator as Navigator & { deviceMemory?: number }) : undefined;
  const deviceMemoryGb =
    typeof nav?.deviceMemory === 'number' && Number.isFinite(nav.deviceMemory)
      ? nav.deviceMemory
      : 4;

  let canvas: HTMLCanvasElement | null = null;
  try {
    canvas = document.createElement('canvas');
    canvas.width = 2;
    canvas.height = 2;
    const gl = canvas.getContext('webgl2') as WebGL2RenderingContext | null;
    if (!gl) {
      return {
        maxTextureSize: 4096,
        maxRenderbufferSize: 4096,
        supportsWebGL2: false,
        supportsColorBufferFloat: false,
        supportsColorBufferHalfFloat: false,
        isSoftwareGl: true,
        deviceMemoryGb,
      };
    }

    const maxTextureSize = Number(gl.getParameter(gl.MAX_TEXTURE_SIZE)) || 4096;
    const maxRenderbufferSize = Number(gl.getParameter(gl.MAX_RENDERBUFFER_SIZE)) || 4096;
    const supportsColorBufferFloat = Boolean(gl.getExtension('EXT_color_buffer_float'));
    const supportsColorBufferHalfFloat = Boolean(gl.getExtension('EXT_color_buffer_half_float'));
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    const rendererName = String(
      gl.getParameter(dbg ? dbg.UNMASKED_RENDERER_WEBGL : gl.RENDERER) ?? '',
    );
    const isSoftwareGl = /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(rendererName);
    gl.getExtension('WEBGL_lose_context')?.loseContext();

    return {
      maxTextureSize,
      maxRenderbufferSize,
      supportsWebGL2: true,
      supportsColorBufferFloat,
      supportsColorBufferHalfFloat,
      isSoftwareGl,
      deviceMemoryGb,
    };
  } catch {
    return {
      maxTextureSize: 4096,
      maxRenderbufferSize: 4096,
      supportsWebGL2: false,
      supportsColorBufferFloat: false,
      supportsColorBufferHalfFloat: false,
      isSoftwareGl: true,
      deviceMemoryGb,
    };
  } finally {
    canvas = null;
  }
}

/**
 * Generates an adaptive progressive batch schedule summing strictly to totalSamples.
 * Pass 1 always renders 1 SPP so the user sees the full frame shape immediately.
 */
export function buildProgressiveSampleSchedule(
  totalSamples: number,
  tileCols: number,
  tileRows: number,
  isSoftwareGl: boolean,
): number[] {
  const clamped = Math.max(1, Math.min(1024, Math.round(totalSamples)));
  if (clamped === 1) return [1];

  const tileCount = Math.max(1, tileCols * tileRows);
  // Keep each GPU tile pass fast enough that the main thread stays interactive
  const maxBatchPerPass = isSoftwareGl
    ? tileCount > 16
      ? 16
      : 32
    : tileCount > 64
      ? 32
      : 64;

  const batches: number[] = [1];
  let remaining = clamped - 1;
  let step = 3;

  while (remaining > 0) {
    const next = Math.min(remaining, step, maxBatchPerPass);
    batches.push(next);
    remaining -= next;
    step = Math.min(maxBatchPerPass, Math.max(2, step * 2));
  }

  return batches;
}

/**
 * Plans safe tile chunking, memory ceilings, and WebGL vs CPU fallback execution
 * so high resolutions (up to 4K) and 1024 SPP never exhaust GPU VRAM or crash mobile tabs.
 */
export function planExportMemoryBudget(
  width: number,
  height: number,
  targetSamples: number,
  caps: DeviceGraphicsCapabilities,
  engineKind: 'pathtracer' | 'realtime',
): ExportMemoryPlan {
  const w = Math.round(width);
  const h = Math.round(height);
  const totalPixels = w * h;

  if (!Number.isFinite(w) || !Number.isFinite(h) || w < 64 || h < 64) {
    return invalidPlan(w, h, 'Export dimensions must be at least 64 × 64 pixels.');
  }

  if (totalPixels > MAX_HARD_PIXELS || w > 8192 || h > 8192) {
    return invalidPlan(
      w,
      h,
      `Output size ${w} × ${h} exceeds safe browser canvas memory limits (max 8192 px / 36 MP).`,
    );
  }

  const canvasRgbaBytes = totalPixels * 4;
  const maxSafeDim = Math.min(caps.maxTextureSize, caps.maxRenderbufferSize);

  if (engineKind === 'realtime' && (w > maxSafeDim || h > maxSafeDim)) {
    return invalidPlan(
      w,
      h,
      `Real-Time framebuffer exceeds GPU max texture dimension (${maxSafeDim} px). Switch to Path Tracing for chunked rendering.`,
    );
  }

  const useCpuFallback =
    engineKind === 'pathtracer' && (!caps.supportsWebGL2 || !caps.supportsColorBufferFloat);

  // Choose tile dimension: smaller on software/low-mem for responsive tile-by-tile updates
  let tileSize = 128;
  if (caps.isSoftwareGl || caps.deviceMemoryGb <= 2 || useCpuFallback) {
    tileSize = totalPixels >= 1920 * 1080 ? 96 : 64;
  } else if (totalPixels >= 2560 * 1440) {
    tileSize = 128;
  }

  if (engineKind === 'realtime') {
    tileSize = Math.min(w, h);
  }

  const tileCols = Math.ceil(w / tileSize);
  const tileRows = Math.ceil(h / tileSize);
  const totalTiles = tileCols * tileRows;

  // Allow full-frame progressive float store up to 72 MB on <=4GB devices or 140 MB on >=8GB
  const maxWorkerAccumBytes =
    caps.deviceMemoryGb >= 6 && !caps.isSoftwareGl ? 140 * 1024 * 1024 : 68 * 1024 * 1024;
  const fullFrameHdrBytes = totalPixels * 16; // Float32 RGBA per pixel

  const strategy: AccumulationStrategy =
    engineKind === 'pathtracer' && fullFrameHdrBytes <= maxWorkerAccumBytes
      ? 'full-progressive'
      : 'tile-streaming';

  // GPU only ever holds TWO tiny tileSize x tileSize RGBA32F render targets + 1 RGBA8 staging
  const gpuTileVramBytes =
    engineKind === 'pathtracer'
      ? tileSize * tileSize * (16 * 2 + 4)
      : totalPixels * 4;

  const singleTileHdrBytes = tileSize * tileSize * 16;
  const workerHdrBytes =
    engineKind === 'realtime'
      ? 0
      : strategy === 'full-progressive'
        ? fullFrameHdrBytes
        : singleTileHdrBytes;

  const sampleBatches =
    engineKind === 'pathtracer'
      ? buildProgressiveSampleSchedule(targetSamples, tileCols, tileRows, caps.isSoftwareGl)
      : [1];

  const estimatedPeakBytes =
    canvasRgbaBytes + workerHdrBytes + gpuTileVramBytes + 12 * 1024 * 1024;

  return {
    valid: true,
    width: w,
    height: h,
    totalPixels,
    tileSize,
    tileCols,
    tileRows,
    totalTiles,
    strategy,
    sampleBatches,
    gpuTileVramBytes,
    workerHdrBytes,
    canvasRgbaBytes,
    estimatedPeakMb: Math.round((estimatedPeakBytes / (1024 * 1024)) * 10) / 10,
    useCpuFallback,
  };
}

/**
 * Generates tiles ordered radially from center outward so the focal subject
 * appears first during progressive tile rendering, with exact pixel bounds.
 */
export function buildCenterFirstTiles(width: number, height: number, tileSize: number): TileRect[] {
  const tiles: TileRect[] = [];
  let idx = 0;
  for (let tyTop = 0; tyTop < height; tyTop += tileSize) {
    const th = Math.min(tileSize, height - tyTop);
    for (let tx = 0; tx < width; tx += tileSize) {
      const tw = Math.min(tileSize, width - tx);
      tiles.push({ index: idx++, tx, tyTop, tw, th });
    }
  }

  const cx = width * 0.5;
  const cy = height * 0.5;
  tiles.sort((a, b) => {
    const da = Math.hypot(a.tx + a.tw * 0.5 - cx, a.tyTop + a.th * 0.5 - cy);
    const db = Math.hypot(b.tx + b.tw * 0.5 - cx, b.tyTop + b.th * 0.5 - cy);
    return da - db;
  });

  // Re-index in execution order
  return tiles.map((t, i) => ({ ...t, index: i }));
}

function invalidPlan(width: number, height: number, reason: string): ExportMemoryPlan {
  return {
    valid: false,
    reason,
    width,
    height,
    totalPixels: Math.max(0, width * height),
    tileSize: 64,
    tileCols: 0,
    tileRows: 0,
    totalTiles: 0,
    strategy: 'tile-streaming',
    sampleBatches: [1],
    gpuTileVramBytes: 0,
    workerHdrBytes: 0,
    canvasRgbaBytes: 0,
    estimatedPeakMb: 0,
    useCpuFallback: false,
  };
}
