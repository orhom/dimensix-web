export interface TilePostProcessParams {
  exposure: number;
  contrast: number;
  gamma: number;
  toneMappingMode: 0 | 1 | 2;
  denoiseStrength: number;
}

export interface TileAccumSlot {
  sumFloat: Float32Array;
  sampleCount: number;
  tw: number;
  th: number;
}

export class TileAccumulationStore {
  private readonly slots = new Map<string, TileAccumSlot>();

  accumulateTileBatch(
    tileKey: string,
    tw: number,
    th: number,
    batchSamples: number,
    incomingRgba: Float32Array,
    incomingIsSum: boolean,
    flipY: boolean,
  ): TileAccumSlot {
    const expectedLen = tw * th * 4;
    let slot = this.slots.get(tileKey);
    if (!slot || slot.tw !== tw || slot.th !== th) {
      slot = {
        sumFloat: new Float32Array(expectedLen),
        sampleCount: 0,
        tw,
        th,
      };
      this.slots.set(tileKey, slot);
    }

    const dst = slot.sumFloat;
    const scale = incomingIsSum ? 1 : Math.max(1, batchSamples);

    for (let y = 0; y < th; y++) {
      const srcY = flipY ? th - 1 - y : y;
      const srcRowBase = srcY * tw * 4;
      const dstRowBase = y * tw * 4;

      for (let x = 0; x < tw; x++) {
        const si = srcRowBase + x * 4;
        const di = dstRowBase + x * 4;

        const r = incomingRgba[si];
        const g = incomingRgba[si + 1];
        const b = incomingRgba[si + 2];

        dst[di] += Number.isFinite(r) && r > 0 ? r * scale : 0;
        dst[di + 1] += Number.isFinite(g) && g > 0 ? g * scale : 0;
        dst[di + 2] += Number.isFinite(b) && b > 0 ? b * scale : 0;
        dst[di + 3] = 1;
      }
    }

    slot.sampleCount += Math.max(1, Math.round(batchSamples));
    return slot;
  }

  releaseTile(tileKey: string): void {
    this.slots.delete(tileKey);
  }

  clear(): void {
    this.slots.clear();
  }

  getTileCount(): number {
    return this.slots.size;
  }
}

function acesToneMapChannel(x: number): number {
  const a = 2.51;
  const b = 0.03;
  const c = 2.43;
  const d = 0.59;
  const e = 0.14;
  return clamp01((x * (a * x + b)) / (x * (c * x + d) + e));
}

function clamp01(v: number): number {
  return v < 0 ? 0 : v > 1 ? 1 : v;
}

/**
 * Converts a tile's accumulated linear HDR sum buffer into an 8-bit sRGB RGBA8 buffer
 * with adaptive edge-preserving denoising, exposure, tone mapping, contrast, and gamma.
 */
export function resolveTileToRgba8(
  slot: TileAccumSlot,
  params: TilePostProcessParams,
): Uint8ClampedArray {
  const { tw, th, sumFloat, sampleCount } = slot;
  const invSamples = 1 / Math.max(1, sampleCount);
  const pixelCount = tw * th;

  // 1. Compute linear HDR mean RGB
  const meanRgb = new Float32Array(pixelCount * 3);
  for (let i = 0; i < pixelCount; i++) {
    const s = i * 4;
    const m = i * 3;
    meanRgb[m] = sumFloat[s] * invSamples;
    meanRgb[m + 1] = sumFloat[s + 1] * invSamples;
    meanRgb[m + 2] = sumFloat[s + 2] * invSamples;
  }

  // 2. Adaptive edge-preserving bilateral denoise (fades cleanly to 0 by 128+ SPP)
  const adaptiveWeight =
    params.denoiseStrength * clamp01(1 - sampleCount / 112);

  const out = new Uint8ClampedArray(pixelCount * 4);
  const invGamma = 1 / Math.max(0.1, params.gamma);
  const sigmaColor = 0.14 + (0.35 - 0.14) * adaptiveWeight;
  const twoSigma2 = 2 * sigmaColor * sigmaColor;

  for (let y = 0; y < th; y++) {
    for (let x = 0; x < tw; x++) {
      const idx = y * tw + x;
      const mIdx = idx * 3;
      const cR = meanRgb[mIdx];
      const cG = meanRgb[mIdx + 1];
      const cB = meanRgb[mIdx + 2];

      let fR = cR;
      let fG = cG;
      let fB = cB;

      if (adaptiveWeight > 0.02) {
        const cLum = 0.2126 * cR + 0.7152 * cG + 0.0722 * cB;
        const denomLum = Math.max(cLum + 0.15, 0.15);
        let accR = 0;
        let accG = 0;
        let accB = 0;
        let totalW = 0;

        for (let dy = -2; dy <= 2; dy++) {
          const ny = y + dy;
          const cy = ny < 0 ? 0 : ny >= th ? th - 1 : ny;
          const dy2 = dy * dy;
          for (let dx = -2; dx <= 2; dx++) {
            const nx = x + dx;
            const cx = nx < 0 ? 0 : nx >= tw ? tw - 1 : nx;
            const nBase = (cy * tw + cx) * 3;
            const nR = meanRgb[nBase];
            const nG = meanRgb[nBase + 1];
            const nB = meanRgb[nBase + 2];

            const nLum = 0.2126 * nR + 0.7152 * nG + 0.0722 * nB;
            const lumDiff = Math.abs(nLum - cLum) / denomLum;
            const wSpatial = Math.exp(-(dx * dx + dy2) / 4.5);
            const wRange = Math.exp(-(lumDiff * lumDiff) / twoSigma2);
            const w = wSpatial * wRange;

            accR += nR * w;
            accG += nG * w;
            accB += nB * w;
            totalW += w;
          }
        }

        const invW = 1 / Math.max(totalW, 1e-5);
        fR = cR + (accR * invW - cR) * adaptiveWeight;
        fG = cG + (accG * invW - cG) * adaptiveWeight;
        fB = cB + (accB * invW - cB) * adaptiveWeight;
      }

      // 3. Exposure + Tone Mapping + Contrast + Gamma
      const hR = fR * params.exposure;
      const hG = fG * params.exposure;
      const hB = fB * params.exposure;

      let mR: number;
      let mG: number;
      let mB: number;

      if (params.toneMappingMode === 0) {
        mR = clamp01(hR);
        mG = clamp01(hG);
        mB = clamp01(hB);
      } else if (params.toneMappingMode === 1) {
        mR = hR / (1 + hR);
        mG = hG / (1 + hG);
        mB = hB / (1 + hB);
      } else {
        mR = acesToneMapChannel(hR);
        mG = acesToneMapChannel(hG);
        mB = acesToneMapChannel(hB);
      }

      mR = clamp01((mR - 0.5) * params.contrast + 0.5);
      mG = clamp01((mG - 0.5) * params.contrast + 0.5);
      mB = clamp01((mB - 0.5) * params.contrast + 0.5);

      const oIdx = idx * 4;
      out[oIdx] = Math.round(Math.pow(mR, invGamma) * 255);
      out[oIdx + 1] = Math.round(Math.pow(mG, invGamma) * 255);
      out[oIdx + 2] = Math.round(Math.pow(mB, invGamma) * 255);
      out[oIdx + 3] = 255;
    }
  }

  return out;
}
