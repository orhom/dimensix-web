export type RenderResolutionPreset = 'native' | '720p' | '1080p' | '1440p';
export type AntiAliasingMode = 'none' | 'fxaa' | 'msaa';
export type QualityLevel = 'low' | 'medium' | 'high';
export type ShadowQualityLevel = 'off' | 'low' | 'medium' | 'high';
export type RenderQualityLevel = 'draft' | 'standard' | 'high';
export type ShadowResolutionSize = 512 | 1024 | 2048;
export type RenderPresetId = 'performance' | 'balanced' | 'cinematic';

export interface RenderSettings {
  // Image Quality
  resolution: RenderResolutionPreset;
  renderScale: number; // 0.5 .. 2.0
  pixelRatio: number; // 0.5 .. 2.0
  antiAliasing: AntiAliasingMode;
  shadowQuality: ShadowQualityLevel;

  // Lighting & Visual Quality
  ambientOcclusion: boolean;
  exposure: number; // 0.4 .. 2.2
  gamma: number; // 1.4 .. 2.6
  contrast: number; // 0.5 .. 1.8
  bloomEnabled: boolean;
  bloomIntensity: number; // 0 .. 2.0
  dofEnabled: boolean;
  dofFocusDistance: number; // 1 .. 30
  dofAperture: number; // 0.001 .. 0.03
  motionBlurEnabled: boolean;
  motionBlurAmount: number; // 0.1 .. 0.9

  // Performance
  previewQuality: QualityLevel;
  renderQuality: RenderQualityLevel;
  textureQuality: QualityLevel;
  shadowResolution: ShadowResolutionSize;
  performanceMode: boolean;
}

export const DEFAULT_RENDER_SETTINGS: RenderSettings = {
  resolution: 'native',
  renderScale: 1.0,
  pixelRatio: 1.5,
  antiAliasing: 'msaa',
  shadowQuality: 'medium',

  ambientOcclusion: false,
  exposure: 1.1,
  gamma: 2.2,
  contrast: 1.0,
  bloomEnabled: false,
  bloomIntensity: 0.55,
  dofEnabled: false,
  dofFocusDistance: 8.0,
  dofAperture: 0.008,
  motionBlurEnabled: false,
  motionBlurAmount: 0.45,

  previewQuality: 'high',
  renderQuality: 'standard',
  textureQuality: 'high',
  shadowResolution: 1024,
  performanceMode: false,
};

export const RENDER_SETTING_PRESETS: Record<RenderPresetId, Partial<RenderSettings>> = {
  performance: {
    resolution: '720p',
    renderScale: 0.75,
    pixelRatio: 1.0,
    antiAliasing: 'none',
    shadowQuality: 'low',
    ambientOcclusion: false,
    bloomEnabled: false,
    dofEnabled: false,
    motionBlurEnabled: false,
    previewQuality: 'low',
    renderQuality: 'draft',
    textureQuality: 'low',
    shadowResolution: 512,
    performanceMode: true,
  },
  balanced: {
    ...DEFAULT_RENDER_SETTINGS,
  },
  cinematic: {
    resolution: 'native',
    renderScale: 1.25,
    pixelRatio: 2.0,
    antiAliasing: 'fxaa',
    shadowQuality: 'high',
    ambientOcclusion: true,
    exposure: 1.15,
    gamma: 2.2,
    contrast: 1.08,
    bloomEnabled: true,
    bloomIntensity: 0.65,
    dofEnabled: false,
    motionBlurEnabled: false,
    previewQuality: 'high',
    renderQuality: 'high',
    textureQuality: 'high',
    shadowResolution: 2048,
    performanceMode: false,
  },
};

export function sanitizeRenderSettings(raw?: Partial<RenderSettings> | null): RenderSettings {
  const merged: RenderSettings = {
    ...DEFAULT_RENDER_SETTINGS,
    ...(raw ?? {}),
  };

  return {
    ...merged,
    renderScale: clamp(round2(merged.renderScale), 0.5, 2.0),
    pixelRatio: clamp(round2(merged.pixelRatio), 0.5, 2.0),
    exposure: clamp(round2(merged.exposure), 0.4, 2.2),
    gamma: clamp(round2(merged.gamma), 1.4, 2.6),
    contrast: clamp(round2(merged.contrast), 0.5, 1.8),
    bloomIntensity: clamp(round2(merged.bloomIntensity), 0, 2.0),
    dofFocusDistance: clamp(round2(merged.dofFocusDistance), 1.0, 30.0),
    dofAperture: clamp(Number(merged.dofAperture.toFixed(4)), 0.001, 0.03),
    motionBlurAmount: clamp(round2(merged.motionBlurAmount), 0.1, 0.9),
    shadowResolution:
      merged.shadowResolution === 512 ||
      merged.shadowResolution === 1024 ||
      merged.shadowResolution === 2048
        ? merged.shadowResolution
        : 1024,
  };
}

export class RenderSettingsManager {
  private settings: RenderSettings;

  constructor(initial?: Partial<RenderSettings>) {
    this.settings = sanitizeRenderSettings(initial);
  }

  getSettings(): RenderSettings {
    return { ...this.settings };
  }

  load(raw?: Partial<RenderSettings> | null): RenderSettings {
    this.settings = sanitizeRenderSettings(raw);
    return this.getSettings();
  }

  update(patch: Partial<RenderSettings>): RenderSettings {
    this.settings = sanitizeRenderSettings({
      ...this.settings,
      ...patch,
    });
    return this.getSettings();
  }

  applyPreset(preset: RenderPresetId): RenderSettings {
    this.settings = sanitizeRenderSettings({
      ...this.settings,
      ...RENDER_SETTING_PRESETS[preset],
    });
    return this.getSettings();
  }

  reset(): RenderSettings {
    this.settings = sanitizeRenderSettings(DEFAULT_RENDER_SETTINGS);
    return this.getSettings();
  }
}

function clamp(v: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, v));
}

function round2(v: number): number {
  return Math.round(v * 100) / 100;
}
