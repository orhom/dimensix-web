import * as THREE from 'three';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import type { ModelAssetRegistry } from '../assets/ModelAssetRegistry';
import { intersectRayTLAS } from '../bvh/BVHBuilder';
import { CameraController, type CameraMode } from '../camera/CameraController';
import type {
  CameraPoseState,
  CameraPreset,
  EngineMemoryStats,
  ExportImageOptions,
  IRenderEngine,
  PathTracerStatus,
  RenderEngineDescriptor,
  TransformMode,
  ViewportCallbacks,
  ViewportSettings,
} from './IRenderEngine';
import { clampSampleCount } from './AspectAndResolution';
import {
  DENOISE_DISPLAY_FRAGMENT_SHADER,
  FULLSCREEN_VERTEX_SHADER,
  PATH_TRACER_FRAGMENT_SHADER,
} from './PathTracingShaders';
import { DEFAULT_RENDER_SETTINGS, type RenderSettings } from './RenderSettings';
import {
  buildPackedSceneForPathTracer,
  computeNodeWorldMatrices,
  PrimitiveGeometryCache,
  type PackedSceneForPathTracer,
} from './SceneBridge';
import { runTiledPathTracingExportSession } from './TiledPathTracingExportSession';
import {
  isLightNodeType,
  type SceneNode,
  type SceneSnapshot,
  type TransformData,
} from '../scene/SceneNode';

export const PATH_TRACING_DESCRIPTOR: RenderEngineDescriptor = {
  id: 'dimensix-path-tracer',
  name: 'Path Tracing Renderer',
  version: '3.0.0',
  description:
    'Monte Carlo BVH Path Tracer with MIS, global illumination, reflections, glass refraction, and denoising.',
  capabilities: {
    supportsShadows: true,
    supportsEnvironmentLighting: true,
    supportsTransformGizmo: true,
    supportsPostProcessing: true,
    supportsRayTracing: true,
    supportsSSGI: true,
  },
};

// Shaders imported from ./PathTracingShaders

function detectSoftwareWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) ?? '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export class PathTracingViewportEngine implements IRenderEngine {
  readonly descriptor = PATH_TRACING_DESCRIPTOR;

  private container: HTMLElement | null = null;
  private callbacks: ViewportCallbacks | null = null;
  private assetRegistry: ModelAssetRegistry | null = null;

  private renderer: THREE.WebGLRenderer | null = null;
  private ptCamera: THREE.PerspectiveCamera | null = null;
  private overlayScene: THREE.Scene | null = null;
  private overlayRoot = new THREE.Group();
  private gridHelper: THREE.GridHelper | null = null;
  private axesHelper: THREE.AxesHelper | null = null;
  private selectionHelper: THREE.BoxHelper | null = null;
  private transformControls: TransformControls | null = null;
  private overlayObjects = new Map<string, THREE.Object3D>();

  private quadScene = new THREE.Scene();
  private quadCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  private quadGeo: THREE.PlaneGeometry | null = null;
  private quadMesh: THREE.Mesh | null = null;
  private ptMaterial: THREE.ShaderMaterial | null = null;
  private displayMaterial: THREE.ShaderMaterial | null = null;

  private accumTargets: [THREE.WebGLRenderTarget, THREE.WebGLRenderTarget] | null = null;
  private accumWriteIdx = 0;

  // GPU Scene & BVH DataTextures
  private bvhNodesTex: THREE.DataTexture | null = null;
  private triTex: THREE.DataTexture | null = null;
  private instanceTex: THREE.DataTexture | null = null;
  private materialTex: THREE.DataTexture | null = null;
  private lightTex: THREE.DataTexture | null = null;
  private atlasTex: THREE.DataTexture | null = null;

  private readonly cameraController = new CameraController();
  private readonly primitiveCache = new PrimitiveGeometryCache();
  private packedScene: PackedSceneForPathTracer | null = null;

  private snapshot: SceneSnapshot = { nodes: [], selectedId: null };
  private renderSettings: RenderSettings = { ...DEFAULT_RENDER_SETTINGS };
  private viewportSettings: ViewportSettings = {
    showGrid: true,
    showAxes: true,
    snapToGrid: false,
    fov: 50,
  };
  private isSoftwareGl = false;
  private hasFloatColorBuffer = true;
  private viewportSize = { width: 1, height: 1 };
  private accumSize = { width: 1, height: 1 };

  // Progressive & dynamic motion-adaptive state
  private sampleIndex = 0;
  private isInteracting = false;
  private interactionTimer = 0;
  private frameId = 0;
  private renderBusy = false;
  private renderDirty = false;
  private paused = false;
  private lastTransitionTime = 0;
  private disposed = false;

  // Pointer & Touch state
  private activePointers = new Map<number, { x: number; y: number }>();
  private pointerDownPos = { x: 0, y: 0 };
  private pointerTravel = 0;
  private isDraggingGizmo = false;
  private prevPinchDist = 0;
  private prevPinchCenter = { x: 0, y: 0 };
  private raycaster = new THREE.Raycaster();
  private pointerVec = new THREE.Vector2();
  private cleanupListeners: Array<() => void> = [];

  mount(container: HTMLElement, callbacks: ViewportCallbacks): void {
    this.container = container;
    this.callbacks = callbacks;
    this.disposed = false;
    this.isSoftwareGl = detectSoftwareWebGL();

    const width = Math.max(container.clientWidth, 1);
    const height = Math.max(container.clientHeight, 1);
    this.viewportSize = { width, height };

    try {
      const renderer = new THREE.WebGLRenderer({
        antialias: false,
        powerPreference: 'high-performance',
        preserveDrawingBuffer: true,
      });
      renderer.autoClear = false;
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.setPixelRatio(1);
      renderer.setSize(width, height, false);
      renderer.domElement.style.display = 'block';
      renderer.domElement.style.width = '100%';
      renderer.domElement.style.height = '100%';
      renderer.domElement.style.touchAction = 'none';
      renderer.domElement.setAttribute('data-testid', 'dimensix-viewport-canvas');
      renderer.domElement.setAttribute('data-engine', this.descriptor.id);
      container.appendChild(renderer.domElement);
      this.renderer = renderer;

      const gl = renderer.getContext() as WebGL2RenderingContext;
      this.hasFloatColorBuffer = Boolean(gl.getExtension('EXT_color_buffer_float'));

      const ptCamera = new THREE.PerspectiveCamera(
        this.viewportSettings.fov,
        width / height,
        0.1,
        250,
      );
      this.ptCamera = ptCamera;
      this.applyCameraPose();

      // Overlay scene (grid, axes, gizmo, light/camera proxies)
      const overlayScene = new THREE.Scene();
      this.overlayScene = overlayScene;
      overlayScene.add(this.overlayRoot);

      const grid = new THREE.GridHelper(24, 24, 0x38bdf8, 0x1e293b);
      grid.position.y = 0.002;
      const gridMat = grid.material as THREE.Material | THREE.Material[];
      (Array.isArray(gridMat) ? gridMat : [gridMat]).forEach((m) => {
        m.transparent = true;
        m.opacity = 0.36;
      });
      grid.visible = this.viewportSettings.showGrid;
      this.gridHelper = grid;
      overlayScene.add(grid);

      const axes = new THREE.AxesHelper(1.5);
      axes.position.y = 0.01;
      axes.visible = this.viewportSettings.showAxes;
      this.axesHelper = axes;
      overlayScene.add(axes);

      const gizmo = new TransformControls(ptCamera, renderer.domElement);
      gizmo.setSize(0.85);
      overlayScene.add(gizmo.getHelper());
      this.transformControls = gizmo;

      this.initFullscreenShaders();
      this.createAccumTargets(width, height);

      const onDraggingChanged = (event: { value: unknown }) => {
        this.isDraggingGizmo = Boolean(event.value);
        if (this.isDraggingGizmo) {
          this.triggerInteractiveMotion();
          this.resetAccumulation();
        } else {
          this.scheduleMotionSettle();
        }
      };

      const onObjectChange = () => {
        const obj = gizmo.object;
        if (!obj || !obj.userData.nodeId) return;
        this.triggerInteractiveMotion();
        this.updateSelectionHelper();
        const transform = this.extractTransform(obj);
        this.callbacks?.onNodeTransformPreview(String(obj.userData.nodeId), transform);
      };

      const onMouseUp = () => {
        const obj = gizmo.object;
        if (!obj || !obj.userData.nodeId) return;
        const transform = this.extractTransform(obj);
        this.callbacks?.onNodeTransformCommit(String(obj.userData.nodeId), transform);
        this.scheduleMotionSettle();
      };

      gizmo.addEventListener('dragging-changed', onDraggingChanged);
      gizmo.addEventListener('objectChange', onObjectChange);
      gizmo.addEventListener('mouseUp', onMouseUp);

      const dom = renderer.domElement;

      const onPointerDown = (e: PointerEvent) => {
        this.activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
        if (this.activePointers.size === 1) {
          this.pointerDownPos = { x: e.clientX, y: e.clientY };
          this.pointerTravel = 0;
        } else if (this.activePointers.size === 2) {
          const pts = Array.from(this.activePointers.values());
          this.prevPinchDist = Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y);
          this.prevPinchCenter = {
            x: (pts[0].x + pts[1].x) * 0.5,
            y: (pts[0].y + pts[1].y) * 0.5,
          };
        }
      };

      const onPointerMove = (e: PointerEvent) => {
        if (!this.activePointers.has(e.pointerId)) return;
        const prev = this.activePointers.get(e.pointerId)!;
        const dx = e.clientX - prev.x;
        const dy = e.clientY - prev.y;
        this.activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

        if (this.isDraggingGizmo || gizmo.dragging) return;

        if (this.activePointers.size === 1) {
          this.pointerTravel += Math.hypot(dx, dy);
          if (Math.abs(dx) > 0.25 || Math.abs(dy) > 0.25) {
            this.triggerInteractiveMotion();
            const isPan = e.buttons === 2 || e.buttons === 4 || e.shiftKey;
            if (isPan) {
              this.cameraController.pan(dx, dy);
            } else {
              this.cameraController.rotate(-dx * 0.0072, -dy * 0.0072);
            }
            this.applyCameraPose();
            this.resetAccumulation();
          }
        } else if (this.activePointers.size === 2) {
          const pts = Array.from(this.activePointers.values());
          const dist = Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y);
          const center = {
            x: (pts[0].x + pts[1].x) * 0.5,
            y: (pts[0].y + pts[1].y) * 0.5,
          };
          this.triggerInteractiveMotion();
          this.cameraController.pan(
            center.x - this.prevPinchCenter.x,
            center.y - this.prevPinchCenter.y,
          );
          const pinchDelta = this.prevPinchDist - dist;
          if (Math.abs(pinchDelta) > 0.25) {
            this.cameraController.zoom(pinchDelta * 0.01);
          }
          this.prevPinchDist = dist;
          this.prevPinchCenter = center;
          this.applyCameraPose();
          this.resetAccumulation();
        }
      };

      const onPointerUp = (e: PointerEvent) => {
        const wasSingle = this.activePointers.size === 1;
        this.activePointers.delete(e.pointerId);

        if (this.activePointers.size === 0 && this.isInteracting) {
          this.scheduleMotionSettle();
        } else if (this.activePointers.size === 1) {
          const rem = Array.from(this.activePointers.values())[0];
          this.pointerDownPos = { ...rem };
          this.pointerTravel = 10;
        }

        if (
          wasSingle &&
          !this.isDraggingGizmo &&
          !gizmo.dragging &&
          e.button === 0 &&
          this.pointerTravel <= 6 &&
          Math.hypot(e.clientX - this.pointerDownPos.x, e.clientY - this.pointerDownPos.y) <= 6
        ) {
          this.pickAtPointer(e);
        }
      };

      const onWheel = (e: WheelEvent) => {
        e.preventDefault();
        this.triggerInteractiveMotion();
        this.cameraController.zoom(e.deltaY * 0.0012);
        this.applyCameraPose();
        this.resetAccumulation();
        this.scheduleMotionSettle();
      };

      const onContextMenu = (e: MouseEvent) => e.preventDefault();

      const onKeyDown = (e: KeyboardEvent) => {
        if (this.cameraController.getMode() !== 'free') return;
        const target = e.target as HTMLElement | null;
        if (
          target?.tagName === 'INPUT' ||
          target?.tagName === 'TEXTAREA' ||
          target?.tagName === 'SELECT'
        ) {
          return;
        }
        const step = 0.45;
        let moved = true;
        switch (e.key.toLowerCase()) {
          case 'w':
          case 'arrowup':
            this.cameraController.moveFree(step, 0, 0);
            break;
          case 's':
          case 'arrowdown':
            this.cameraController.moveFree(-step, 0, 0);
            break;
          case 'd':
          case 'arrowright':
            this.cameraController.moveFree(0, step, 0);
            break;
          case 'a':
          case 'arrowleft':
            this.cameraController.moveFree(0, -step, 0);
            break;
          case 'e':
            this.cameraController.moveFree(0, 0, step);
            break;
          case 'q':
            this.cameraController.moveFree(0, 0, -step);
            break;
          default:
            moved = false;
        }
        if (moved) {
          e.preventDefault();
          this.triggerInteractiveMotion();
          this.applyCameraPose();
          this.resetAccumulation();
          this.scheduleMotionSettle();
        }
      };

      const onContextLost = (e: Event) => {
        e.preventDefault();
        this.callbacks?.onEngineError?.('WebGL context lost in Path Tracer. Attempting recovery.');
      };

      const onContextRestored = () => {
        this.initFullscreenShaders();
        this.createAccumTargets(this.viewportSize.width, this.viewportSize.height);
        this.rebuildGpuScene();
        this.resetAccumulation();
      };

      dom.addEventListener('pointerdown', onPointerDown);
      window.addEventListener('pointermove', onPointerMove);
      window.addEventListener('pointerup', onPointerUp);
      window.addEventListener('pointercancel', onPointerUp);
      dom.addEventListener('wheel', onWheel, { passive: false });
      dom.addEventListener('contextmenu', onContextMenu);
      window.addEventListener('keydown', onKeyDown);
      dom.addEventListener('webglcontextlost', onContextLost);
      dom.addEventListener('webglcontextrestored', onContextRestored);

      this.cleanupListeners.push(() => {
        gizmo.removeEventListener('dragging-changed', onDraggingChanged);
        gizmo.removeEventListener('objectChange', onObjectChange);
        gizmo.removeEventListener('mouseUp', onMouseUp);
        dom.removeEventListener('pointerdown', onPointerDown);
        window.removeEventListener('pointermove', onPointerMove);
        window.removeEventListener('pointerup', onPointerUp);
        window.removeEventListener('pointercancel', onPointerUp);
        dom.removeEventListener('wheel', onWheel);
        dom.removeEventListener('contextmenu', onContextMenu);
        window.removeEventListener('keydown', onKeyDown);
        dom.removeEventListener('webglcontextlost', onContextLost);
        dom.removeEventListener('webglcontextrestored', onContextRestored);
      });

      this.syncScene(this.snapshot);
      this.applyRenderSettingsAttributes();
      this.requestRender();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to initialize Path Tracing WebGL2';
      this.callbacks?.onEngineError?.(msg);
    }
  }

  unmount(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    window.clearTimeout(this.frameId);
    window.clearTimeout(this.interactionTimer);

    for (const cleanup of this.cleanupListeners) cleanup();
    this.cleanupListeners = [];
    this.activePointers.clear();

    this.transformControls?.detach();
    this.transformControls?.dispose();
    this.transformControls = null;

    this.disposeOverlayObjects();
    this.selectionHelper?.geometry.dispose();
    (this.selectionHelper?.material as THREE.Material | undefined)?.dispose();
    this.selectionHelper = null;

    this.disposeGpuTextures();
    this.disposeAccumTargets();
    this.quadGeo?.dispose();
    this.ptMaterial?.dispose();
    this.displayMaterial?.dispose();
    this.quadGeo = null;
    this.ptMaterial = null;
    this.displayMaterial = null;

    this.primitiveCache.dispose();

    if (this.renderer) {
      this.renderer.domElement.remove();
      this.renderer.dispose();
      this.renderer = null;
    }

    this.overlayScene = null;
    this.ptCamera = null;
    this.container = null;
    this.callbacks = null;
  }

  setAssetRegistry(registry: ModelAssetRegistry): void {
    this.assetRegistry = registry;
  }

  syncScene(snapshot: SceneSnapshot): void {
    this.snapshot = snapshot;
    if (!this.renderer || !this.overlayScene) return;

    this.rebuildOverlayScene(snapshot);
    this.rebuildGpuScene();
    this.setSelection(snapshot.selectedId);
    this.resetAccumulation();
  }

  updateNode(node: SceneNode): void {
    const idx = this.snapshot.nodes.findIndex((n) => n.id === node.id);
    if (idx >= 0) {
      this.snapshot.nodes[idx] = node;
    }
    if (!this.renderer || !this.overlayScene) return;

    this.rebuildOverlayScene(this.snapshot);
    this.rebuildGpuScene();
    this.updateSelectionHelper();
    this.resetAccumulation();
  }

  setSelection(nodeId: string | null): void {
    this.snapshot = { ...this.snapshot, selectedId: nodeId };
    if (!this.overlayScene || !this.transformControls) return;

    if (!nodeId || !this.overlayObjects.has(nodeId)) {
      this.transformControls.detach();
      if (this.selectionHelper) this.selectionHelper.visible = false;
      this.requestRender();
      return;
    }

    const obj = this.overlayObjects.get(nodeId)!;
    if (obj.visible) {
      this.transformControls.attach(obj);
    } else {
      this.transformControls.detach();
    }

    if (!this.selectionHelper) {
      this.selectionHelper = new THREE.BoxHelper(obj, 0x22d3ee);
      this.overlayScene.add(this.selectionHelper);
    } else {
      this.selectionHelper.setFromObject(obj);
    }
    this.selectionHelper.visible = obj.visible;
    this.requestRender();
  }

  setTransformMode(mode: TransformMode): void {
    this.transformControls?.setMode(mode);
    this.requestRender();
  }

  setViewportSettings(settings: ViewportSettings): void {
    this.viewportSettings = { ...settings };
    if (this.gridHelper) this.gridHelper.visible = settings.showGrid;
    if (this.axesHelper) this.axesHelper.visible = settings.showAxes;
    if (this.transformControls) {
      this.transformControls.translationSnap = settings.snapToGrid ? 0.25 : null;
      this.transformControls.rotationSnap = settings.snapToGrid
        ? THREE.MathUtils.degToRad(15)
        : null;
      this.transformControls.scaleSnap = settings.snapToGrid ? 0.1 : null;
    }
    if (this.ptCamera && Math.abs(this.ptCamera.fov - settings.fov) > 0.1) {
      this.ptCamera.fov = settings.fov;
      this.ptCamera.updateProjectionMatrix();
      this.resetAccumulation();
    }
    this.requestRender();
  }

  setRenderSettings(settings: RenderSettings): void {
    this.renderSettings = { ...settings };
    this.applyRenderSettingsAttributes();
    this.resizeAccumTargetsForCurrentState();
    this.resetAccumulation();
  }

  setCameraMode(mode: CameraMode): void {
    this.cameraController.setMode(mode);
    this.applyCameraPose();
    this.requestRender();
  }

  setCameraPreset(preset: CameraPreset): void {
    this.triggerInteractiveMotion();
    this.cameraController.setPreset(preset, this.isSoftwareGl);
    this.lastTransitionTime = performance.now();
    this.applyCameraPose();
    this.resetAccumulation();
    if (this.isSoftwareGl) this.scheduleMotionSettle();
  }

  moveCameraFree(forward: number, right: number, up: number): void {
    this.triggerInteractiveMotion();
    this.cameraController.moveFree(forward, right, up);
    this.applyCameraPose();
    this.resetAccumulation();
    this.scheduleMotionSettle();
  }

  resetCamera(): void {
    this.triggerInteractiveMotion();
    this.cameraController.reset(this.isSoftwareGl);
    this.lastTransitionTime = performance.now();
    this.applyCameraPose();
    this.resetAccumulation();
    if (this.isSoftwareGl) this.scheduleMotionSettle();
  }

  focusSelected(): void {
    const selectedObj = this.snapshot.selectedId
      ? this.overlayObjects.get(this.snapshot.selectedId)
      : null;
    const center = new THREE.Vector3(0, 0.5, 0);
    let radius = 1.6;
    if (selectedObj) {
      selectedObj.getWorldPosition(center);
      const box = new THREE.Box3().setFromObject(selectedObj);
      const sphere = new THREE.Sphere();
      box.getBoundingSphere(sphere);
      if (Number.isFinite(sphere.radius) && sphere.radius > 0.1) {
        radius = sphere.radius;
      }
    }
    this.triggerInteractiveMotion();
    this.cameraController.focusOn(
      { x: center.x, y: center.y, z: center.z },
      radius,
      this.isSoftwareGl,
    );
    this.lastTransitionTime = performance.now();
    this.applyCameraPose();
    this.resetAccumulation();
    if (this.isSoftwareGl) this.scheduleMotionSettle();
  }

  alignViewToNode(nodeId: string): void {
    const node = this.snapshot.nodes.find((n) => n.id === nodeId);
    const obj = this.overlayObjects.get(nodeId);
    if (!node || !obj) return;
    const worldPos = new THREE.Vector3();
    obj.getWorldPosition(worldPos);
    this.cameraController.alignToPose(
      { x: worldPos.x, y: worldPos.y, z: worldPos.z },
      node.transform.rotation,
    );
    if (node.camera && this.ptCamera) {
      this.ptCamera.fov = node.camera.fov;
      this.ptCamera.near = node.camera.near;
      this.ptCamera.far = node.camera.far;
      this.ptCamera.updateProjectionMatrix();
    }
    this.applyCameraPose();
    this.resetAccumulation();
  }

  getCameraState(): CameraPoseState {
    return this.cameraController.getState();
  }

  setCameraState(state: CameraPoseState): void {
    this.cameraController.setState(state);
    this.applyCameraPose();
    this.resetAccumulation();
  }

  resize(width: number, height: number): void {
    this.viewportSize = { width: Math.max(width, 1), height: Math.max(height, 1) };
    if (!this.renderer || !this.ptCamera) return;
    this.renderer.setPixelRatio(1);
    this.renderer.setSize(this.viewportSize.width, this.viewportSize.height, false);
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.ptCamera.aspect = this.viewportSize.width / this.viewportSize.height;
    this.ptCamera.updateProjectionMatrix();
    this.resizeAccumTargetsForCurrentState();
    this.resetAccumulation();
  }

  getMemoryStats(): EngineMemoryStats {
    return {
      bvhBytes: this.packedScene?.gpuBvh.estimatedGpuBytes ?? 0,
      textureBytes: this.packedScene ? this.packedScene.atlasData.byteLength : 0,
      triangleCount: this.packedScene?.gpuBvh.totalInstancedTriangles ?? 0,
    };
  }

  setPaused(paused: boolean): void {
    this.paused = paused;
    if (!paused) {
      this.requestRender();
    }
  }

  requestRender(): void {
    if (
      this.disposed ||
      this.paused ||
      !this.renderer ||
      !this.ptMaterial ||
      !this.displayMaterial ||
      !this.accumTargets
    ) {
      return;
    }
    if (this.renderBusy) {
      this.renderDirty = true;
      return;
    }
    this.renderBusy = true;

    this.frameId = requestAnimationFrame(() => {
      if (
        this.disposed ||
        !this.renderer ||
        !this.ptMaterial ||
        !this.displayMaterial ||
        !this.accumTargets
      ) {
        this.renderBusy = false;
        return;
      }

      this.renderDirty = false;
      const now = performance.now();
      const dt = Math.min((now - (this.lastTransitionTime || now)) / 1000, 0.05);
      this.lastTransitionTime = now;

      const transitioning = this.cameraController.stepTransition(dt, this.isSoftwareGl);
      if (transitioning) {
        this.applyCameraPose();
        this.sampleIndex = 0;
      }

      const maxSamples = this.getActiveSampleCap();
      const shouldTraceMore = this.sampleIndex < maxSamples;

      if (shouldTraceMore) {
        this.traceSingleSampleIntoAccum(this.sampleIndex);
        this.sampleIndex++;
      }

      this.presentDisplayAndOverlay();
      this.emitStatus(maxSamples);

      const needNextFrame =
        transitioning || this.sampleIndex < maxSamples || this.renderDirty;

      const finish = () => {
        this.renderBusy = false;
        if (!this.disposed && (needNextFrame || this.renderDirty)) {
          this.requestRender();
        }
      };

      if (this.isSoftwareGl) {
        this.afterDraw(finish);
      } else {
        finish();
      }
    });
  }

  /**
   * Chunked/tiled progressive Path Tracing export returning a clean PNG Blob
   * (zero gizmos, grid, or UI overlays) supporting up to 1024 SPP & 4K+ resolution.
   */
  async exportImage(options: ExportImageOptions): Promise<Blob> {
    if (options.signal?.aborted) {
      throw new Error('Export cancelled.');
    }

    const exportW = Math.max(64, Math.round(options.width));
    const exportH = Math.max(64, Math.round(options.height));
    const totalSamples = clampSampleCount(options.samples);

    if (!this.packedScene) {
      this.packedScene = buildPackedSceneForPathTracer(
        this.snapshot,
        this.assetRegistry,
        this.primitiveCache,
      );
    }

    const pose = this.cameraController.getPose();
    const fovDeg = this.ptCamera?.fov ?? this.viewportSettings.fov;

    const exportCanvas = options.targetCanvas ?? document.createElement('canvas');
    if (exportCanvas.width !== exportW || exportCanvas.height !== exportH) {
      exportCanvas.width = exportW;
      exportCanvas.height = exportH;
    }
    const ctx = exportCanvas.getContext('2d');
    if (!ctx) throw new Error('Failed to create 2D export canvas.');

    // Initialize clean scene backdrop on live preview canvas before tiles arrive
    ctx.fillStyle = '#090D16';
    ctx.fillRect(0, 0, exportW, exportH);

    this.paused = true;
    this.emitStatus(totalSamples, 'exporting', 0);

    try {
      await runTiledPathTracingExportSession({
        packedScene: this.packedScene,
        cameraPose: pose,
        fovDeg,
        width: exportW,
        height: exportH,
        samples: totalSamples,
        renderSettings: options.renderSettings,
        pauseController: options.pauseController,
        signal: options.signal,
        onTileOutput: (tile) => {
          const imgData = ctx.createImageData(tile.tw, tile.th);
          imgData.data.set(tile.rgba8);
          ctx.putImageData(imgData, tile.tx, tile.tyTop);
          options.onTileOutput?.(tile);
        },
        onProgress: (ev) => {
          this.emitStatus(ev.totalSamples, 'exporting', ev.currentSample);
          options.onTiledProgress?.(ev);
          options.onProgress?.(ev.progress01, ev.currentSample, ev.totalSamples);
        },
      });

      const blob = await new Promise<Blob>((resolve, reject) => {
        exportCanvas.toBlob(
          (b) => (b ? resolve(b) : reject(new Error('Failed to encode exported PNG.'))),
          'image/png',
        );
      });
      return blob;
    } finally {
      this.paused = false;
      this.emitStatus(this.getActiveSampleCap());
      this.requestRender();
    }
  }

  // --- Internal Pipeline & Resource Helpers ---

  private initFullscreenShaders(): void {
    this.quadGeo?.dispose();
    this.ptMaterial?.dispose();
    this.displayMaterial?.dispose();

    const emptyRGBA32 = new THREE.DataTexture(new Float32Array(4), 1, 1, THREE.RGBAFormat, THREE.FloatType);
    emptyRGBA32.needsUpdate = true;
    const emptyAtlas = new THREE.DataTexture(new Uint8Array(4), 1, 1, THREE.RGBAFormat, THREE.UnsignedByteType);
    emptyAtlas.needsUpdate = true;

    this.ptMaterial = new THREE.ShaderMaterial({
      glslVersion: THREE.GLSL3,
      vertexShader: FULLSCREEN_VERTEX_SHADER,
      fragmentShader: PATH_TRACER_FRAGMENT_SHADER,
      depthTest: false,
      depthWrite: false,
      uniforms: {
        uPrevAccumTex: { value: null },
        uBvhNodesTex: { value: emptyRGBA32 },
        uTriTex: { value: emptyRGBA32 },
        uInstanceTex: { value: emptyRGBA32 },
        uMaterialTex: { value: emptyRGBA32 },
        uLightTex: { value: emptyRGBA32 },
        uAtlasTex: { value: emptyAtlas },
        uBvhNodesWidth: { value: 1 },
        uTriWidth: { value: 1 },
        uInstanceWidth: { value: 1 },
        uMaterialWidth: { value: 1 },
        uInstanceCount: { value: 0 },
        uLightCount: { value: 0 },
        uResolution: { value: new THREE.Vector2(1, 1) },
        uTileOrigin: { value: new THREE.Vector2(0, 0) },
        uSampleIndex: { value: 0 },
        uAccumReset: { value: 0 },
        uOutputSumMode: { value: 0 },
        uMaxBounces: { value: 4 },
        uCamPos: { value: new THREE.Vector3() },
        uCamForward: { value: new THREE.Vector3(0, 0, -1) },
        uCamRight: { value: new THREE.Vector3(1, 0, 0) },
        uCamUp: { value: new THREE.Vector3(0, 1, 0) },
        uTanHalfFov: { value: Math.tan(THREE.MathUtils.degToRad(25)) },
        uAspect: { value: 1 },
        uDofEnabled: { value: 0 },
        uDofFocus: { value: 8 },
        uDofAperture: { value: 0.02 },
        uEnvIntensity: { value: 1 },
      },
    });

    this.displayMaterial = new THREE.ShaderMaterial({
      glslVersion: THREE.GLSL3,
      vertexShader: FULLSCREEN_VERTEX_SHADER,
      fragmentShader: DENOISE_DISPLAY_FRAGMENT_SHADER,
      depthTest: false,
      depthWrite: false,
      uniforms: {
        uAccumTex: { value: null },
        uTexelSize: { value: new THREE.Vector2(1, 1) },
        uSampleCount: { value: 1 },
        uDenoiseStrength: { value: 0.85 },
        uExposure: { value: 1.1 },
        uContrast: { value: 1.0 },
        uGamma: { value: 2.2 },
        uToneMappingMode: { value: 2 },
      },
    });

    this.quadGeo = new THREE.PlaneGeometry(2, 2);
    this.quadMesh = new THREE.Mesh(this.quadGeo, this.ptMaterial);
    this.quadScene.clear();
    this.quadScene.add(this.quadMesh);
  }

  private getEffectiveResolutionScale(): number {
    if (this.isInteracting) {
      return this.isSoftwareGl ? 0.3 : 0.42;
    }
    const s = this.renderSettings;
    const previewMult =
      s.previewQuality === 'low' ? 0.55 : s.previewQuality === 'medium' ? 0.78 : 1.0;
    const perfMult = s.performanceMode ? 0.7 : 1.0;
    const base = this.isSoftwareGl ? 0.55 : 0.92;
    return THREE.MathUtils.clamp(base * s.renderScale * previewMult * perfMult, 0.25, 1.35);
  }

  private getActiveSampleCap(): number {
    if (this.isInteracting) return 5;
    if (this.renderSettings.performanceMode || this.renderSettings.renderQuality === 'draft') {
      return this.isSoftwareGl ? 16 : 32;
    }
    if (this.renderSettings.renderQuality === 'high') {
      return this.isSoftwareGl ? 32 : 96;
    }
    return this.isSoftwareGl ? 24 : 64;
  }

  private createAccumTargets(cssWidth: number, cssHeight: number): void {
    this.disposeAccumTargets();
    const scale = this.getEffectiveResolutionScale();
    const w = Math.max(64, Math.round(cssWidth * scale));
    const h = Math.max(64, Math.round(cssHeight * scale));
    this.accumSize = { width: w, height: h };

    const texType = this.hasFloatColorBuffer ? THREE.FloatType : THREE.HalfFloatType;
    const opts: THREE.RenderTargetOptions = {
      type: texType,
      format: THREE.RGBAFormat,
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      depthBuffer: false,
      stencilBuffer: false,
    };
    this.accumTargets = [
      new THREE.WebGLRenderTarget(w, h, opts),
      new THREE.WebGLRenderTarget(w, h, opts),
    ];
    this.accumWriteIdx = 0;
  }

  private resizeAccumTargetsForCurrentState(): void {
    if (!this.accumTargets) {
      this.createAccumTargets(this.viewportSize.width, this.viewportSize.height);
      return;
    }
    const scale = this.getEffectiveResolutionScale();
    const nextW = Math.max(64, Math.round(this.viewportSize.width * scale));
    const nextH = Math.max(64, Math.round(this.viewportSize.height * scale));
    if (nextW !== this.accumSize.width || nextH !== this.accumSize.height) {
      this.accumSize = { width: nextW, height: nextH };
      this.accumTargets[0].setSize(nextW, nextH);
      this.accumTargets[1].setSize(nextW, nextH);
    }
  }

  private disposeAccumTargets(): void {
    if (this.accumTargets) {
      this.accumTargets[0].dispose();
      this.accumTargets[1].dispose();
      this.accumTargets = null;
    }
  }

  private triggerInteractiveMotion(): void {
    window.clearTimeout(this.interactionTimer);
    if (!this.isInteracting) {
      this.isInteracting = true;
      this.resizeAccumTargetsForCurrentState();
      this.emitStatus(this.getActiveSampleCap());
    }
  }

  private scheduleMotionSettle(): void {
    window.clearTimeout(this.interactionTimer);
    this.interactionTimer = window.setTimeout(() => {
      if (this.disposed) return;
      this.isInteracting = false;
      this.resizeAccumTargetsForCurrentState();
      this.resetAccumulation();
    }, 220);
  }

  private resetAccumulation(): void {
    this.sampleIndex = 0;
    this.accumWriteIdx = 0;
    this.emitStatus(this.getActiveSampleCap());
    this.requestRender();
  }

  private rebuildGpuScene(): void {
    this.disposeGpuTextures();
    const packed = buildPackedSceneForPathTracer(
      this.snapshot,
      this.assetRegistry,
      this.primitiveCache,
    );
    this.packedScene = packed;

    const makeFloatTex = (data: Float32Array, w: number, h: number) => {
      const tex = new THREE.DataTexture(data, w, h, THREE.RGBAFormat, THREE.FloatType);
      tex.minFilter = THREE.NearestFilter;
      tex.magFilter = THREE.NearestFilter;
      tex.generateMipmaps = false;
      tex.needsUpdate = true;
      return tex;
    };

    this.bvhNodesTex = makeFloatTex(
      packed.gpuBvh.bvhNodesData,
      packed.gpuBvh.bvhNodesWidth,
      packed.gpuBvh.bvhNodesHeight,
    );
    this.triTex = makeFloatTex(
      packed.gpuBvh.triData,
      packed.gpuBvh.triWidth,
      packed.gpuBvh.triHeight,
    );
    this.instanceTex = makeFloatTex(
      packed.gpuBvh.instanceData,
      packed.gpuBvh.instanceWidth,
      packed.gpuBvh.instanceHeight,
    );
    this.materialTex = makeFloatTex(
      packed.materialsData,
      packed.materialsWidth,
      packed.materialsHeight,
    );
    this.lightTex = makeFloatTex(packed.lightsData, 16 * 6, 1);

    const atlas = new THREE.DataTexture(
      packed.atlasData,
      packed.atlasWidth,
      packed.atlasHeight,
      THREE.RGBAFormat,
      THREE.UnsignedByteType,
    );
    atlas.minFilter = THREE.LinearFilter;
    atlas.magFilter = THREE.LinearFilter;
    atlas.generateMipmaps = false;
    atlas.needsUpdate = true;
    this.atlasTex = atlas;

    if (this.ptMaterial) {
      this.bindSceneUniforms(this.ptMaterial);
    }
  }

  private bindSceneUniforms(mat: THREE.ShaderMaterial): void {
    const packed = this.packedScene;
    if (!packed) return;
    mat.uniforms.uBvhNodesTex.value = this.bvhNodesTex;
    mat.uniforms.uTriTex.value = this.triTex;
    mat.uniforms.uInstanceTex.value = this.instanceTex;
    mat.uniforms.uMaterialTex.value = this.materialTex;
    mat.uniforms.uLightTex.value = this.lightTex;
    mat.uniforms.uAtlasTex.value = this.atlasTex;
    mat.uniforms.uBvhNodesWidth.value = packed.gpuBvh.bvhNodesWidth;
    mat.uniforms.uTriWidth.value = packed.gpuBvh.triWidth;
    mat.uniforms.uInstanceWidth.value = packed.gpuBvh.instanceWidth;
    mat.uniforms.uMaterialWidth.value = packed.materialsWidth;
    mat.uniforms.uInstanceCount.value = packed.gpuBvh.instanceCount;
    mat.uniforms.uLightCount.value = packed.lightCount;
  }

  private disposeGpuTextures(): void {
    this.bvhNodesTex?.dispose();
    this.triTex?.dispose();
    this.instanceTex?.dispose();
    this.materialTex?.dispose();
    this.lightTex?.dispose();
    this.atlasTex?.dispose();
    this.bvhNodesTex = null;
    this.triTex = null;
    this.instanceTex = null;
    this.materialTex = null;
    this.lightTex = null;
    this.atlasTex = null;
  }

  private traceSingleSampleIntoAccum(sampleIdx: number): void {
    if (!this.renderer || !this.ptMaterial || !this.accumTargets || !this.quadMesh) return;

    const readRt = this.accumTargets[1 - this.accumWriteIdx];
    const writeRt = this.accumTargets[this.accumWriteIdx];
    const pose = this.cameraController.getPose();
    const fovRad = THREE.MathUtils.degToRad(this.ptCamera?.fov ?? this.viewportSettings.fov);

    this.quadMesh.material = this.ptMaterial;
    this.ptMaterial.uniforms.uPrevAccumTex.value = readRt.texture;
    this.ptMaterial.uniforms.uResolution.value.set(this.accumSize.width, this.accumSize.height);
    this.ptMaterial.uniforms.uTileOrigin.value.set(0, 0);
    this.ptMaterial.uniforms.uSampleIndex.value = sampleIdx;
    this.ptMaterial.uniforms.uAccumReset.value = sampleIdx === 0 ? 1 : 0;
    this.ptMaterial.uniforms.uOutputSumMode.value = 0;
    this.ptMaterial.uniforms.uMaxBounces.value = this.isInteracting ? 2 : 4;
    this.ptMaterial.uniforms.uCamPos.value.set(pose.position.x, pose.position.y, pose.position.z);
    this.ptMaterial.uniforms.uCamForward.value.set(pose.forward.x, pose.forward.y, pose.forward.z);
    this.ptMaterial.uniforms.uCamRight.value.set(pose.right.x, pose.right.y, pose.right.z);
    this.ptMaterial.uniforms.uCamUp.value.set(pose.up.x, pose.up.y, pose.up.z);
    this.ptMaterial.uniforms.uTanHalfFov.value = Math.tan(fovRad * 0.5);
    this.ptMaterial.uniforms.uAspect.value =
      this.viewportSize.width / Math.max(this.viewportSize.height, 1);
    this.ptMaterial.uniforms.uDofEnabled.value =
      this.renderSettings.dofEnabled && !this.isInteracting ? 1 : 0;
    this.ptMaterial.uniforms.uDofFocus.value = this.renderSettings.dofFocusDistance;
    this.ptMaterial.uniforms.uDofAperture.value = this.renderSettings.dofAperture * 2.5;
    this.ptMaterial.uniforms.uEnvIntensity.value =
      this.renderSettings.textureQuality === 'low'
        ? 0.7
        : this.renderSettings.textureQuality === 'medium'
          ? 0.9
          : 1.05;

    this.renderer.setRenderTarget(writeRt);
    this.renderer.setViewport(0, 0, this.accumSize.width, this.accumSize.height);
    this.renderer.render(this.quadScene, this.quadCamera);
    this.renderer.setRenderTarget(null);

    this.accumWriteIdx = 1 - this.accumWriteIdx;
  }

  private presentDisplayAndOverlay(): void {
    if (
      !this.renderer ||
      !this.displayMaterial ||
      !this.accumTargets ||
      !this.quadMesh ||
      !this.overlayScene ||
      !this.ptCamera
    ) {
      return;
    }

    const latestRt = this.accumTargets[1 - this.accumWriteIdx];
    this.quadMesh.material = this.displayMaterial;
    this.displayMaterial.uniforms.uAccumTex.value = latestRt.texture;
    this.displayMaterial.uniforms.uTexelSize.value.set(
      1 / Math.max(this.accumSize.width, 1),
      1 / Math.max(this.accumSize.height, 1),
    );
    this.displayMaterial.uniforms.uSampleCount.value = Math.max(1, this.sampleIndex);
    this.displayMaterial.uniforms.uDenoiseStrength.value = this.isInteracting ? 0.95 : 0.85;
    this.displayMaterial.uniforms.uExposure.value = this.renderSettings.exposure;
    this.displayMaterial.uniforms.uContrast.value = this.renderSettings.contrast;
    this.displayMaterial.uniforms.uGamma.value = this.renderSettings.gamma;
    this.displayMaterial.uniforms.uToneMappingMode.value =
      this.renderSettings.renderQuality === 'draft'
        ? 0
        : this.renderSettings.renderQuality === 'standard'
          ? 1
          : 2;

    this.renderer.setRenderTarget(null);
    this.renderer.setViewport(0, 0, this.viewportSize.width, this.viewportSize.height);
    this.renderer.clear(true, true, true);
    this.renderer.render(this.quadScene, this.quadCamera);

    // Clear depth buffer only so Gizmo, Grid, and Light proxies render cleanly on top
    this.renderer.clearDepth();
    this.renderer.render(this.overlayScene, this.ptCamera);
  }

  private rebuildOverlayScene(snapshot: SceneSnapshot): void {
    this.disposeOverlayObjects();
    const worldMatrices = computeNodeWorldMatrices(snapshot.nodes);
    const posTmp = new THREE.Vector3();
    const quatTmp = new THREE.Quaternion();
    const scaleTmp = new THREE.Vector3();

    for (const node of snapshot.nodes) {
      let proxyObj: THREE.Object3D | null = null;

      if (isLightNodeType(node.type)) {
        const g = new THREE.Group();
        const col = node.light?.color ?? '#FDE047';
        const marker = new THREE.Mesh(
          new THREE.OctahedronGeometry(0.18, 0),
          new THREE.MeshBasicMaterial({ color: col, wireframe: true }),
        );
        marker.userData.nodeId = node.id;
        g.add(marker);
        proxyObj = g;
      } else if (node.type === 'camera') {
        const g = new THREE.Group();
        const camBox = new THREE.Mesh(
          new THREE.BoxGeometry(0.38, 0.24, 0.48),
          new THREE.MeshBasicMaterial({ color: '#38BDF8', wireframe: true }),
        );
        camBox.userData.nodeId = node.id;
        g.add(camBox);
        proxyObj = g;
      } else {
        // Empty anchor object matching node transform so TransformControls & BoxHelper work accurately
        const g = new THREE.Group();
        const box = this.computeOverlayBoundsForNode(node);
        const helperMesh = new THREE.Mesh(
          new THREE.BoxGeometry(
            Math.max(box.x, 0.2),
            Math.max(box.y, 0.2),
            Math.max(box.z, 0.2),
          ),
          new THREE.MeshBasicMaterial({ visible: false }),
        );
        helperMesh.userData.nodeId = node.id;
        g.add(helperMesh);
        proxyObj = g;
      }

      if (!proxyObj) continue;
      proxyObj.userData.nodeId = node.id;
      proxyObj.visible = node.visible;
      const worldM = worldMatrices.get(node.id) ?? new THREE.Matrix4();
      worldM.decompose(posTmp, quatTmp, scaleTmp);
      proxyObj.position.copy(posTmp);
      proxyObj.quaternion.copy(quatTmp);
      proxyObj.scale.copy(scaleTmp);

      this.overlayRoot.add(proxyObj);
      this.overlayObjects.set(node.id, proxyObj);
    }
  }

  private computeOverlayBoundsForNode(node: SceneNode): THREE.Vector3 {
    if (node.type === 'model' && node.modelAsset && this.assetRegistry) {
      const asset = this.assetRegistry.get(node.modelAsset.assetId);
      if (asset) {
        const b = new THREE.Box3().setFromObject(asset.rootObject);
        const s = new THREE.Vector3();
        b.getSize(s);
        return s;
      }
    }
    if (node.type === 'plane') return new THREE.Vector3(1, 0.05, 1);
    return new THREE.Vector3(1, 1, 1);
  }

  private disposeOverlayObjects(): void {
    this.transformControls?.detach();
    for (const obj of this.overlayObjects.values()) {
      obj.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          const m = child as THREE.Mesh;
          m.geometry?.dispose();
          if (Array.isArray(m.material)) {
            m.material.forEach((mt) => mt.dispose());
          } else {
            m.material?.dispose();
          }
        }
      });
    }
    this.overlayObjects.clear();
    this.overlayRoot.clear();
  }

  private updateSelectionHelper(): void {
    if (!this.selectionHelper) return;
    const selectedId = this.snapshot.selectedId;
    if (!selectedId || !this.overlayObjects.has(selectedId)) {
      this.selectionHelper.visible = false;
      return;
    }
    const obj = this.overlayObjects.get(selectedId)!;
    this.selectionHelper.setFromObject(obj);
    this.selectionHelper.visible = obj.visible;
  }

  private applyCameraPose(): void {
    if (!this.ptCamera) return;
    const pose = this.cameraController.getPose();
    this.ptCamera.position.set(pose.position.x, pose.position.y, pose.position.z);
    this.ptCamera.quaternion.set(
      pose.orientation.x,
      pose.orientation.y,
      pose.orientation.z,
      pose.orientation.w,
    );
    this.ptCamera.up.set(pose.up.x, pose.up.y, pose.up.z);
    this.ptCamera.updateMatrixWorld();

    if (this.renderer) {
      const dom = this.renderer.domElement;
      dom.dataset.cameraMode = pose.mode;
      dom.dataset.cameraPitchDeg = String(Math.round((pose.pitch * 180) / Math.PI));
      dom.dataset.cameraYawDeg = String(Math.round((pose.yaw * 180) / Math.PI));
    }
  }

  private applyRenderSettingsAttributes(): void {
    if (!this.renderer) return;
    const dom = this.renderer.domElement;
    const s = this.renderSettings;
    dom.dataset.renderScale = String(s.renderScale);
    dom.dataset.exposure = String(s.exposure);
    dom.dataset.gamma = String(s.gamma);
    dom.dataset.contrast = String(s.contrast);
  }

  private emitStatus(
    targetSamples: number,
    overrideMode?: PathTracerStatus['mode'],
    overrideSamples?: number,
  ): void {
    const mode: PathTracerStatus['mode'] =
      overrideMode ??
      (this.isInteracting
        ? 'interactive'
        : this.sampleIndex < targetSamples
          ? 'converging'
          : 'idle');
    const samples = overrideSamples ?? this.sampleIndex;
    const scale = this.getEffectiveResolutionScale();

    if (this.renderer) {
      const dom = this.renderer.domElement;
      dom.dataset.ptMode = mode;
      dom.dataset.ptSamples = String(samples);
      dom.dataset.ptSampleCap = String(targetSamples);
      dom.dataset.ptScale = scale.toFixed(2);
    }

    this.callbacks?.onPathTracerStatus?.({
      mode,
      samples,
      targetSamples,
      sampleCap: targetSamples,
      resolutionScale: scale,
      triangleCount: this.packedScene?.gpuBvh.totalInstancedTriangles ?? 0,
      bvhMemoryBytes: this.packedScene?.gpuBvh.estimatedGpuBytes ?? 0,
    });
  }

  private extractTransform(obj: THREE.Object3D): TransformData {
    return {
      position: {
        x: round3(obj.position.x),
        y: round3(obj.position.y),
        z: round3(obj.position.z),
      },
      rotation: {
        x: round3(THREE.MathUtils.radToDeg(obj.rotation.x)),
        y: round3(THREE.MathUtils.radToDeg(obj.rotation.y)),
        z: round3(THREE.MathUtils.radToDeg(obj.rotation.z)),
      },
      scale: {
        x: round3(obj.scale.x),
        y: round3(obj.scale.y),
        z: round3(obj.scale.z),
      },
    };
  }

  private pickAtPointer(event: PointerEvent): void {
    if (!this.renderer || !this.ptCamera) return;
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointerVec.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.pointerVec.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.pointerVec, this.ptCamera);
    const ray = this.raycaster.ray;

    // 1. Check exact BVH mesh triangles first
    let bestT = Infinity;
    let pickedNodeId: string | null = null;
    if (this.packedScene) {
      const hit = intersectRayTLAS(
        this.packedScene.bvh,
        [ray.origin.x, ray.origin.y, ray.origin.z],
        [ray.direction.x, ray.direction.y, ray.direction.z],
      );
      if (hit) {
        bestT = hit.t;
        const inst = this.packedScene.bvh.instances.find(
          (i) => i.instanceIndex === hit.instanceIndex,
        );
        pickedNodeId = inst?.nodeId ?? null;
      }
    }

    // 2. Also check light & camera proxy spheres/markers in overlay
    const lightOrCamProxies: THREE.Object3D[] = [];
    for (const node of this.snapshot.nodes) {
      if (node.visible && (isLightNodeType(node.type) || node.type === 'camera')) {
        const obj = this.overlayObjects.get(node.id);
        if (obj) lightOrCamProxies.push(obj);
      }
    }
    if (lightOrCamProxies.length > 0) {
      const hits = this.raycaster.intersectObjects(lightOrCamProxies, true);
      if (hits.length > 0 && hits[0].distance < bestT) {
        let curr: THREE.Object3D | null = hits[0].object;
        while (curr && !curr.userData.nodeId) curr = curr.parent;
        if (curr?.userData.nodeId) {
          pickedNodeId = String(curr.userData.nodeId);
        }
      }
    }

    this.callbacks?.onNodeSelected(pickedNodeId);
  }

  private afterDraw(cb: () => void): void {
    if (!this.renderer) {
      cb();
      return;
    }
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 65);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync ? gl.getSyncParameter(sync, gl.SYNC_STATUS) : gl.SIGNALED;
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 45);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }
}

function round3(value: number): number {
  return Math.round(value * 1000) / 1000;
}
