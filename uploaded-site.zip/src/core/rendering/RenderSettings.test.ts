import test from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULT_RENDER_SETTINGS, RenderSettingsManager } from './RenderSettings';

test('RenderSettingsManager clamps out-of-range values and applies presets', () => {
  const manager = new RenderSettingsManager();
  assert.equal(manager.getSettings().gamma, DEFAULT_RENDER_SETTINGS.gamma);

  const updated = manager.update({
    exposure: 10,
    gamma: 0.2,
    contrast: 5,
    renderScale: 0.1,
    bloomEnabled: true,
  });

  assert.equal(updated.exposure, 2.2);
  assert.equal(updated.gamma, 1.4);
  assert.equal(updated.contrast, 1.8);
  assert.equal(updated.renderScale, 0.5);
  assert.equal(updated.bloomEnabled, true);

  const perf = manager.applyPreset('performance');
  assert.equal(perf.performanceMode, true);
  assert.equal(perf.shadowResolution, 512);
  assert.equal(perf.bloomEnabled, false);

  const reset = manager.reset();
  assert.deepEqual(reset, DEFAULT_RENDER_SETTINGS);
});
