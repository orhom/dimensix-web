import * as THREE from 'three';
import {
  buildCenterFirstTiles,
  probeDeviceGraphicsCapabilities,
  type ExportMemoryPlan,
  type TileRect,
  planExportMemoryBudget,
} from './MemoryBudget';
import { FULLSCREEN_VERTEX_SHADER, PATH_TRACER_FRAGMENT_SHADER } from './PathTracingShaders';
import type { PackedSceneForPathTracer } from './SceneBridge';
import type { RenderSettings } from './RenderSettings';
import {
  resolveTileToRgba8,
  TileAccumulationStore,
  type TilePostProcessParams,
} from './TileAccumulationCore';
import type {
  TileWorkerRequest,
  WorkerTileResultResponse,
} from './workers/TilePostProcessWorker';
import type {
  CpuTraceTileRequest,
  CpuTraceTileResponse,
} from './workers/CpuPathTracerWorker';

export interface TiledExportProgressEvent {
  progress01: number;
  currentSample: number;
  totalSamples: number;
  completedTilesInPass: number;
  totalTiles: number;
  samplesPerSec: number;
  elapsedMs: number;
  activeTile: TileRect | null;
  completedTileIndices: ReadonlySet<number>;
  engineModeLabel: 'GPU WebGL2' | 'CPU BVH Worker';
  strategy: ExportMemoryPlan['strategy'];
}

export interface TileOutputUpdate {
  tx: number;
  tyTop: number;
  tw: number;
  th: number;
  rgba8: Uint8ClampedArray;
  tileIndex: number;
  tileSamples: number;
}

export interface ExportPauseController {
  isPaused: () => boolean;
  waitWhilePaused: (signal?: AbortSignal) => Promise<void>;
}

export interface TiledExportSessionInput {
  packedScene: PackedSceneForPathTracer;
  cameraPose: {
    position: { x: number; y: number; z: number };
    forward: { x: number; y: number; z: number };
    right: { x: number; y: number; z: number };
    up: { x: number; y: number; z: number };
  };
  fovDeg: number;
  width: number;
  height: number;
  samples: number;
  renderSettings: RenderSettings;
  onTileOutput: (tile: TileOutputUpdate) => void;
  onProgress: (event: TiledExportProgressEvent) => void;
  pauseController?: ExportPauseController;
  signal?: AbortSignal;
}

function makeFloatTex(data: Float32Array, w: number, h: number): THREE.DataTexture {
  const tex = new THREE.DataTexture(data, w, h, THREE.RGBAFormat, THREE.FloatType);
  tex.minFilter = THREE.NearestFilter;
  tex.magFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;
  tex.needsUpdate = true;
  return tex;
}

async function yieldToBrowser(): Promise<void> {
  await new Promise<void>((resolve) => {
    setTimeout(resolve, 0);
  });
}

class PostProcessWorkerBridge {
  private worker: Worker | null = null;
  private localFallback = new TileAccumulationStore();
  private reqCounter = 1;
  private pending = new Map<
    number,
    { resolve: (res: WorkerTileResultResponse) => void; reject: (err: Error) => void }
  >();

  constructor(private readonly jobId: string) {
    if (typeof Worker !== 'undefined') {
      try {
        this.worker = new Worker(
          new URL('./workers/TilePostProcessWorker.ts', import.meta.url),
          { type: 'module' },
        );
        this.worker.onmessage = (ev: MessageEvent<WorkerTileResultResponse>) => {
          const msg = ev.data;
          if (msg.type !== 'tileResult') return;
          const entry = this.pending.get(msg.requestId);
          if (entry) {
            this.pending.delete(msg.requestId);
            entry.resolve(msg);
          }
        };
        this.worker.onerror = (err) => {
          const e = new Error(err.message || 'Tile post-process worker failed');
          for (const entry of this.pending.values()) entry.reject(e);
          this.pending.clear();
        };
      } catch {
        this.worker = null;
      }
    }
  }

  async processTileBatch(
    tileKey: string,
    tx: number,
    tyTop: number,
    tw: number,
    th: number,
    batchSamples: number,
    incomingRgba: Float32Array,
    incomingIsSum: boolean,
    flipY: boolean,
    params: TilePostProcessParams,
  ): Promise<{ rgba8: Uint8ClampedArray; tileSampleCount: number }> {
    if (!this.worker) {
      const slot = this.localFallback.accumulateTileBatch(
        tileKey,
        tw,
        th,
        batchSamples,
        incomingRgba,
        incomingIsSum,
        flipY,
      );
      return {
        rgba8: resolveTileToRgba8(slot, params),
        tileSampleCount: slot.sampleCount,
      };
    }

    const requestId = this.reqCounter++;
    const req: TileWorkerRequest = {
      type: 'accumulateTile',
      requestId,
      jobId: this.jobId,
      tileKey,
      tx,
      tyTop,
      tw,
      th,
      batchSamples,
      incomingIsSum,
      flipY,
      incomingRgba,
      params,
    };

    const res = await new Promise<WorkerTileResultResponse>((resolve, reject) => {
      this.pending.set(requestId, { resolve, reject });
      this.worker!.postMessage(req, [incomingRgba.buffer]);
    });

    return {
      rgba8: res.rgba8,
      tileSampleCount: res.tileSampleCount,
    };
  }

  releaseTile(tileKey: string): void {
    if (this.worker) {
      const req: TileWorkerRequest = {
        type: 'releaseTile',
        jobId: this.jobId,
        tileKey,
      };
      this.worker.postMessage(req);
    } else {
      this.localFallback.releaseTile(tileKey);
    }
  }

  dispose(): void {
    for (const entry of this.pending.values()) {
      entry.reject(new Error('Export cancelled.'));
    }
    this.pending.clear();
    if (this.worker) {
      const req: TileWorkerRequest = { type: 'disposeJob', jobId: this.jobId };
      this.worker.postMessage(req);
      this.worker.terminate();
      this.worker = null;
    }
    this.localFallback.clear();
  }
}

class GpuTileRayTracer {
  private renderer: THREE.WebGLRenderer | null = null;
  private quadScene = new THREE.Scene();
  private quadCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  private quadGeo: THREE.PlaneGeometry | null = null;
  private quadMesh: THREE.Mesh | null = null;
  private ptMaterial: THREE.ShaderMaterial | null = null;
  private pingRt: THREE.WebGLRenderTarget | null = null;
  private pongRt: THREE.WebGLRenderTarget | null = null;
  private textures: THREE.DataTexture[] = [];
  private fboWidth = 0;
  private fboHeight = 0;

  init(packed: PackedSceneForPathTracer, maxTileSize: number): boolean {
    try {
      const renderer = new THREE.WebGLRenderer({
        antialias: false,
        alpha: false,
        depth: false,
        stencil: false,
        powerPreference: 'high-performance',
        preserveDrawingBuffer: false,
      });
      renderer.autoClear = false;
      renderer.setPixelRatio(1);
      renderer.setSize(maxTileSize, maxTileSize, false);
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || !gl.getExtension('EXT_color_buffer_float')) {
        renderer.dispose();
        gl?.getExtension('WEBGL_lose_context')?.loseContext();
        return false;
      }

      const rtOpts: THREE.RenderTargetOptions = {
        type: THREE.FloatType,
        format: THREE.RGBAFormat,
        minFilter: THREE.NearestFilter,
        magFilter: THREE.NearestFilter,
        depthBuffer: false,
        stencilBuffer: false,
      };
      this.pingRt = new THREE.WebGLRenderTarget(maxTileSize, maxTileSize, rtOpts);
      this.pongRt = new THREE.WebGLRenderTarget(maxTileSize, maxTileSize, rtOpts);
      this.fboWidth = maxTileSize;
      this.fboHeight = maxTileSize;

      // Verify FBO completeness + Float readPixels support upfront
      renderer.setRenderTarget(this.pingRt);
      const status = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
      renderer.setRenderTarget(null);
      if (status !== gl.FRAMEBUFFER_COMPLETE) {
        this.pingRt.dispose();
        this.pongRt.dispose();
        renderer.dispose();
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return false;
      }

      const bvhTex = makeFloatTex(
        packed.gpuBvh.bvhNodesData,
        packed.gpuBvh.bvhNodesWidth,
        packed.gpuBvh.bvhNodesHeight,
      );
      const triTex = makeFloatTex(
        packed.gpuBvh.triData,
        packed.gpuBvh.triWidth,
        packed.gpuBvh.triHeight,
      );
      const instTex = makeFloatTex(
        packed.gpuBvh.instanceData,
        packed.gpuBvh.instanceWidth,
        packed.gpuBvh.instanceHeight,
      );
      const matTex = makeFloatTex(
        packed.materialsData,
        packed.materialsWidth,
        packed.materialsHeight,
      );
      const lightTex = makeFloatTex(packed.lightsData, 16 * 6, 1);
      const atlasTex = new THREE.DataTexture(
        packed.atlasData,
        packed.atlasWidth,
        packed.atlasHeight,
        THREE.RGBAFormat,
        THREE.UnsignedByteType,
      );
      atlasTex.minFilter = THREE.LinearFilter;
      atlasTex.magFilter = THREE.LinearFilter;
      atlasTex.generateMipmaps = false;
      atlasTex.needsUpdate = true;

      this.textures = [bvhTex, triTex, instTex, matTex, lightTex, atlasTex];

      this.ptMaterial = new THREE.ShaderMaterial({
        glslVersion: THREE.GLSL3,
        vertexShader: FULLSCREEN_VERTEX_SHADER,
        fragmentShader: PATH_TRACER_FRAGMENT_SHADER,
        depthTest: false,
        depthWrite: false,
        uniforms: {
          uPrevAccumTex: { value: null },
          uBvhNodesTex: { value: bvhTex },
          uTriTex: { value: triTex },
          uInstanceTex: { value: instTex },
          uMaterialTex: { value: matTex },
          uLightTex: { value: lightTex },
          uAtlasTex: { value: atlasTex },
          uBvhNodesWidth: { value: packed.gpuBvh.bvhNodesWidth },
          uTriWidth: { value: packed.gpuBvh.triWidth },
          uInstanceWidth: { value: packed.gpuBvh.instanceWidth },
          uMaterialWidth: { value: packed.materialsWidth },
          uInstanceCount: { value: packed.gpuBvh.instanceCount },
          uLightCount: { value: packed.lightCount },
          uResolution: { value: new THREE.Vector2(1, 1) },
          uTileOrigin: { value: new THREE.Vector2(0, 0) },
          uSampleIndex: { value: 0 },
          uAccumReset: { value: 0 },
          uOutputSumMode: { value: 1 },
          uMaxBounces: { value: 5 },
          uCamPos: { value: new THREE.Vector3() },
          uCamForward: { value: new THREE.Vector3() },
          uCamRight: { value: new THREE.Vector3() },
          uCamUp: { value: new THREE.Vector3() },
          uTanHalfFov: { value: 0.46 },
          uAspect: { value: 1 },
          uDofEnabled: { value: 0 },
          uDofFocus: { value: 8 },
          uDofAperture: { value: 0.02 },
          uEnvIntensity: { value: 1 },
        },
      });

      this.quadGeo = new THREE.PlaneGeometry(2, 2);
      this.quadMesh = new THREE.Mesh(this.quadGeo, this.ptMaterial);
      this.quadScene.clear();
      this.quadScene.add(this.quadMesh);
      this.renderer = renderer;
      return true;
    } catch {
      this.dispose();
      return false;
    }
  }

  configureCameraAndScene(input: TiledExportSessionInput): void {
    if (!this.ptMaterial) return;
    const u = this.ptMaterial.uniforms;
    const fovRad = THREE.MathUtils.degToRad(input.fovDeg);
    u.uResolution.value.set(input.width, input.height);
    u.uOutputSumMode.value = 1;
    u.uMaxBounces.value = 5;
    u.uCamPos.value.set(
      input.cameraPose.position.x,
      input.cameraPose.position.y,
      input.cameraPose.position.z,
    );
    u.uCamForward.value.set(
      input.cameraPose.forward.x,
      input.cameraPose.forward.y,
      input.cameraPose.forward.z,
    );
    u.uCamRight.value.set(
      input.cameraPose.right.x,
      input.cameraPose.right.y,
      input.cameraPose.right.z,
    );
    u.uCamUp.value.set(
      input.cameraPose.up.x,
      input.cameraPose.up.y,
      input.cameraPose.up.z,
    );
    u.uTanHalfFov.value = Math.tan(fovRad * 0.5);
    u.uAspect.value = input.width / Math.max(1, input.height);
    u.uDofEnabled.value = input.renderSettings.dofEnabled ? 1 : 0;
    u.uDofFocus.value = input.renderSettings.dofFocusDistance;
    u.uDofAperture.value = input.renderSettings.dofAperture * 2.5;
    u.uEnvIntensity.value =
      input.renderSettings.textureQuality === 'low'
        ? 0.7
        : input.renderSettings.textureQuality === 'medium'
          ? 0.9
          : 1.05;
  }

  traceTileBatch(
    tile: TileRect,
    exportHeight: number,
    startSample: number,
    batchSamples: number,
  ): Float32Array {
    if (!this.renderer || !this.ptMaterial || !this.pingRt || !this.pongRt) {
      throw new Error('GPU tile raytracer is not initialized.');
    }

    const glTileY = exportHeight - (tile.tyTop + tile.th);
    this.ptMaterial.uniforms.uTileOrigin.value.set(tile.tx, glTileY);

    let readRt = this.pingRt;
    let writeRt = this.pongRt;

    for (let s = 0; s < batchSamples; s++) {
      this.ptMaterial.uniforms.uPrevAccumTex.value = readRt.texture;
      this.ptMaterial.uniforms.uSampleIndex.value = startSample + s;
      this.ptMaterial.uniforms.uAccumReset.value = s === 0 ? 1 : 0;

      this.renderer.setRenderTarget(writeRt);
      this.renderer.setViewport(0, 0, tile.tw, tile.th);
      this.renderer.setScissorTest(true);
      this.renderer.setScissor(0, 0, tile.tw, tile.th);
      this.renderer.render(this.quadScene, this.quadCamera);

      const tmp = readRt;
      readRt = writeRt;
      writeRt = tmp;
    }

    this.renderer.setScissorTest(false);

    // readRt now holds the sum of batchSamples in region [0..tw, 0..th]
    const outFloats = new Float32Array(tile.tw * tile.th * 4);
    this.renderer.readRenderTargetPixels(readRt, 0, 0, tile.tw, tile.th, outFloats);
    this.renderer.setRenderTarget(null);

    if (outFloats.length !== tile.tw * tile.th * 4 || this.fboWidth < tile.tw || this.fboHeight < tile.th) {
      throw new Error('Unexpected tile pixel buffer size.');
    }

    return outFloats;
  }

  dispose(): void {
    this.pingRt?.dispose();
    this.pongRt?.dispose();
    this.pingRt = null;
    this.pongRt = null;
    for (const tex of this.textures) tex.dispose();
    this.textures = [];
    this.quadGeo?.dispose();
    this.ptMaterial?.dispose();
    this.quadGeo = null;
    this.ptMaterial = null;
    this.quadMesh = null;
    if (this.renderer) {
      const gl = this.renderer.getContext();
      this.renderer.dispose();
      gl?.getExtension('WEBGL_lose_context')?.loseContext();
      this.renderer = null;
    }
  }
}

class CpuWorkerTracerBridge {
  private worker: Worker | null = null;
  private reqId = 1;
  private pending = new Map<
    number,
    { resolve: (buf: Float32Array) => void; reject: (err: Error) => void }
  >();

  constructor(private readonly jobId: string) {}

  init(packed: PackedSceneForPathTracer): boolean {
    if (typeof Worker === 'undefined') return false;
    try {
      this.worker = new Worker(
        new URL('./workers/CpuPathTracerWorker.ts', import.meta.url),
        { type: 'module' },
      );
      this.worker.onmessage = (ev: MessageEvent<CpuTraceTileResponse>) => {
        const msg = ev.data;
        if (msg.type !== 'tracedTile') return;
        const entry = this.pending.get(msg.requestId);
        if (entry) {
          this.pending.delete(msg.requestId);
          entry.resolve(msg.sumRgba);
        }
      };
      this.worker.onerror = (err) => {
        const e = new Error(err.message || 'CPU path tracer worker error');
        for (const p of this.pending.values()) p.reject(e);
        this.pending.clear();
      };

      const initMsg: CpuTraceTileRequest = {
        type: 'initScene',
        jobId: this.jobId,
        scene: {
          bvhNodesData: packed.gpuBvh.bvhNodesData,
          triData: packed.gpuBvh.triData,
          instanceData: packed.gpuBvh.instanceData,
          materialsData: packed.materialsData,
          lightsData: packed.lightsData,
          atlasData: packed.atlasData,
          atlasWidth: packed.atlasWidth,
          atlasHeight: packed.atlasHeight,
          instanceCount: packed.gpuBvh.instanceCount,
          lightCount: packed.lightCount,
        },
      };
      this.worker.postMessage(initMsg);
      return true;
    } catch {
      return false;
    }
  }

  async traceTileBatch(
    tile: TileRect,
    input: TiledExportSessionInput,
    startSample: number,
    batchSamples: number,
  ): Promise<Float32Array> {
    if (!this.worker) throw new Error('CPU Worker unavailable');
    const requestId = this.reqId++;
    const fovRad = THREE.MathUtils.degToRad(input.fovDeg);
    const msg: CpuTraceTileRequest = {
      type: 'traceTile',
      jobId: this.jobId,
      requestId,
      tx: tile.tx,
      tyTop: tile.tyTop,
      tw: tile.tw,
      th: tile.th,
      exportW: input.width,
      exportH: input.height,
      startSample,
      batchSamples,
      maxBounces: 4,
      camPos: [input.cameraPose.position.x, input.cameraPose.position.y, input.cameraPose.position.z],
      camForward: [
        input.cameraPose.forward.x,
        input.cameraPose.forward.y,
        input.cameraPose.forward.z,
      ],
      camRight: [input.cameraPose.right.x, input.cameraPose.right.y, input.cameraPose.right.z],
      camUp: [input.cameraPose.up.x, input.cameraPose.up.y, input.cameraPose.up.z],
      tanHalfFov: Math.tan(fovRad * 0.5),
      aspect: input.width / Math.max(1, input.height),
      envIntensity:
        input.renderSettings.textureQuality === 'low'
          ? 0.7
          : input.renderSettings.textureQuality === 'medium'
            ? 0.9
            : 1.05,
    };

    return new Promise<Float32Array>((resolve, reject) => {
      this.pending.set(requestId, { resolve, reject });
      this.worker!.postMessage(msg);
    });
  }

  dispose(): void {
    for (const p of this.pending.values()) p.reject(new Error('Export cancelled.'));
    this.pending.clear();
    this.worker?.terminate();
    this.worker = null;
  }
}

export async function runTiledPathTracingExportSession(
  input: TiledExportSessionInput,
): Promise<ExportMemoryPlan> {
  const caps = probeDeviceGraphicsCapabilities();
  const plan = planExportMemoryBudget(
    input.width,
    input.height,
    input.samples,
    caps,
    'pathtracer',
  );

  if (!plan.valid) {
    throw new Error(plan.reason || 'Export memory budget rejected requested dimensions.');
  }

  const jobId = `pt_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const tiles = buildCenterFirstTiles(plan.width, plan.height, plan.tileSize);
  const postWorker = new PostProcessWorkerBridge(jobId);

  const gpuTracer = plan.useCpuFallback ? null : new GpuTileRayTracer();
  let useGpu = gpuTracer ? gpuTracer.init(input.packedScene, plan.tileSize) : false;
  if (useGpu && gpuTracer) {
    gpuTracer.configureCameraAndScene(input);
  }

  let cpuTracer: CpuWorkerTracerBridge | null = null;
  if (!useGpu) {
    cpuTracer = new CpuWorkerTracerBridge(jobId);
    if (!cpuTracer.init(input.packedScene)) {
      postWorker.dispose();
      throw new Error('Neither WebGL2 float buffers nor Web Workers are available.');
    }
  }

  const postParams: TilePostProcessParams = {
    exposure: input.renderSettings.exposure,
    contrast: input.renderSettings.contrast,
    gamma: input.renderSettings.gamma,
    toneMappingMode:
      input.renderSettings.renderQuality === 'draft'
        ? 0
        : input.renderSettings.renderQuality === 'standard'
          ? 1
          : 2,
    denoiseStrength: 0.85,
  };

  const engineModeLabel: TiledExportProgressEvent['engineModeLabel'] = useGpu
    ? 'GPU WebGL2'
    : 'CPU BVH Worker';

  const startMs = performance.now();
  let pausedAccumMs = 0;
  const totalSampleWork = plan.width * plan.height * input.samples;
  let completedSampleWork = 0;

  const checkAbortAndPause = async () => {
    if (input.signal?.aborted) throw new Error('Export cancelled.');
    if (input.pauseController?.isPaused()) {
      const pauseStart = performance.now();
      await input.pauseController.waitWhilePaused(input.signal);
      pausedAccumMs += performance.now() - pauseStart;
    }
    if (input.signal?.aborted) throw new Error('Export cancelled.');
  };

  try {
    if (plan.strategy === 'full-progressive') {
      let accumulatedSpp = 0;
      for (const batchSamples of plan.sampleBatches) {
        const completedInPass = new Set<number>();

        for (const tile of tiles) {
          await checkAbortAndPause();

          input.onProgress({
            progress01: completedSampleWork / Math.max(1, totalSampleWork),
            currentSample: accumulatedSpp,
            totalSamples: input.samples,
            completedTilesInPass: completedInPass.size,
            totalTiles: tiles.length,
            samplesPerSec: computeSamplesPerSec(
              completedSampleWork / Math.max(1, plan.totalPixels),
              performance.now() - startMs - pausedAccumMs,
            ),
            elapsedMs: performance.now() - startMs - pausedAccumMs,
            activeTile: tile,
            completedTileIndices: completedInPass,
            engineModeLabel,
            strategy: plan.strategy,
          });

          const tileKey = `${tile.tx},${tile.tyTop}`;
          const sumRgba = useGpu
            ? gpuTracer!.traceTileBatch(tile, plan.height, accumulatedSpp, batchSamples)
            : await cpuTracer!.traceTileBatch(tile, input, accumulatedSpp, batchSamples);

          const processed = await postWorker.processTileBatch(
            tileKey,
            tile.tx,
            tile.tyTop,
            tile.tw,
            tile.th,
            batchSamples,
            sumRgba,
            true,
            useGpu,
            postParams,
          );

          input.onTileOutput({
            tx: tile.tx,
            tyTop: tile.tyTop,
            tw: tile.tw,
            th: tile.th,
            rgba8: processed.rgba8,
            tileIndex: tile.index,
            tileSamples: processed.tileSampleCount,
          });

          completedInPass.add(tile.index);
          completedSampleWork += tile.tw * tile.th * batchSamples;

          const activeElapsed = performance.now() - startMs - pausedAccumMs;
          const equivSamples = completedSampleWork / Math.max(1, plan.totalPixels);
          input.onProgress({
            progress01: completedSampleWork / Math.max(1, totalSampleWork),
            currentSample: Math.min(input.samples, accumulatedSpp + batchSamples),
            totalSamples: input.samples,
            completedTilesInPass: completedInPass.size,
            totalTiles: tiles.length,
            samplesPerSec: computeSamplesPerSec(equivSamples, activeElapsed),
            elapsedMs: activeElapsed,
            activeTile: null,
            completedTileIndices: completedInPass,
            engineModeLabel,
            strategy: plan.strategy,
          });

          await yieldToBrowser();
        }

        accumulatedSpp += batchSamples;
      }
    } else {
      // 'tile-streaming': processes one tile completely through its batches (updating live),
      // then releases that tile's HDR float memory immediately to stay under strict RAM cap.
      const completedTiles = new Set<number>();

      for (const tile of tiles) {
        const tileKey = `${tile.tx},${tile.tyTop}`;
        let tileSpp = 0;

        for (const batchSamples of plan.sampleBatches) {
          await checkAbortAndPause();

          input.onProgress({
            progress01: completedSampleWork / Math.max(1, totalSampleWork),
            currentSample: tileSpp,
            totalSamples: input.samples,
            completedTilesInPass: completedTiles.size,
            totalTiles: tiles.length,
            samplesPerSec: computeSamplesPerSec(
              completedSampleWork / Math.max(1, plan.totalPixels),
              performance.now() - startMs - pausedAccumMs,
            ),
            elapsedMs: performance.now() - startMs - pausedAccumMs,
            activeTile: tile,
            completedTileIndices: completedTiles,
            engineModeLabel,
            strategy: plan.strategy,
          });

          const sumRgba = useGpu
            ? gpuTracer!.traceTileBatch(tile, plan.height, tileSpp, batchSamples)
            : await cpuTracer!.traceTileBatch(tile, input, tileSpp, batchSamples);

          const processed = await postWorker.processTileBatch(
            tileKey,
            tile.tx,
            tile.tyTop,
            tile.tw,
            tile.th,
            batchSamples,
            sumRgba,
            true,
            useGpu,
            postParams,
          );

          input.onTileOutput({
            tx: tile.tx,
            tyTop: tile.tyTop,
            tw: tile.tw,
            th: tile.th,
            rgba8: processed.rgba8,
            tileIndex: tile.index,
            tileSamples: processed.tileSampleCount,
          });

          tileSpp += batchSamples;
          completedSampleWork += tile.tw * tile.th * batchSamples;
          await yieldToBrowser();
        }

        postWorker.releaseTile(tileKey);
        completedTiles.add(tile.index);

        const activeElapsed = performance.now() - startMs - pausedAccumMs;
        input.onProgress({
          progress01: completedSampleWork / Math.max(1, totalSampleWork),
          currentSample: input.samples,
          totalSamples: input.samples,
          completedTilesInPass: completedTiles.size,
          totalTiles: tiles.length,
          samplesPerSec: computeSamplesPerSec(
            completedSampleWork / Math.max(1, plan.totalPixels),
            activeElapsed,
          ),
          elapsedMs: activeElapsed,
          activeTile: null,
          completedTileIndices: completedTiles,
          engineModeLabel,
          strategy: plan.strategy,
        });
      }
    }

    return plan;
  } finally {
    gpuTracer?.dispose();
    cpuTracer?.dispose();
    postWorker.dispose();
  }
}

function computeSamplesPerSec(equivalentSamples: number, elapsedMs: number): number {
  if (elapsedMs <= 20) return 0;
  return Math.round((equivalentSamples / (elapsedMs / 1000)) * 100) / 100;
}
