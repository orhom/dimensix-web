import test from 'node:test';
import assert from 'node:assert/strict';
import {
  resolveTileToRgba8,
  TileAccumulationStore,
  type TilePostProcessParams,
} from './TileAccumulationCore';

const DEFAULT_PARAMS: TilePostProcessParams = {
  exposure: 1.0,
  contrast: 1.0,
  gamma: 2.2,
  toneMappingMode: 2,
  denoiseStrength: 0.75,
};

test('TileAccumulationStore accumulates sample sums without drift up to 1024 SPP and releases memory cleanly', () => {
  const store = new TileAccumulationStore();
  // 2x2 tile, bottom-up flip test: top row in WebGL (y=1) has radiance 0.8, bottom row (y=0) has 0.2
  const incomingBatch1 = new Float32Array([
    0.2, 0.2, 0.2, 1, 0.2, 0.2, 0.2, 1, // src y=0 -> dst y=1
    0.8, 0.8, 0.8, 1, 0.8, 0.8, 0.8, 1, // src y=1 -> dst y=0
  ]);

  store.accumulateTileBatch('0,0', 2, 2, 1, incomingBatch1, true, true);
  // Accumulate 1023 more samples (constant sum = 1023 * value)
  const incomingBatch1023 = new Float32Array(incomingBatch1.length);
  for (let i = 0; i < incomingBatch1.length; i++) {
    incomingBatch1023[i] = incomingBatch1[i] * 1023;
  }
  const slot = store.accumulateTileBatch('0,0', 2, 2, 1023, incomingBatch1023, true, true);
  assert.equal(slot.sampleCount, 1024);

  const rgba = resolveTileToRgba8(slot, DEFAULT_PARAMS);
  assert.equal(rgba.length, 16);
  // Top-left pixel (dst y=0) had higher radiance (0.8) than bottom-left pixel (dst y=1, 0.2)
  assert.ok(rgba[0] > rgba[8], `Expected top pixel ${rgba[0]} > bottom pixel ${rgba[8]}`);
  assert.equal(rgba[3], 255);

  store.releaseTile('0,0');
  assert.equal(store.getTileCount(), 0);
});

test('TileAccumulationStore sanitizes NaN and negative radiances safely', () => {
  const store = new TileAccumulationStore();
  const dirty = new Float32Array([
    Number.NaN, Number.POSITIVE_INFINITY, -5.0, 1,
    0.5, 0.5, 0.5, 1,
  ]);
  const slot = store.accumulateTileBatch('0,0', 2, 1, 2, dirty, false, false);
  const rgba = resolveTileToRgba8(slot, { ...DEFAULT_PARAMS, denoiseStrength: 0 });
  assert.equal(rgba[0], 0);
  assert.equal(rgba[1], 0);
  assert.equal(rgba[2], 0);
  assert.ok(rgba[4] > 100);
});
