import type * as THREE from 'three';
import type { ModelFormat } from '../scene/SceneNode';

export interface ImportedTextureData {
  id: string;
  width: number;
  height: number;
  rgba: Uint8Array;
}

export interface ImportedMaterialDescriptor {
  color: [number, number, number];
  roughness: number;
  metalness: number;
  transmission: number;
  ior: number;
  emissive: [number, number, number];
  doubleSided: boolean;
  textureId: string | null;
}

export interface ImportedMeshPart {
  name: string;
  geometryKey: string;
  localMatrix: number[]; // 16-element column-major matrix relative to normalized asset root
  geometry: THREE.BufferGeometry;
  materials: ImportedMaterialDescriptor[];
  submeshes: Array<{
    startIndex: number;
    count: number;
    materialIndex: number;
  }>;
  triangleCount: number;
}

export interface ImportedAsset {
  assetId: string;
  fileName: string;
  format: ModelFormat;
  rootObject: THREE.Group;
  parts: ImportedMeshPart[];
  textures: ImportedTextureData[];
  meshCount: number;
  triangleCount: number;
  partNames: string[];
  rawBufferBase64?: string;
}
