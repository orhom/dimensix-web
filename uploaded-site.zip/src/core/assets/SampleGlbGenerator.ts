/**
 * Generates a valid, spec-compliant binary glTF 2.0 (.glb) buffer in memory
 * containing a multi-part mechanical/crystalline showcase sculpture with real
 * vertex positions, normals, UVs, indices, node hierarchy, and PBR materials.
 */

interface PartDef {
  name: string;
  positions: number[];
  normals: number[];
  uvs: number[];
  indices: number[];
  translation: [number, number, number];
  materialIndex: number;
}

export function buildShowcaseGlbBuffer(): ArrayBuffer {
  const parts: PartDef[] = [];

  // Part 1: Octagonal Machined Base Ring (gold/brass metallic PBR)
  parts.push(createPrismPart('Glb_Brass_Base', 8, 0.72, 0.72, 0.18, [0, 0.09, 0], 0));
  // Part 2: Upper Collar (brushed titanium)
  parts.push(createPrismPart('Glb_Titanium_Collar', 12, 0.45, 0.36, 0.24, [0, 0.3, 0], 1));
  // Part 3: Faceted Crystal Spire (emerald/cyan glossy prism)
  parts.push(createCrystalSpirePart('Glb_Faceted_Spire', 6, 0.3, 0.92, [0, 0.42, 0], 2));

  // Build binary buffer (4-byte aligned per accessor view)
  const binChunks: Uint8Array[] = [];
  let byteOffset = 0;

  const bufferViews: Array<{
    buffer: number;
    byteOffset: number;
    byteLength: number;
    target: number;
  }> = [];

  const accessors: Array<{
    bufferView: number;
    componentType: number;
    count: number;
    type: string;
    min?: number[];
    max?: number[];
  }> = [];

  const meshes: Array<{
    name: string;
    primitives: Array<{
      attributes: { POSITION: number; NORMAL: number; TEXCOORD_0: number };
      indices: number;
      material: number;
    }>;
  }> = [];

  const nodes: Array<{
    name: string;
    mesh?: number;
    translation?: [number, number, number];
    children?: number[];
  }> = [];

  const pushTypedArray = (data: Float32Array | Uint16Array, target: number): number => {
    const raw = new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    const pad = (4 - (raw.byteLength % 4)) % 4;
    const viewIndex = bufferViews.length;
    bufferViews.push({
      buffer: 0,
      byteOffset,
      byteLength: raw.byteLength,
      target,
    });
    binChunks.push(raw);
    if (pad > 0) binChunks.push(new Uint8Array(pad));
    byteOffset += raw.byteLength + pad;
    return viewIndex;
  };

  for (let i = 0; i < parts.length; i++) {
    const p = parts[i];
    const posArr = new Float32Array(p.positions);
    const normArr = new Float32Array(p.normals);
    const uvArr = new Float32Array(p.uvs);
    const idxArr = new Uint16Array(p.indices);

    const posView = pushTypedArray(posArr, 34962); // ARRAY_BUFFER
    const normView = pushTypedArray(normArr, 34962);
    const uvView = pushTypedArray(uvArr, 34962);
    const idxView = pushTypedArray(idxArr, 34963); // ELEMENT_ARRAY_BUFFER

    const { min, max } = computeMinMax3(posArr);

    const posAccessor = accessors.length;
    accessors.push({
      bufferView: posView,
      componentType: 5126, // FLOAT
      count: posArr.length / 3,
      type: 'VEC3',
      min,
      max,
    });

    const normAccessor = accessors.length;
    accessors.push({
      bufferView: normView,
      componentType: 5126,
      count: normArr.length / 3,
      type: 'VEC3',
    });

    const uvAccessor = accessors.length;
    accessors.push({
      bufferView: uvView,
      componentType: 5126,
      count: uvArr.length / 2,
      type: 'VEC2',
    });

    const idxAccessor = accessors.length;
    accessors.push({
      bufferView: idxView,
      componentType: 5123, // UNSIGNED_SHORT
      count: idxArr.length,
      type: 'SCALAR',
    });

    const meshIndex = meshes.length;
    meshes.push({
      name: p.name,
      primitives: [
        {
          attributes: {
            POSITION: posAccessor,
            NORMAL: normAccessor,
            TEXCOORD_0: uvAccessor,
          },
          indices: idxAccessor,
          material: p.materialIndex,
        },
      ],
    });

    nodes.push({
      name: p.name,
      mesh: meshIndex,
      translation: p.translation,
    });
  }

  // Root parent node uniting the 3 submesh nodes
  const rootNodeIdx = nodes.length;
  nodes.push({
    name: 'Precision_Artifact_Root',
    children: [0, 1, 2],
  });

  const gltfJson = {
    asset: { version: '2.0', generator: 'DimensiX GLB Builder' },
    scene: 0,
    scenes: [{ name: 'ArtifactScene', nodes: [rootNodeIdx] }],
    nodes,
    meshes,
    materials: [
      {
        name: 'BrushedBrass',
        pbrMetallicRoughness: {
          baseColorFactor: [0.92, 0.72, 0.34, 1.0],
          metallicFactor: 0.92,
          roughnessFactor: 0.24,
        },
      },
      {
        name: 'DarkTitanium',
        pbrMetallicRoughness: {
          baseColorFactor: [0.22, 0.27, 0.35, 1.0],
          metallicFactor: 0.85,
          roughnessFactor: 0.32,
        },
      },
      {
        name: 'CobaltCeramic',
        pbrMetallicRoughness: {
          baseColorFactor: [0.22, 0.78, 0.96, 1.0],
          metallicFactor: 0.12,
          roughnessFactor: 0.16,
        },
      },
    ],
    buffers: [{ byteLength: byteOffset }],
    bufferViews,
    accessors,
  };

  const jsonEncoder = new TextEncoder();
  const rawJsonBytes = jsonEncoder.encode(JSON.stringify(gltfJson));
  const jsonPad = (4 - (rawJsonBytes.byteLength % 4)) % 4;
  const jsonChunkLen = rawJsonBytes.byteLength + jsonPad;
  const binChunkLen = byteOffset;
  const totalLen = 12 + 8 + jsonChunkLen + 8 + binChunkLen;

  const out = new ArrayBuffer(totalLen);
  const view = new DataView(out);
  const bytes = new Uint8Array(out);

  // GLB Header
  view.setUint32(0, 0x46546c67, true); // 'glTF'
  view.setUint32(4, 2, true); // version 2
  view.setUint32(8, totalLen, true);

  // JSON Chunk Header + Data
  view.setUint32(12, jsonChunkLen, true);
  view.setUint32(16, 0x4e4f534a, true); // 'JSON'
  bytes.set(rawJsonBytes, 20);
  for (let i = 0; i < jsonPad; i++) {
    bytes[20 + rawJsonBytes.byteLength + i] = 0x20; // space padding per GLB spec
  }

  // BIN Chunk Header + Data
  const binHeaderOffset = 20 + jsonChunkLen;
  view.setUint32(binHeaderOffset, binChunkLen, true);
  view.setUint32(binHeaderOffset + 4, 0x004e4942, true); // 'BIN\0'

  let cursor = binHeaderOffset + 8;
  for (const chunk of binChunks) {
    bytes.set(chunk, cursor);
    cursor += chunk.byteLength;
  }

  return out;
}

function createPrismPart(
  name: string,
  sides: number,
  bottomR: number,
  topR: number,
  height: number,
  translation: [number, number, number],
  materialIndex: number,
): PartDef {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  const halfH = height * 0.5;

  const addTri = (
    a: [number, number, number],
    b: [number, number, number],
    c: [number, number, number],
    uva: [number, number],
    uvb: [number, number],
    uvc: [number, number],
  ) => {
    const ux = b[0] - a[0];
    const uy = b[1] - a[1];
    const uz = b[2] - a[2];
    const vx = c[0] - a[0];
    const vy = c[1] - a[1];
    const vz = c[2] - a[2];
    const nx = uy * vz - uz * vy;
    const ny = uz * vx - ux * vz;
    const nz = ux * vy - uy * vx;
    const len = Math.hypot(nx, ny, nz) || 1;
    const n: [number, number, number] = [nx / len, ny / len, nz / len];
    const baseIdx = positions.length / 3;
    positions.push(...a, ...b, ...c);
    normals.push(...n, ...n, ...n);
    uvs.push(...uva, ...uvb, ...uvc);
    indices.push(baseIdx, baseIdx + 1, baseIdx + 2);
  };

  for (let i = 0; i < sides; i++) {
    const a0 = (i / sides) * Math.PI * 2;
    const a1 = ((i + 1) / sides) * Math.PI * 2;
    const b0: [number, number, number] = [Math.cos(a0) * bottomR, -halfH, Math.sin(a0) * bottomR];
    const b1: [number, number, number] = [Math.cos(a1) * bottomR, -halfH, Math.sin(a1) * bottomR];
    const t0: [number, number, number] = [Math.cos(a0) * topR, halfH, Math.sin(a0) * topR];
    const t1: [number, number, number] = [Math.cos(a1) * topR, halfH, Math.sin(a1) * topR];

    // Side quad (CCW outward)
    addTri(b0, t0, t1, [i / sides, 0], [i / sides, 1], [(i + 1) / sides, 1]);
    addTri(b0, t1, b1, [i / sides, 0], [(i + 1) / sides, 1], [(i + 1) / sides, 0]);

    // Top cap
    addTri([0, halfH, 0], t1, t0, [0.5, 0.5], [1, 1], [0, 1]);
    // Bottom cap
    addTri([0, -halfH, 0], b0, b1, [0.5, 0.5], [0, 0], [1, 0]);
  }

  return { name, positions, normals, uvs, indices, translation, materialIndex };
}

function createCrystalSpirePart(
  name: string,
  sides: number,
  radius: number,
  height: number,
  translation: [number, number, number],
  materialIndex: number,
): PartDef {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  const midY = height * 0.45;

  const addTri = (
    a: [number, number, number],
    b: [number, number, number],
    c: [number, number, number],
  ) => {
    const ux = b[0] - a[0];
    const uy = b[1] - a[1];
    const uz = b[2] - a[2];
    const vx = c[0] - a[0];
    const vy = c[1] - a[1];
    const vz = c[2] - a[2];
    const nx = uy * vz - uz * vy;
    const ny = uz * vx - ux * vz;
    const nz = ux * vy - uy * vx;
    const len = Math.hypot(nx, ny, nz) || 1;
    const baseIdx = positions.length / 3;
    positions.push(...a, ...b, ...c);
    normals.push(nx / len, ny / len, nz / len, nx / len, ny / len, nz / len, nx / len, ny / len, nz / len);
    uvs.push(0, 0, 1, 0, 0.5, 1);
    indices.push(baseIdx, baseIdx + 1, baseIdx + 2);
  };

  for (let i = 0; i < sides; i++) {
    const a0 = (i / sides) * Math.PI * 2;
    const a1 = ((i + 1) / sides) * Math.PI * 2;
    const m0: [number, number, number] = [Math.cos(a0) * radius, midY, Math.sin(a0) * radius];
    const m1: [number, number, number] = [Math.cos(a1) * radius, midY, Math.sin(a1) * radius];
    const b0: [number, number, number] = [
      Math.cos(a0) * radius * 0.72,
      0,
      Math.sin(a0) * radius * 0.72,
    ];
    const b1: [number, number, number] = [
      Math.cos(a1) * radius * 0.72,
      0,
      Math.sin(a1) * radius * 0.72,
    ];

    addTri(b0, m0, m1);
    addTri(b0, m1, b1);
    addTri(m0, [0, height, 0], m1);
    addTri([0, 0, 0], b0, b1);
  }

  return { name, positions, normals, uvs, indices, translation, materialIndex };
}

function computeMinMax3(arr: Float32Array): { min: number[]; max: number[] } {
  const min = [Infinity, Infinity, Infinity];
  const max = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < arr.length; i += 3) {
    min[0] = Math.min(min[0], arr[i]);
    min[1] = Math.min(min[1], arr[i + 1]);
    min[2] = Math.min(min[2], arr[i + 2]);
    max[0] = Math.max(max[0], arr[i]);
    max[1] = Math.max(max[1], arr[i + 1]);
    max[2] = Math.max(max[2], arr[i + 2]);
  }
  return { min, max };
}
