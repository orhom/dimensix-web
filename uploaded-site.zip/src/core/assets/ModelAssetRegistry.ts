import * as THREE from 'three';
import type { ImportedAsset } from './ModelAssetTypes';

/**
 * Stores parsed 3D model assets so both Real-Time and Path Tracing engines
 * share identical geometry, hierarchy, materials, and textures, and so
 * duplicating a model node reuses the same underlying geometry/BVH BLAS.
 */
export class ModelAssetRegistry {
  private assets = new Map<string, ImportedAsset>();

  register(asset: ImportedAsset): void {
    const existing = this.assets.get(asset.assetId);
    if (existing && existing !== asset) {
      this.disposeAssetResources(existing);
    }
    this.assets.set(asset.assetId, asset);
  }

  get(assetId: string): ImportedAsset | null {
    return this.assets.get(assetId) ?? null;
  }

  has(assetId: string): boolean {
    return this.assets.has(assetId);
  }

  list(): ImportedAsset[] {
    return Array.from(this.assets.values());
  }

  /**
   * Clones the Three.js scene hierarchy for mounting into a viewport while
   * sharing underlying BufferGeometry and Material references (instanced memory).
   */
  instantiateThreeGroup(assetId: string): THREE.Group | null {
    const asset = this.assets.get(assetId);
    if (!asset) return null;
    const clone = asset.rootObject.clone(true);
    return clone;
  }

  remove(assetId: string): void {
    const existing = this.assets.get(assetId);
    if (!existing) return;
    this.disposeAssetResources(existing);
    this.assets.delete(assetId);
  }

  clear(): void {
    for (const asset of this.assets.values()) {
      this.disposeAssetResources(asset);
    }
    this.assets.clear();
  }

  getEstimatedMemoryBytes(): number {
    let total = 0;
    for (const asset of this.assets.values()) {
      for (const part of asset.parts) {
        const pos = part.geometry.getAttribute('position');
        const norm = part.geometry.getAttribute('normal');
        const uv = part.geometry.getAttribute('uv');
        const idx = part.geometry.getIndex();
        if (pos) total += pos.array.byteLength;
        if (norm) total += norm.array.byteLength;
        if (uv) total += uv.array.byteLength;
        if (idx) total += idx.array.byteLength;
      }
      for (const tex of asset.textures) {
        total += tex.rgba.byteLength;
      }
    }
    return total;
  }

  private disposeAssetResources(asset: ImportedAsset): void {
    asset.rootObject.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const mesh = child as THREE.Mesh;
        mesh.geometry?.dispose();
        const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
        for (const mat of mats) {
          if (!mat) continue;
          const std = mat as THREE.MeshStandardMaterial;
          std.map?.dispose();
          std.normalMap?.dispose();
          std.roughnessMap?.dispose();
          std.metalnessMap?.dispose();
          std.emissiveMap?.dispose();
          mat.dispose();
        }
      }
    });
  }
}
