import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { STLLoader } from 'three/addons/loaders/STLLoader.js';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
import type { ModelFormat } from '../scene/SceneNode';
import type {
  ImportedAsset,
  ImportedMaterialDescriptor,
  ImportedMeshPart,
  ImportedTextureData,
} from './ModelAssetTypes';

export class ModelImportError extends Error {
  readonly code: 'UNSUPPORTED_FORMAT' | 'EMPTY_FILE' | 'PARSE_FAILED' | 'NO_GEOMETRY';

  constructor(
    code: 'UNSUPPORTED_FORMAT' | 'EMPTY_FILE' | 'PARSE_FAILED' | 'NO_GEOMETRY',
    message: string,
  ) {
    super(message);
    this.name = 'ModelImportError';
    this.code = code;
  }
}

const SUPPORTED_EXTENSIONS: ReadonlySet<ModelFormat> = new Set([
  'glb',
  'gltf',
  'obj',
  'stl',
  'fbx',
]);

export function detectModelFormat(fileName: string): ModelFormat | null {
  const dot = fileName.lastIndexOf('.');
  if (dot < 0) return null;
  const ext = fileName.slice(dot + 1).toLowerCase();
  if (SUPPORTED_EXTENSIONS.has(ext as ModelFormat)) {
    return ext as ModelFormat;
  }
  return null;
}

export async function importModelFile(file: File): Promise<ImportedAsset> {
  const format = detectModelFormat(file.name);
  if (!format) {
    throw new ModelImportError(
      'UNSUPPORTED_FORMAT',
      `Unsupported file format for "${file.name}". Supported formats: .glb, .gltf, .obj, .stl, .fbx`,
    );
  }
  if (file.size <= 0) {
    throw new ModelImportError('EMPTY_FILE', `File "${file.name}" is empty.`);
  }
  const buffer = await file.arrayBuffer();
  return parseModelFromBuffer(buffer, file.name, { encodeBase64: buffer.byteLength <= 1_500_000 });
}

export async function parseModelFromBuffer(
  buffer: ArrayBuffer,
  fileName: string,
  options?: { assetId?: string; encodeBase64?: boolean },
): Promise<ImportedAsset> {
  const format = detectModelFormat(fileName);
  if (!format) {
    throw new ModelImportError(
      'UNSUPPORTED_FORMAT',
      `Unsupported file format for "${fileName}". Supported formats: .glb, .gltf, .obj, .stl, .fbx`,
    );
  }
  if (!buffer || buffer.byteLength === 0) {
    throw new ModelImportError('EMPTY_FILE', `File "${fileName}" contains no bytes.`);
  }

  let parsedRoot: THREE.Group;
  try {
    parsedRoot = await loadByFormat(buffer, format, fileName);
  } catch (err) {
    if (err instanceof ModelImportError) throw err;
    const msg = err instanceof Error ? err.message : String(err);
    throw new ModelImportError('PARSE_FAILED', `Failed to parse "${fileName}": ${msg}`);
  }

  // Wrap inside a normalized pivot group so internal node hierarchy stays intact
  parsedRoot.updateMatrixWorld(true);
  const rawBox = new THREE.Box3().setFromObject(parsedRoot);
  if (rawBox.isEmpty()) {
    throw new ModelImportError(
      'NO_GEOMETRY',
      `Model "${fileName}" contains no valid 3D mesh geometry.`,
    );
  }

  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  rawBox.getSize(size);
  rawBox.getCenter(center);

  const maxDim = Math.max(size.x, size.y, size.z, 1e-4);
  // Fit comfortably inside editor viewport (~2.0m max span if oversized or microscopic)
  const scaleFactor = maxDim > 4.2 || maxDim < 0.35 ? 2.0 / maxDim : 1.0;

  const wrapper = new THREE.Group();
  wrapper.name = stripExtension(fileName);

  parsedRoot.scale.multiplyScalar(scaleFactor);
  parsedRoot.position.set(
    -center.x * scaleFactor,
    -rawBox.min.y * scaleFactor,
    -center.z * scaleFactor,
  );
  wrapper.add(parsedRoot);
  wrapper.updateMatrixWorld(true);

  const assetId =
    options?.assetId ?? `asset_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

  const parts: ImportedMeshPart[] = [];
  const textures: ImportedTextureData[] = [];
  const textureIdByThreeUuid = new Map<string, string>();
  const geometryKeyByUuid = new Map<string, string>();
  const partNames: string[] = [];
  let totalTriangles = 0;

  const rootInverse = new THREE.Matrix4().copy(wrapper.matrixWorld).invert();

  wrapper.traverse((child) => {
    const isMesh = (child as THREE.Mesh).isMesh;
    const isInstanced = (child as THREE.InstancedMesh).isInstancedMesh;
    if (!isMesh && !isInstanced) return;

    const mesh = child as THREE.Mesh;
    const geo = mesh.geometry;
    if (!geo) return;

    const posAttr = geo.getAttribute('position');
    if (!posAttr || posAttr.count < 3) return;

    // Ensure geometry has valid normals for shading and BVH
    if (!geo.getAttribute('normal')) {
      geo.computeVertexNormals();
    }

    const triCount = geo.getIndex()
      ? Math.floor(geo.getIndex()!.count / 3)
      : Math.floor(posAttr.count / 3);
    if (triCount <= 0) return;

    mesh.castShadow = true;
    mesh.receiveShadow = true;

    let geoKey = geometryKeyByUuid.get(geo.uuid);
    if (!geoKey) {
      geoKey = `${assetId}:geo_${geometryKeyByUuid.size}`;
      geometryKeyByUuid.set(geo.uuid, geoKey);
    }

    const threeMaterials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    const materialDescriptors: ImportedMaterialDescriptor[] = threeMaterials.map((mat) =>
      extractMaterialDescriptor(mat, textures, textureIdByThreeUuid),
    );
    if (materialDescriptors.length === 0) {
      materialDescriptors.push(defaultMaterialDescriptor());
    }

    const submeshes: ImportedMeshPart['submeshes'] = [];
    const totalIdxCount = geo.getIndex() ? geo.getIndex()!.count : posAttr.count;
    if (geo.groups && geo.groups.length > 0) {
      for (const g of geo.groups) {
        if (g.count <= 0) continue;
        submeshes.push({
          startIndex: g.start,
          count: g.count,
          materialIndex: Math.min(
            Math.max(0, g.materialIndex ?? 0),
            materialDescriptors.length - 1,
          ),
        });
      }
    }
    if (submeshes.length === 0) {
      submeshes.push({
        startIndex: 0,
        count: totalIdxCount,
        materialIndex: 0,
      });
    }

    const baseName = mesh.name?.trim() || `Submesh_${parts.length + 1}`;
    const relMatrix = new THREE.Matrix4().multiplyMatrices(rootInverse, mesh.matrixWorld);

    if (isInstanced) {
      const instMesh = child as THREE.InstancedMesh;
      const instMat = new THREE.Matrix4();
      for (let idx = 0; idx < instMesh.count; idx++) {
        instMesh.getMatrixAt(idx, instMat);
        const combined = new THREE.Matrix4().multiplyMatrices(relMatrix, instMat);
        const name = `${baseName}_Inst_${idx + 1}`;
        partNames.push(name);
        parts.push({
          name,
          geometryKey: geoKey,
          localMatrix: Array.from(combined.elements),
          geometry: geo,
          materials: materialDescriptors,
          submeshes,
          triangleCount: triCount,
        });
        totalTriangles += triCount;
      }
    } else {
      partNames.push(baseName);
      parts.push({
        name: baseName,
        geometryKey: geoKey,
        localMatrix: Array.from(relMatrix.elements),
        geometry: geo,
        materials: materialDescriptors,
        submeshes,
        triangleCount: triCount,
      });
      totalTriangles += triCount;
    }
  });

  if (parts.length === 0 || totalTriangles === 0) {
    throw new ModelImportError(
      'NO_GEOMETRY',
      `Model "${fileName}" did not produce any renderable triangles.`,
    );
  }

  return {
    assetId,
    fileName,
    format,
    rootObject: wrapper,
    parts,
    textures,
    meshCount: parts.length,
    triangleCount: totalTriangles,
    partNames,
    rawBufferBase64: options?.encodeBase64 ? arrayBufferToBase64(buffer) : undefined,
  };
}

async function loadByFormat(
  buffer: ArrayBuffer,
  format: ModelFormat,
  fileName: string,
): Promise<THREE.Group> {
  if (format === 'glb' || format === 'gltf') {
    const loader = new GLTFLoader();
    if (format === 'glb') {
      validateGlbMagic(buffer, fileName);
      const gltf = await new Promise<{ scene: THREE.Group }>((resolve, reject) => {
        loader.parse(
          buffer,
          '',
          (res) => resolve(res as unknown as { scene: THREE.Group }),
          (err) => reject(err instanceof Error ? err : new Error(String(err))),
        );
      });
      const group = new THREE.Group();
      group.add(gltf.scene);
      return group;
    } else {
      const text = new TextDecoder().decode(buffer);
      let json: Record<string, unknown>;
      try {
        json = JSON.parse(text) as Record<string, unknown>;
      } catch {
        throw new ModelImportError('PARSE_FAILED', `Invalid JSON in glTF file "${fileName}".`);
      }
      const buffers = Array.isArray(json.buffers) ? json.buffers : [];
      for (const b of buffers) {
        if (
          b &&
          typeof b === 'object' &&
          'uri' in b &&
          typeof (b as { uri?: unknown }).uri === 'string'
        ) {
          const uri = (b as { uri: string }).uri;
          if (!uri.startsWith('data:')) {
            throw new ModelImportError(
              'PARSE_FAILED',
              `glTF "${fileName}" references external buffer "${uri}". Use self-contained .glb or embedded data URIs.`,
            );
          }
        }
      }
      const gltf = await new Promise<{ scene: THREE.Group }>((resolve, reject) => {
        loader.parse(
          text,
          '',
          (res) => resolve(res as unknown as { scene: THREE.Group }),
          (err) => reject(err instanceof Error ? err : new Error(String(err))),
        );
      });
      const group = new THREE.Group();
      group.add(gltf.scene);
      return group;
    }
  }

  if (format === 'obj') {
    const text = new TextDecoder().decode(buffer);
    if (!/\bv\s+[-\d.eE]+/m.test(text)) {
      throw new ModelImportError(
        'NO_GEOMETRY',
        `OBJ file "${fileName}" contains no vertex coordinates.`,
      );
    }
    const loader = new OBJLoader();
    const objGroup = loader.parse(text);
    objGroup.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const mesh = child as THREE.Mesh;
        if (!mesh.material) {
          mesh.material = new THREE.MeshStandardMaterial({
            color: 0xcbd5e1,
            roughness: 0.45,
            metalness: 0.25,
          });
        }
      }
    });
    return objGroup;
  }

  if (format === 'stl') {
    const loader = new STLLoader();
    const geometry = loader.parse(buffer);
    geometry.computeVertexNormals();
    const mat = new THREE.MeshStandardMaterial({
      color: 0xcbd5e1,
      roughness: 0.38,
      metalness: 0.35,
    });
    const mesh = new THREE.Mesh(geometry, mat);
    mesh.name = stripExtension(fileName);
    const group = new THREE.Group();
    group.add(mesh);
    return group;
  }

  if (format === 'fbx') {
    const loader = new FBXLoader();
    const fbxGroup = loader.parse(buffer, '');
    return fbxGroup;
  }

  throw new ModelImportError('UNSUPPORTED_FORMAT', `Unsupported model format "${format}".`);
}

function validateGlbMagic(buffer: ArrayBuffer, fileName: string): void {
  if (buffer.byteLength < 12) {
    throw new ModelImportError('PARSE_FAILED', `GLB "${fileName}" header is truncated.`);
  }
  const view = new DataView(buffer);
  const magic = view.getUint32(0, true);
  if (magic !== 0x46546c67) {
    throw new ModelImportError('PARSE_FAILED', `File "${fileName}" is not a valid binary GLB.`);
  }
}

function defaultMaterialDescriptor(): ImportedMaterialDescriptor {
  return {
    color: [0.8, 0.84, 0.9],
    roughness: 0.45,
    metalness: 0.2,
    transmission: 0,
    ior: 1.5,
    emissive: [0, 0, 0],
    doubleSided: false,
    textureId: null,
  };
}

function extractMaterialDescriptor(
  mat: THREE.Material | undefined,
  textures: ImportedTextureData[],
  textureIdByThreeUuid: Map<string, string>,
): ImportedMaterialDescriptor {
  if (!mat) return defaultMaterialDescriptor();

  const std = mat as THREE.MeshStandardMaterial & THREE.MeshPhysicalMaterial;
  const col = std.color instanceof THREE.Color ? std.color : new THREE.Color(0xcbd5e1);
  const em = std.emissive instanceof THREE.Color ? std.emissive : new THREE.Color(0x000000);
  const emIntensity = typeof std.emissiveIntensity === 'number' ? std.emissiveIntensity : 1;

  let textureId: string | null = null;
  if (std.map) {
    textureId = extractTextureData(std.map, textures, textureIdByThreeUuid);
  }

  return {
    color: [col.r, col.g, col.b],
    roughness: typeof std.roughness === 'number' ? clamp01(std.roughness) : 0.45,
    metalness: typeof std.metalness === 'number' ? clamp01(std.metalness) : 0.2,
    transmission: typeof std.transmission === 'number' ? clamp01(std.transmission) : 0,
    ior: typeof std.ior === 'number' ? Math.max(1.0, Math.min(2.5, std.ior)) : 1.5,
    emissive: [em.r * emIntensity, em.g * emIntensity, em.b * emIntensity],
    doubleSided: mat.side === THREE.DoubleSide,
    textureId,
  };
}

function extractTextureData(
  tex: THREE.Texture,
  textures: ImportedTextureData[],
  textureIdByThreeUuid: Map<string, string>,
): string | null {
  const cached = textureIdByThreeUuid.get(tex.uuid);
  if (cached) return cached;

  if (typeof document === 'undefined') {
    return null;
  }

  const img = tex.image as
    | { width?: number; height?: number; data?: Uint8Array | Uint8ClampedArray }
    | undefined;
  if (!img || !img.width || !img.height) return null;

  const targetSize = 128;
  try {
    const canvas = document.createElement('canvas');
    canvas.width = targetSize;
    canvas.height = targetSize;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    if (
      typeof HTMLImageElement !== 'undefined' &&
      (img instanceof HTMLImageElement ||
        img instanceof HTMLCanvasElement ||
        (typeof ImageBitmap !== 'undefined' && img instanceof ImageBitmap))
    ) {
      ctx.drawImage(img as CanvasImageSource, 0, 0, targetSize, targetSize);
      const imgData = ctx.getImageData(0, 0, targetSize, targetSize);
      const id = `tex_${textures.length}`;
      textures.push({
        id,
        width: targetSize,
        height: targetSize,
        rgba: new Uint8Array(imgData.data.buffer),
      });
      textureIdByThreeUuid.set(tex.uuid, id);
      return id;
    }

    if (img.data && img.data.length >= img.width * img.height * 4) {
      const id = `tex_${textures.length}`;
      const w = Math.min(img.width, targetSize);
      const h = Math.min(img.height, targetSize);
      const rawCanvas = document.createElement('canvas');
      rawCanvas.width = img.width;
      rawCanvas.height = img.height;
      const rawCtx = rawCanvas.getContext('2d');
      if (rawCtx) {
        const clamped = new Uint8ClampedArray(img.data.slice(0, img.width * img.height * 4));
        rawCtx.putImageData(new ImageData(clamped, img.width, img.height), 0, 0);
        ctx.drawImage(rawCanvas, 0, 0, w, h);
        const scaled = ctx.getImageData(0, 0, w, h);
        textures.push({
          id,
          width: w,
          height: h,
          rgba: new Uint8Array(scaled.data.buffer),
        });
        textureIdByThreeUuid.set(tex.uuid, id);
        return id;
      }
    }
  } catch {
    return null;
  }
  return null;
}

function stripExtension(name: string): string {
  const dot = name.lastIndexOf('.');
  return dot > 0 ? name.slice(0, dot) : name;
}

function clamp01(v: number): number {
  return Math.min(1, Math.max(0, v));
}

export function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

export function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}
