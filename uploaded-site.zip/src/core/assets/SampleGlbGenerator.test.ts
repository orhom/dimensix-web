import test from 'node:test';
import assert from 'node:assert/strict';
import { buildShowcaseGlbBuffer } from './SampleGlbGenerator';
import { ModelImportError, parseModelFromBuffer } from './ModelImporter';

test('SampleGlbGenerator builds valid binary glTF 2.0 parsed by GLTFLoader', async () => {
  const buffer = buildShowcaseGlbBuffer();
  assert.ok(buffer.byteLength > 100);

  const view = new DataView(buffer);
  assert.equal(view.getUint32(0, true), 0x46546c67); // 'glTF'
  assert.equal(view.getUint32(4, true), 2);

  const asset = await parseModelFromBuffer(buffer, 'precision_artifact.glb', {
    assetId: 'test_artifact',
  });

  assert.equal(asset.format, 'glb');
  assert.equal(asset.meshCount, 3);
  assert.ok(asset.triangleCount > 40);
  assert.deepEqual(asset.partNames, [
    'Glb_Brass_Base',
    'Glb_Titanium_Collar',
    'Glb_Faceted_Spire',
  ]);

  for (const part of asset.parts) {
    assert.ok(part.triangleCount > 0);
    assert.ok(part.geometry.getAttribute('position').count >= 3);
    assert.ok(part.geometry.getAttribute('normal').count >= 3);
    assert.equal(part.materials.length, 1);
  }
});

test('ModelImporter rejects unsupported and malformed files with explicit errors', async () => {
  const garbage = new TextEncoder().encode('not a 3d model').buffer;

  await assert.rejects(
    () => parseModelFromBuffer(garbage, 'broken.xyz'),
    (err: unknown) => err instanceof ModelImportError && err.code === 'UNSUPPORTED_FORMAT',
  );

  await assert.rejects(
    () => parseModelFromBuffer(garbage, 'corrupt.glb'),
    (err: unknown) => err instanceof ModelImportError && err.code === 'PARSE_FAILED',
  );

  await assert.rejects(
    () => parseModelFromBuffer(new ArrayBuffer(0), 'empty.obj'),
    (err: unknown) => err instanceof ModelImportError && err.code === 'EMPTY_FILE',
  );
});

test('ModelImporter parses real OBJ geometry into triangles and parts', async () => {
  const objText = [
    '# Pyramid OBJ',
    'o TestPyramid',
    'v 0 1 0',
    'v -1 0 1',
    'v 1 0 1',
    'v 1 0 -1',
    'v -1 0 -1',
    'f 1 2 3',
    'f 1 3 4',
    'f 1 4 5',
    'f 1 5 2',
    'f 2 5 4',
    'f 2 4 3',
  ].join('\n');
  const buf = new TextEncoder().encode(objText).buffer;
  const asset = await parseModelFromBuffer(buf, 'pyramid.obj');
  assert.equal(asset.format, 'obj');
  assert.equal(asset.meshCount, 1);
  assert.equal(asset.triangleCount, 6);
});
